<?php
echo 'Ruta al binario PHP: ' . PHP_BINARY . "\n";
echo 'Ruta real al binario PHP: ' . realpath(PHP_BINARY) . "\n";
?>