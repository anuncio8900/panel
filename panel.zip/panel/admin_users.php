<?php
// panel/admin_users.php
date_default_timezone_set('America/Bogota');
session_start();

// --- ACTIVAR VISUALIZACIÓN DE ERRORES (ELIMINAR EN PRODUCCIÓN) ---
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// --- FIN ACTIVAR VISUALIZACIÓN DE ERRORES ---


// Incluir la conexión a la base de datos
require_once 'db.php';

// --- VERIFICACIÓN DE SESIÓN Y ROL DE ADMINISTRADOR ---
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); // Redirige si no está logueado o no es admin
    exit();
}

// Opcional: Comprobación de inactividad de la sesión
$session_timeout = 3600; // 1 hora
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset();
    session_destroy();
    header("Location: login.php?expired=true");
    exit();
}
$_SESSION['last_activity'] = time();

$username_admin = $_SESSION['username']; // Nombre del admin logueado
$error_message = '';
$success_message = '';

// --- Lógica para Crear Nuevo Usuario ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_user') {
    $new_username = trim($_POST['new_username'] ?? '');
    $new_telegram_chat_id = trim($_POST['new_telegram_chat_id'] ?? '');
    $new_role = $_POST['new_role'] ?? 'user';

    if (empty($new_username) || empty($new_telegram_chat_id)) {
        $error_message = "Todos los campos de usuario son obligatorios.";
    } elseif (!in_array($new_role, ['admin', 'user', 'marquillador'])) {
        $error_message = "Rol inválido.";
    } else {
        try {
            // Se inserta allowed_entities como NULL por defecto al crear
            $stmt = $db->prepare("INSERT INTO panel_users (username, telegram_chat_id, role, allowed_entities) VALUES (?, ?, ?, NULL)");
            $stmt->execute([$new_username, $new_telegram_chat_id, $new_role]);
            $success_message = "Usuario '{$new_username}' creado con éxito.";
            // Limpiar campos del formulario después del éxito
            $new_username = '';
            $new_telegram_chat_id = '';
            $new_role = 'user';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Código de error para entrada duplicada (UNIQUE constraint)
                $error_message = "Error: El nombre de usuario o ID de chat de Telegram ya existe.";
            } else {
                $error_message = "Error de base de datos al crear usuario: " . $e->getMessage();
            }
        }
    }
}

// --- Lógica para Actualizar/Gestionar Usuario Existente (AHORA INCLUYE USERNAME Y TELEGRAM_CHAT_ID) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'manage_user') {
    $manage_user_id = $_POST['user_id'] ?? null;
    $manage_role = $_POST['role'] ?? null;
    $manage_is_blocked = isset($_POST['is_blocked']) ? 1 : 0;
    $manage_allowed_entities = trim($_POST['allowed_entities'] ?? '');
    // AÑADIDO: Nuevos campos para editar
    $manage_username = trim($_POST['username'] ?? ''); 
    $manage_telegram_chat_id = trim($_POST['telegram_chat_id'] ?? '');

    $manage_allowed_entities = empty($manage_allowed_entities) ? NULL : $manage_allowed_entities;


    if (!$manage_user_id || !is_numeric($manage_user_id)) {
        $error_message = "ID de usuario inválido para gestionar.";
    } elseif (!in_array($manage_role, ['admin', 'user', 'marquillador'])) {
        $error_message = "Rol inválido.";
    } elseif (empty($manage_username) || empty($manage_telegram_chat_id)) { // Validación para los nuevos campos
        $error_message = "El nombre de usuario y el ID de Chat de Telegram no pueden estar vacíos.";
    } else {
        try {
            // Consulta de actualización extendida para incluir username y telegram_chat_id
            $sql = "UPDATE panel_users SET username = ?, telegram_chat_id = ?, role = ?, is_blocked = ?, allowed_entities = ?"; 
            $params = [$manage_username, $manage_telegram_chat_id, $manage_role, $manage_is_blocked, $manage_allowed_entities];

            // Si se pide resetear IP/Device ID
            if (isset($_POST['reset_ip_device'])) {
                $sql .= ", current_ip = NULL, current_device_id = NULL";
            }
            $sql .= " WHERE id = ?";
            $params[] = $manage_user_id;

            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $success_message = "Usuario ID {$manage_user_id} actualizado con éxito.";
            
            // Si el usuario actualizó su propio username, actualizar la sesión
            if ($manage_user_id == $_SESSION['user_id']) {
                $_SESSION['username'] = $manage_username;
            }

        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Código de error para entrada duplicada
                $error_message = "Error: El nombre de usuario o ID de chat de Telegram ya existe para otro usuario.";
            } else {
                $error_message = "Error de base de datos al gestionar usuario: " . $e->getMessage();
            }
        }
    }
}


// --- Lógica para Eliminar Usuario ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $delete_user_id = $_POST['user_id'] ?? null;

    if (!$delete_user_id || !is_numeric($delete_user_id)) {
        $error_message = "ID de usuario inválido para eliminar.";
    } else {
        // PRECAUCIÓN: No permitir que un admin se elimine a sí mismo
        if ($delete_user_id == $_SESSION['user_id']) {
            $error_message = "No puedes eliminar tu propia cuenta.";
        } else {
            try {
                $stmt = $db->prepare("DELETE FROM panel_users WHERE id = ?");
                $stmt->execute([$delete_user_id]);
                if ($stmt->rowCount() > 0) {
                    $success_message = "Usuario ID {$delete_user_id} eliminado con éxito.";
                } else {
                    $error_message = "No se pudo eliminar el usuario ID {$delete_user_id}. Posiblemente no existe.";
                }
            } catch (PDOException $e) {
                $error_message = "Error de base de datos al eliminar usuario: " . $e->getMessage();
            }
        }
    }
}


// --- Obtener Lista de Usuarios para Mostrar (con filtro de búsqueda) ---
$users = [];
// NOTA: search_term_filter y filter_role se obtienen de $_GET para que persistan en la URL
$search_term_filter = trim($_GET['search_term'] ?? ''); // Lee de GET para la búsqueda
$filter_role = trim($_GET['filter_role'] ?? ''); // Lee de GET para el filtro de rol


$sql_users = "SELECT id, username, telegram_chat_id, role, current_ip, is_blocked, last_login_at, created_at, allowed_entities FROM panel_users";
$params_users = [];
$conditions_users = [];

if (!empty($search_term_filter)) {
    $conditions_users[] = " (username LIKE ? OR telegram_chat_id LIKE ?) ";
    $params_users[] = '%' . $search_term_filter . '%';
    $params_users[] = '%' . $search_term_filter . '%';
}

if (!empty($filter_role)) {
    $conditions_users[] = " role = ? ";
    $params_users[] = $filter_role;
}

if (!empty($conditions_users)) {
    $sql_users .= " WHERE " . implode(" AND ", $conditions_users);
}

$sql_users .= " ORDER BY id ASC";

try {
    $stmt = $db->prepare($sql_users);
    $stmt->execute($params_users);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error al cargar usuarios: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Usuarios del Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; margin: 0; padding: 0; color: #333; }
        .main-content-container {
            max-width: 1200px;
            margin: 15px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        /* Estilos de la barra de navegación superior (Navbar) - Adaptados del dashboard.php */
        .top-navbar {
            background-color: #004080;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            margin-bottom: 15px;
        }

        .navbar-brand {
            font-size: 22px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .navbar-controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Dropdown de usuario - Estilos reutilizados del dashboard.php */
        .dropdown-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        .dropdown-toggle {
            color: white;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9em;
        }
        .dropdown-toggle:hover { text-decoration: underline; }
        .dropdown-toggle i {
            font-size: 0.7em;
            transition: transform 0.2s ease;
        }
        .dropdown-container.show .dropdown-toggle i {
            transform: rotate(180deg);
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: #fff;
            min-width: 180px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 100;
            border-radius: 5px;
            right: 0;
            top: 100%;
            margin-top: 5px;
            border: 1px solid #ddd;
        }
        .dropdown-menu a {
            color: #333;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
            text-align: left;
            transition: background-color 0.2s ease;
        }
        .dropdown-menu a:hover { background-color: #f1f1f1; }
        .dropdown-menu a i { margin-right: 8px; color: #007bff; }
        .dropdown-container.show .dropdown-menu { display: block; }

        /* Estilos generales de la página (alertas, formularios, tablas) */
        /* Contenedor para el título principal y el botón de volver */
        .page-header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #eee;
        }
        .page-header-container h1 {
            flex-grow: 1;
            text-align: center;
            margin: 0;
            color: #004080;
            font-size: 1.8em;
            padding-bottom: 0;
            border-bottom: none;
        }
        /* Ajuste para el botón dentro del contenedor */
        .page-header-container .back-to-dashboard-btn {
            margin-bottom: 0;
            flex-shrink: 0;
        }

        h2 { /* Estilos para subtítulos de sección */
            color: #004080;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
            margin-bottom: 10px;
            font-size: 1.1em; /* Ajustado a 1.1em, más pequeño aún */
            text-align: left;
        }

        .alert { padding: 10px; margin-bottom: 15px; border-radius: 5px; font-weight: bold; font-size: 0.9em; }
        .alert.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

        .form-section, .table-section { margin-bottom: 20px; }
        
        /* REDISEÑO FORMULARIO CREAR USUARIO */
        .form-create-user {
            display: grid;
            /* Reorganización de columnas para Rol y Botón */
            grid-template-columns: 120px 1fr 100px auto; /* label | input | rol select | button */
            gap: 8px 10px;
            align-items: center;
            max-width: 800px; /* Mantener un ancho razonable */
            margin: 0 auto 15px auto;
            padding: 15px;
            background-color: #fbfbfb;
            border: 1px solid #eee;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            font-size: 0.9em;
        }
        .form-create-user .form-group {
            margin-bottom: 0;
            display: contents;
        }
        /* Posicionamiento específico de Rol y Botón en el Grid */
        .form-create-user .form-group:nth-of-type(3) label { /* Label del Rol */
            grid-column: 1 / 2; /* Columna de labels */
        }
        .form-create-user .form-group:nth-of-type(3) select { /* Select del Rol */
            grid-column: 2 / 3; /* Columna de inputs */
        }
        .form-create-user .create-user-button-container {
            grid-column: 3 / -1; /* Ocupa las columnas del rol select y del botón */
            display: flex;
            justify-content: flex-start; /* Alinea el botón a la izquierda en su celda */
            align-items: center;
            gap: 10px; /* Espacio entre el select de rol y el botón, si están en la misma línea */
        }
        .form-create-user .create-user-button-container button {
            padding: 7px 12px;
            font-size: 0.9em;
        }

        .form-create-user label {
            text-align: right;
            font-weight: bold;
            margin-right: 0;
            font-size: 0.9em;
        }
        .form-create-user input[type="text"],
        .form-create-user select {
            width: 100%;
            padding: 6px 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            max-width: unset;
            font-size: 0.9em;
        }
        .form-create-user small {
            grid-column: 2 / 3;
            font-size: 0.75em;
            color: #666;
            margin-top: -3px;
            margin-bottom: 5px;
        }
        
        /* Contenedor de búsqueda y filtro (separado ahora) */
        .table-controls {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between; /* Distribuye el h2 y el grupo de búsqueda */
            align-items: center;
            margin-bottom: 15px; /* Espacio antes de la tabla */
            padding: 10px 15px; /* Padding para el nuevo contenedor */
            background-color: #fbfbfb;
            border: 1px solid #eee;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .table-controls h2 {
            flex-grow: 1; /* Permite al h2 ocupar el espacio */
            text-align: left; /* Alinea el h2 a la izquierda */
            margin: 0; /* Elimina márgenes por defecto */
            border-bottom: none; /* Elimina borde inferior duplicado */
            padding-bottom: 0; /* Elimina padding inferior duplicado */
        }
        .search-filter-group { /* Grupo que contiene los campos de búsqueda y filtro de rol */
            display: flex;
            align-items: center;
            gap: 8px;
            flex-grow: 1; /* Permite que el grupo crezca */
            justify-content: flex-end; /* Alinea los elementos a la derecha dentro de su grupo */
            max-width: 550px; /* Ancho máximo para el grupo de búsqueda/filtro */
        }
        .search-filter-group label {
            font-size: 0.9em;
            font-weight: bold;
            color: #555;
            white-space: nowrap;
        }
        .search-filter-group input[type="text"] {
            flex-grow: 1;
            padding: 6px 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.85em;
            max-width: 180px;
        }
        .search-filter-group select {
            flex-grow: 1;
            padding: 6px 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.85em;
            max-width: 120px;
        }
        .search-filter-group button {
            padding: 7px 12px;
            font-size: 0.85em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
            background-color: #007bff; /* Color para el botón de búsqueda/limpiar */
            color: white;
        }
        .search-filter-group button:hover {
            background-color: #0056b3;
        }
        .search-filter-group button.clear-search-btn {
            background-color: #6c757d;
        }
        .search-filter-group button.clear-search-btn:hover {
            background-color: #5a6268;
        }


        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 10px 12px; border: 1px solid #eee; text-align: left; font-size: 0.85em; }
        th { background-color: #f0f0f0; font-weight: bold; color: #555; }
        tr:nth-child(even) { background-color: #f9f9f9; }

        /* Estilos para la columna de acciones (REDISEÑADO) */
        td.actions-column {
            white-space: normal;
            vertical-align: top;
        }
        
        td.actions-column form {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            align-items: center;
            margin-bottom: 8px;
            padding: 4px;
            border: 1px solid #f0f0f0;
            border-radius: 5px;
            background-color: #fdfdfd;
        }

        td.actions-column form label {
            font-size: 0.8em;
            color: #666;
            margin: 0;
            flex-basis: 100%;
            text-align: left;
            font-weight: normal;
        }
        
        td.actions-column select {
            flex-grow: 1;
            min-width: 80px;
            max-width: 120px;
            padding: 4px 6px;
            font-size: 0.8em;
            height: auto;
            margin-bottom: 0;
        }
        
        td.actions-column input[type="text"] {
            flex-grow: 1;
            padding: 4px 6px;
            font-size: 0.8em;
            height: auto;
            min-width: 60px;
            box-sizing: border-box;
        }

        /* Checkboxes en línea */
        td.actions-column .checkbox-group {
            display: flex;
            align-items: center;
            gap: 3px;
            flex-basis: 100%;
            margin-bottom: 3px;
            font-size: 0.8em;
        }
        td.actions-column label input[type="checkbox"] {
            margin: 0;
            vertical-align: middle;
            width: auto;
            height: auto;
        }
        td.actions-column .checkbox-group label {
            font-size: 1em;
            color: #333;
            font-weight: normal;
            flex-basis: auto;
        }

        td.actions-column textarea {
            width: 100%;
            padding: 4px 6px;
            border-radius: 4px;
            border: 1px solid #ddd;
            box-sizing: border-box;
            min-height: 30px;
            resize: vertical;
            font-size: 0.8em;
            margin-bottom: 5px;
        }
        
        /* Botones dentro del formulario de acciones */
        td.actions-column button { 
            width: auto;
            flex-grow: 1;
            padding: 5px 8px;
            font-size: 0.8em;
            border-radius: 4px;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 3px;
            white-space: nowrap;
        }

        td button.update-btn { background-color: #28a745; color: white; }
        td button.update-btn:hover { background-color: #218838; }
        td button.delete-btn { background-color: #dc3545; color: white; }
        td button.delete-btn:hover { background-color: #c82333; }
        td button.reset-btn { background-color: #ffc107; color: black; }
        td button.reset-btn:hover { background-color: #e0a800; }
        td span.status-blocked { color: red; font-weight: bold; }
        td span.status-active { color: green; font-weight: bold; }

        /* Botón Volver al Dashboard (ajuste para flexbox) */
        .back-to-dashboard-btn {
            display: inline-flex;
            align-items: center;
            background-color: #6c757d;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            margin-bottom: 0;
            transition: background-color 0.3s ease;
            font-size: 0.9em;
            gap: 5px;
        }
        .back-to-dashboard-btn:hover { background-color: #5a6268; }


        /* Media Queries para Responsividad */
        @media (max-width: 768px) {
            .top-navbar {
                padding: 10px 15px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .navbar-brand { font-size: 20px; }
            .navbar-controls {
                width: 100%;
                justify-content: flex-end;
                gap: 10px;
            }
            .dropdown-menu { left: 0; right: auto; }

            .main-content-container {
                padding: 15px;
                margin: 15px auto;
            }
            /* Encabezado en móvil */
            .page-header-container {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .page-header-container h1 {
                text-align: left;
                font-size: 1.5em;
            }
            .page-header-container .back-to-dashboard-btn {
                width: 100%;
                justify-content: center;
            }
            
            h2 { text-align: center; font-size: 1.2em;}
            
            /* Formulario de creación en móvil */
            .form-create-user {
                grid-template-columns: 1fr; /* Una sola columna para inputs en móvil */
                padding: 15px;
            }
            .form-create-user label { text-align: left; }
            .form-create-user small { grid-column: 1 / -1; }
            /* Acciones y búsqueda en móvil (dentro del mismo formulario) */
            .form-create-user .form-actions-search {
                flex-direction: column;
                align-items: stretch;
            }
            .form-create-user .form-actions-search .action-group {
                flex-direction: column;
                width: 100%;
            }
            .form-create-user .form-actions-search input[type="text"],
            .form-create-user .form-actions-search select,
            .form-create-user .form-actions-search button {
                width: 100%;
            }


            table, thead, tbody, th, td, tr { display: block; }
            thead tr { position: absolute; top: -9999px; left: -9999px; }
            tr { border: 1px solid #ccc; margin-bottom: 10px; }
            
            td { 
                border: none; 
                border-bottom: 1px solid #eee; 
                position: relative; 
                padding-left: 50% !important; 
                text-align: left; 
            }
            td:last-child { border-bottom: 0; }
            
            td:before { 
                content: attr(data-label); 
                position: absolute; 
                left: 0; 
                width: 45%; 
                padding-right: 10px; 
                white-space: nowrap; 
                text-align: left; 
                font-weight: bold; 
            }
            
            /* Ajustes para las celdas de acciones en móvil */
            td.actions-column {
                text-align: left;
                flex-wrap: wrap;
                gap: 5px;
                min-width: unset;
            }
            td.actions-column form {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
            }
            td.actions-column form label { flex-basis: auto; text-align: left; }
            td.actions-column select,
            td.actions-column input[type="text"],
            td.actions-column textarea,
            td.actions-column button { 
                width: 100%;
                max-width: unset;
                min-width: unset;
                box-sizing: border-box;
                margin-bottom: 5px;
            }
            td.actions-column .checkbox-group {
                flex-direction: row;
                justify-content: flex-start;
                width: 100%;
            }

            .back-to-dashboard-btn { width: 100%; text-align: center; }
        }
    </style>
</head>
<body>
    <nav class="top-navbar">
        <a href="dashboard_a.php" class="navbar-brand">Panel de Administración</a>
        <div class="navbar-controls">
            <div class="dropdown-container" id="userDropdown">
                <span class="dropdown-toggle">
                    Bienvenido: <strong><?php echo htmlspecialchars($username_admin); ?></strong>
                    (Rol: Admin)
                    <i class="fas fa-chevron-down"></i>
                </span>
                <div class="dropdown-menu">
                    <a href="admin_users.php"><i class="fas fa-users-cog"></i> Administrar Usuarios</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="main-content-container">
        <div class="page-header-container">
            <a href="dashboard_a.php" class="back-to-dashboard-btn"><i class="fas fa-arrow-left"></i> Volver al Dashboard</a>
            <h1>Administración de Usuarios del Panel</h1>
            <div></div> </div>

        <?php if ($error_message): ?>
            <div class="alert error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <div class="alert success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <div class="form-section">
            <h2>Crear Nuevo Usuario</h2>
            <form action="admin_users.php" method="POST" class="form-create-user" id="main-admin-form">
                <div class="form-group">
                    <label for="new_username">Nombre de Usuario:</label>
                    <input type="text" id="new_username" name="new_username" required value="<?php echo htmlspecialchars(isset($new_username) ? $new_username : ''); ?>">
                </div>
                <div class="form-group">
                    <label for="new_telegram_chat_id">ID de Chat Telegram:</label>
                    <input type="text" id="new_telegram_chat_id" name="new_telegram_chat_id" required value="<?php echo htmlspecialchars(isset($new_telegram_chat_id) ? $new_telegram_chat_id : ''); ?>">
                    <small>(Asegúrate de que el usuario envíe un mensaje a tu bot para obtener este ID)</small>
                </div>
                <div class="form-group">
                    <label for="new_role">Rol:</label>
                    <select id="new_role" name="new_role">
                        <option value="user" <?php echo (isset($new_role) && $new_role === 'user') ? 'selected' : ''; ?>>Usuario Normal</option>
                        <option value="admin" <?php echo (isset($new_role) && $new_role === 'admin') ? 'selected' : ''; ?>>Administrador</option>
                        <option value="marquillador" <?php echo (isset($new_role) && $new_role === 'marquillador') ? 'selected' : ''; ?>>Marquillador</option>
                    </select>
                </div>
                <div class="create-user-button-container"> <button type="submit" name="action" value="create_user" class="create-btn"><i class="fas fa-user-plus"></i> Crear Usuario</button>
                </div>
            </form>
        </div>

        <div class="table-section">
            <div class="table-controls"> <h2>Usuarios Existentes</h2>
                <div class="search-filter-group">
                    <label for="search-term-filter">Buscar:</label>
                    <input type="text" name="search_term" id="search-term-filter" placeholder="Usuario o ID de Telegram" value="<?php echo htmlspecialchars($search_term_filter); ?>" oninput="performUserSearch()">
                    
                    <label for="filter-role">Rol:</label>
                    <select name="filter_role" id="filter-role" onchange="performUserSearch()">
                        <option value="">Todos</option>
                        <option value="user" <?php echo ($filter_role === 'user') ? 'selected' : ''; ?>>Usuario</option>
                        <option value="admin" <?php echo ($filter_role === 'admin') ? 'selected' : ''; ?>>Admin</option>
                        <option value="marquillador" <?php echo ($filter_role === 'marquillador') ? 'selected' : ''; ?>>Marquillador</option>
                    </select>
                    
                    <?php if (!empty($search_term_filter) || !empty($filter_role)): ?>
                        <button type="button" onclick="clearAndPerformSearch()" class="clear-search-btn"><i class="fas fa-times"></i> Limpiar Filtros</button>
                    <?php endif; ?>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuario</th>
                        <th>ID Chat Telegram</th>
                        <th>Rol</th>
                        <th>IP Actual</th>
                        <th>Bloqueado</th>
                        <th>Último Login</th>
                        <th>Creación</th>
                        <th>Entidades Permitidas</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr><td colspan="10" style="text-align: center;">No hay usuarios de panel registrados que coincidan con la búsqueda.</td></tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td data-label="ID"><?php echo htmlspecialchars($user['id']); ?></td>
                                <td data-label="Usuario">
                                    <input type="text" form="manage_form_<?php echo $user['id']; ?>" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                </td>
                                <td data-label="ID Chat Telegram">
                                    <input type="text" form="manage_form_<?php echo $user['id']; ?>" name="telegram_chat_id" value="<?php echo htmlspecialchars($user['telegram_chat_id']); ?>" required>
                                </td>
                                <td data-label="Rol"><?php echo htmlspecialchars($user['role']); ?></td>
                                <td data-label="IP Actual"><?php echo htmlspecialchars(isset($user['current_ip']) ? $user['current_ip'] : 'N/A'); ?></td>
                                <td data-label="Bloqueado">
                                    <?php if ($user['is_blocked']): ?>
                                        <span class="status-blocked"><i class="fas fa-lock"></i> SÍ</span>
                                    <?php else: ?>
                                        <span class="status-active"><i class="fas fa-unlock"></i> NO</span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Último Login"><?php echo htmlspecialchars(isset($user['last_login_at']) ? $user['last_login_at'] : 'N/A'); ?></td>
                                <td data-label="Creación"><?php echo htmlspecialchars($user['created_at']); ?></td>
                                <td data-label="Entidades Permitidas">
                                    <textarea form="manage_form_<?php echo $user['id']; ?>" name="allowed_entities" rows="2" placeholder="Ej: Entidad A, Entidad B"><?php echo htmlspecialchars($user['allowed_entities'] ?? ''); ?></textarea>
                                </td>
                                <td data-label="Acciones" class="actions-column">
                                    <form id="manage_form_<?php echo $user['id']; ?>" action="admin_users.php" method="POST">
                                        <input type="hidden" name="action" value="manage_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        
                                        <label>Rol:</label>
                                        <select name="role">
                                            <option value="user" <?php echo ($user['role'] === 'user') ? 'selected' : ''; ?>>Usuario</option>
                                            <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                            <option value="marquillador" <?php echo ($user['role'] === 'marquillador') ? 'selected' : ''; ?>>Marquillador</option>
                                        </select>
                                        
                                        <div class="checkbox-group">
                                            <input type="checkbox" name="is_blocked" value="1" id="is_blocked_<?php echo $user['id']; ?>" <?php echo $user['is_blocked'] ? 'checked' : ''; ?>>
                                            <label for="is_blocked_<?php echo $user['id']; ?>">Bloquear Usuario</label>
                                        </div>
                                        
                                        <div class="checkbox-group">
                                            <input type="checkbox" name="reset_ip_device" value="1" id="reset_ip_device_<?php echo $user['id']; ?>">
                                            <label for="reset_ip_device_<?php echo $user['id']; ?>">Resetear IP/Dispositivo</label>
                                        </div>
                                        
                                        <button type="submit" class="update-btn" title="Actualizar Usuario"><i class="fas fa-save"></i> Guardar Cambios</button>
                                    </form>
                                    <form action="admin_users.php" method="POST" onsubmit="return confirm('¿Estás seguro de que quieres eliminar a <?php echo htmlspecialchars($user['username']); ?>? Esta acción es irreversible.');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="delete-btn" title="Eliminar Usuario" <?php echo ($user['id'] == $_SESSION['user_id']) ? 'disabled' : ''; ?>><i class="fas fa-trash-alt"></i> Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Lógica para el menú desplegable de usuario (reutilizado del dashboard)
        document.addEventListener('DOMContentLoaded', function() {
            const userDropdown = document.getElementById('userDropdown');
            const dropdownToggle = userDropdown.querySelector('.dropdown-toggle');
            const dropdownMenu = userDropdown.querySelector('.dropdown-menu');

            dropdownToggle.addEventListener('click', function() {
                userDropdown.classList.toggle('show');
            });

            // Cerrar el dropdown si se hace clic fuera de él
            window.addEventListener('click', function(event) {
                if (!userDropdown.contains(event.target)) {
                    userDropdown.classList.remove('show');
                }
            });
        });

        // Función para la búsqueda en tiempo real de usuarios y filtros de rol
        let searchTimeout;
        function performUserSearch() {
            clearTimeout(searchTimeout); // Limpiar el timeout anterior
            searchTimeout = setTimeout(() => {
                const searchInput = document.getElementById('search-term-filter');
                const roleFilter = document.getElementById('filter-role');
                
                const newUrl = new URL(window.location.href);
                // Establecer parámetros GET para la búsqueda y el filtro de rol
                if (searchInput.value) {
                    newUrl.searchParams.set('search_term', searchInput.value);
                } else {
                    newUrl.searchParams.delete('search_term');
                }
                if (roleFilter.value) {
                    newUrl.searchParams.set('filter_role', roleFilter.value);
                } else {
                    newUrl.searchParams.delete('filter_role');
                }
                window.location.href = newUrl.toString(); // Recargar la página con la nueva URL
                
            }, 300); // Pequeño retraso para evitar recargas excesivas mientras se escribe
        }

        // Función para limpiar los filtros y recargar la página
        function clearAndPerformSearch() {
            document.getElementById('search-term-filter').value = '';
            document.getElementById('filter-role').value = '';
            performUserSearch(); // Llama a la función de búsqueda para aplicar los filtros vacíos
        }

        // Asegurarse de que los campos de filtro se mantengan con su valor después de la recarga
        document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const searchTermFromUrl = urlParams.get('search_term');
            const filterRoleFromUrl = urlParams.get('filter_role');

            if (searchTermFromUrl) {
                document.getElementById('search-term-filter').value = searchTermFromUrl;
            }
            if (filterRoleFromUrl) {
                document.getElementById('filter-role').value = filterRoleFromUrl;
            }
        });

    </script>

</body>
</html>