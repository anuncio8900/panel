<?php
require_once 'db.php';

$stmt = $db->query("SELECT MAX(id) as max_id FROM registros");
$data = $stmt->fetch(PDO::FETCH_ASSOC);
echo json_encode(['ultimo_id' => intval($data['max_id'])]);
