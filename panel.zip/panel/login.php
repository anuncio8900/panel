<?php
// panel/login.php
date_default_timezone_set('America/Bogota'); // Establecer la zona horaria
session_start(); // Inicia la sesión al principio

// Incluir tu archivo de conexión a la base de datos (db.php)
require_once 'db.php'; // Usa tu $db de db.php
require_once 'telegram_api.php'; // La nueva función para Telegram

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && !isset($_POST['otp'])) {
        // --- Paso 1: El usuario envía solo el username ---
        $username = trim($_POST['username']); // Usar trim para limpiar espacios

        $stmt = $db->prepare("SELECT id, telegram_chat_id, is_blocked FROM panel_users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($user['is_blocked']) {
                $error_message = "Tu cuenta ha sido bloqueada. Contacta al administrador.";
            } else {
                // Generar OTP
                $otp_code = strval(rand(100000, 999999));
                $expires_at = date('Y-m-d H:i:s', strtotime('+5 minutes'));

                // Eliminar OTPs anteriores para este usuario (buena práctica de limpieza)
                $stmt_del = $db->prepare("DELETE FROM otp_codes WHERE user_id = ?");
                $stmt_del->execute([$user['id']]);

                $stmt_insert_otp = $db->prepare("INSERT INTO otp_codes (user_id, otp_code, expires_at) VALUES (?, ?, ?)");
                if ($stmt_insert_otp->execute([$user['id'], $otp_code, $expires_at])) {
                    $message_text = "Tu código OTP para acceder al panel es: <b>" . $otp_code . "</b>. Válido por 5 minutos.";
                    if (sendTelegramMessage($user['telegram_chat_id'], $message_text)) {
                        $_SESSION['pending_login_user_id'] = $user['id'];
                        $success_message = "Se ha enviado un código OTP a tu Telegram. Por favor, introdúcelo para continuar.";
                    } else {
                        $error_message = "Error al enviar el OTP a Telegram. Intenta de nuevo más tarde.";
                        // Si el envío falla, limpiar el OTP de la DB también
                        $stmt_del_fail = $db->prepare("DELETE FROM otp_codes WHERE user_id = ? AND otp_code = ?");
                        $stmt_del_fail->execute([$user['id'], $otp_code]);
                    }
                } else {
                    $error_message = "Error al generar el OTP. Intenta de nuevo.";
                }
            }
        } else {
            $error_message = "Usuario no encontrado.";
        }

    } elseif (isset($_POST['otp']) && isset($_SESSION['pending_login_user_id'])) {
        // --- Paso 2: El usuario envía el OTP ---
        $otp_entered = trim($_POST['otp']);
        $user_id = $_SESSION['pending_login_user_id'];

        $stmt = $db->prepare("SELECT otp_code, expires_at FROM otp_codes WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$user_id]);
        $otp_record = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($otp_record && $otp_record['otp_code'] === $otp_entered && strtotime($otp_record['expires_at']) > time()) {
            // OTP válido
            unset($_SESSION['pending_login_user_id']); // Limpiar ID temporal de la sesión

            // Obtener datos completos del usuario para la sesión y validar IP/Dispositivo
            $stmt_user_data = $db->prepare("SELECT id, username, role, current_ip, current_device_id FROM panel_users WHERE id = ?");
            $stmt_user_data->execute([$user_id]);
            $user_data = $stmt_user_data->fetch(PDO::FETCH_ASSOC);

            $current_ip = $_SERVER['REMOTE_ADDR'];
            $new_device_id = session_id(); // Usar el ID de sesión de PHP como un identificador de dispositivo simple

            // Lógica de validación de IP única
            if ($user_data['current_ip'] !== null && $user_data['current_ip'] !== $current_ip) {
                // Se detectó IP diferente, bloquear y alertar
                $stmt_block = $db->prepare("UPDATE panel_users SET is_blocked = TRUE, current_ip = NULL, current_device_id = NULL WHERE id = ?"); // Limpiar también device_id
                $stmt_block->execute([$user_id]);

                $stmt_admin = $db->prepare("SELECT telegram_chat_id FROM panel_users WHERE role = 'admin' LIMIT 1");
                $stmt_admin->execute();
                $admin_chat_id = $stmt_admin->fetchColumn();

                if ($admin_chat_id) {
                    $alert_message = "ALERTA DE SEGURIDAD: Usuario <b>{$user_data['username']}</b> (ID: {$user_data['id']}) ha sido <b>BLOQUEADO</b>.<br>Se detectó un intento de inicio de sesión desde una IP diferente: <b>{$current_ip}</b> (IP anterior: <b>{$user_data['current_ip']}</b>).";
                    sendTelegramMessage($admin_chat_id, $alert_message);
                }
                session_destroy(); // Destruir la sesión por completo
                $error_message = "Acceso denegado: Se detectó un inicio de sesión desde una IP diferente. Tu cuenta ha sido bloqueada. Contacta al administrador.";

            // NUEVA LÓGICA DE VALIDACIÓN POR DISPOSITIVO
            } elseif ($user_data['current_device_id'] !== null && $user_data['current_device_id'] !== $new_device_id) {
                // Se detectó un ID de dispositivo diferente, bloquear y alertar
                $stmt_block = $db->prepare("UPDATE panel_users SET is_blocked = TRUE, current_ip = NULL, current_device_id = NULL WHERE id = ?"); // Limpiar ambos
                $stmt_block->execute([$user_id]);

                $stmt_admin = $db->prepare("SELECT telegram_chat_id FROM panel_users WHERE role = 'admin' LIMIT 1");
                $stmt_admin->execute();
                $admin_chat_id = $stmt_admin->fetchColumn();

                if ($admin_chat_id) {
                    $alert_message = "ALERTA DE SEGURIDAD: Usuario <b>{$user_data['username']}</b> (ID: {$user_data['id']}) ha sido <b>BLOQUEADO</b>.<br>Se detectó un intento de inicio de sesión desde un DISPOSITIVO diferente. (ID Dispositivo anterior: <b>{$user_data['current_device_id']}</b>).";
                    sendTelegramMessage($admin_chat_id, $alert_message);
                }
                session_destroy();
                $error_message = "Acceso denegado: Se detectó un inicio de sesión desde un dispositivo diferente. Tu cuenta ha sido bloqueada. Contacta al administrador.";

            } else {
                // Autenticación exitosa y IP/Dispositivo válidos, establecer sesión
                $_SESSION['user_id'] = $user_data['id'];
                $_SESSION['username'] = $user_data['username'];
                $_SESSION['role'] = $user_data['role'];
                $_SESSION['last_activity'] = time(); // Para control de inactividad
                $_SESSION['device_id'] = $new_device_id; // Guardar el device_id en la sesión

                // Actualizar la IP actual, Device ID y la marca de tiempo del último login
                $stmt_update_login = $db->prepare("UPDATE panel_users SET current_ip = ?, current_device_id = ?, last_login_at = ? WHERE id = ?");
                $stmt_update_login->execute([$current_ip, $new_device_id, date('Y-m-d H:i:s'), $user_id]);

                // Eliminar el OTP usado
                $stmt_del_otp = $db->prepare("DELETE FROM otp_codes WHERE user_id = ? AND otp_code = ?");
                $stmt_del_otp->execute([$user_id, $otp_entered]);

                // *** CAMBIO CRÍTICO AQUÍ: REDIRIGIR A index.php ***
                header("Location: index.php"); // Redirigir a index.php para que maneje la redirección por rol
                exit();
            }

        } else {
            $error_message = "Código OTP inválido o expirado.";
            // Opcional: registrar intento fallido en logs
        }
    } else {
        $error_message = "Solicitud inválida.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login al Panel</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-container { background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        input[type="text"], input[type="submit"] { width: calc(100% - 20px); padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; }
        input[type="submit"] { background-color: #007bff; color: white; cursor: pointer; border: none; }
        input[type="submit"]:hover { background-color: #0056b3; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Acceso al Panel</h1>
        <?php if ($error_message): ?>
            <p class="message error"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <p class="message success"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <?php if (!isset($_SESSION['pending_login_user_id'])): ?>
        <form method="POST">
            <label for="username">Usuario:</label><br>
            <input type="text" id="username" name="username" required autocomplete="username"><br><br>
            <input type="submit" value="Obtener Código de Telegram">
        </form>
        <?php else: ?>
        <form method="POST">
            <p>Introduce el código OTP enviado a tu Telegram:</p>
            <label for="otp">Código OTP:</label><br>
            <input type="text" id="otp" name="otp" required autocomplete="one-time-code"><br><br>
            <input type="submit" value="Verificar Código">
        </form>
        <?php endif; ?>
    </div>
</body>
</html>