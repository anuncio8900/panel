<?php
require_once 'db.php';

$stmt = $db->query("SELECT * FROM registros ORDER BY created_at DESC");
$registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($registros as $row) {
    echo "<tr>";
    echo "<td>{$row['id']}</td>";
    echo "<td>" . htmlspecialchars($row['usuario']) . "</td>";
    echo "<td>{$row['ip']}</td>";
    echo "<td>{$row['fecha']}</td>";
    echo "<td>{$row['hora']}</td>";
    echo "<td>" . htmlspecialchars($row['navegador']) . "</td>";
    echo "<td>{$row['sistema_operativo']}</td>";
    echo "<td>{$row['estado_envio']}</td>";
    echo "<td>{$row['created_at']}</td>";
    echo "</tr>";
}
