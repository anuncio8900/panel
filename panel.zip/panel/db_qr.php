<?php
// panel/db_qr.php (NUEVO ARCHIVO - CONTIENE LA FUNCI�0�7N connectDB() PARA EL QR)

function connectDB() {
    $host = 'localhost'; // O '127.0.0.1'
    $dbname = 'espacove_general';
    $username = 'espacove_pollo';
    $password = 'Colombia123@.';

    try {
        $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->exec("SET time_zone = '-05:00'");
        return $db; // La funci��n devuelve el objeto PDO de conexi��n
    } catch (PDOException $e) {
        // En caso de error de conexi��n, se detiene la ejecuci��n y se devuelve un JSON de error
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            "status" => "ERROR",
            "message" => "Error de conexi��n a la base de datos (db_qr.php)",
            "detail" => $e->getMessage()
        ]);
        exit;
    }
}
?>