<?php
// panel/export_data.php
date_default_timezone_set('America/Bogota');
session_start();

// Incluir la conexión a la base de datos
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Obtener filtros
$search_term = $_GET['search_term'] ?? '';
$filter_status = $_GET['filter_status'] ?? '';
$filter_operador = $_GET['filter_operador'] ?? '';
$filter_entidad = $_GET['filter_entidad'] ?? '';

$sql_select = "SELECT * FROM registros";
$sql_where = [];
$params = [];

if (!empty($search_term)) {
    if (is_numeric($search_term)) {
        $sql_where[] = "(usuario LIKE ? OR id = ?)";
        $params[] = '%' . $search_term . '%';
        $params[] = $search_term;
    } else {
        $sql_where[] = "usuario LIKE ?";
        $params[] = '%' . $search_term . '%';
    }
}

if (!empty($filter_status)) {
    $sql_where[] = "status = ?";
    $params[] = $filter_status;
}

if (!empty($filter_operador)) {
    $sql_where[] = "operador = ?";
    $params[] = $filter_operador;
}

if (!empty($filter_entidad)) {
    $sql_where[] = "entidad = ?";
    $params[] = $filter_entidad;
}

$current_user_role = $_SESSION['role'] ?? 'guest';
$current_user_id = $_SESSION['user_id'] ?? null;

if ($current_user_role === 'user' && $current_user_id) {
    $stmt_user_entities = $db->prepare("SELECT allowed_entities FROM panel_users WHERE id = ?");
    $stmt_user_entities->execute([$current_user_id]);
    $allowed_entities_str = $stmt_user_entities->fetchColumn();
    
    $allow_all_entities = false;
    if ($allowed_entities_str !== null) {
        $trimmed_str = trim($allowed_entities_str);
        if ($trimmed_str === '*' || $trimmed_str === '') {
            $allow_all_entities = true;
        }
    }

    if (!$allow_all_entities) {
        if (!empty($allowed_entities_str)) {
            $allowed_entities_array = explode(',', $allowed_entities_str);
            $clean_allowed_entities = array_map('trim', $allowed_entities_array);
            $clean_allowed_entities = array_filter($clean_allowed_entities);

            if (!empty($clean_allowed_entities)) {
                $placeholders = implode(',', array_fill(0, count($clean_allowed_entities), '?'));
                $sql_where[] = "entidad IN ($placeholders)";
                $params = array_merge($params, $clean_allowed_entities);
            } else {
                $sql_where[] = "1 = 0";
            }
        } else {
            $sql_where[] = "1 = 0";
        }
    }
}

if (!empty($sql_where)) {
    $sql_select .= " WHERE " . implode(" AND ", $sql_where);
}
$sql_select .= " ORDER BY id DESC";

try {
    $stmt = $db->prepare($sql_select);
    $stmt->execute($params);
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $filename = "registros_exportados_" . date('Ymd_His') . ".csv";

    // Forzar Excel con punto y coma como delimitador
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: public");
    header("Expires: 0");

    $output = fopen("php://output", "w");

    // BOM para UTF-8
    fputs($output, "\xEF\xBB\xBF");

    if (!empty($registros)) {
        $headers = array_keys($registros[0]);
        $formatted_headers = array_map(function($header) {
            return ucwords(str_replace('_', ' ', $header));
        }, $headers);
        fputcsv($output, $formatted_headers, ";");

        foreach ($registros as $row) {
            fputcsv($output, $row, ";");
        }
    } else {
        fputcsv($output, ['No hay registros para exportar'], ";");
    }

    fclose($output);
    exit();

} catch (PDOException $e) {
    error_log("Error al exportar datos: " . $e->getMessage());
    $_SESSION['message'] = "Error al exportar registros: " . htmlspecialchars($e->getMessage());
    header("Location: dashboard_a.php");
    exit();
}
?>
