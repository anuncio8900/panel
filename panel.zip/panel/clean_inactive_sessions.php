<?php
// panel/clean_inactive_sessions.php
// Este script debe ser ejecutado por una tarea cron en el servidor.
// panel/clean_inactive_sessions.php
// Este script debe ser ejecutado por una tarea cron en el servidor,
// o directamente en el navegador para depuración.

date_default_timezone_set('America/Bogota'); // Asegura la zona horaria correcta para los cálculos de tiempo.

// Habilitar display_errors para ver la salida en el navegador (SOLO PARA DEPURACIÓN TEMPORAL)


// Incluir la conexión a la base de datos
require_once 'db.php'; // Asegúrate de que esta ruta sea correcta para acceder a $db

// Definir el umbral de inactividad
// Usuarios cuya 'last_login_at' sea más antigua que este umbral serán considerados inactivos.
// Si el cron se ejecuta cada 1 minuto, un umbral de 2 minutos es un buen punto de partida.
// Esto da un margen para que los pings de 5 segundos se actualicen.
$inactivity_threshold_minutes = 1; // 2 minutos de inactividad
$inactive_time = date('Y-m-d H:i:s', strtotime("-$inactivity_threshold_minutes minutes"));

try {
    // Buscar usuarios que no estén bloqueados (is_blocked = FALSE)
    // y que estén inactivos (es decir, tienen una IP o Device ID registrados,
    // pero su last_login_at es anterior al umbral de inactividad).
    $stmt = $db->prepare("
        UPDATE panel_users
        SET 
            current_ip = NULL,
            current_device_id = NULL,
            is_blocked = FALSE
        WHERE 
            (current_ip IS NOT NULL OR current_device_id IS NOT NULL)
            AND last_login_at < ?
            AND is_blocked = FALSE; -- Importante: Solo limpiar sesiones de usuarios que NO ESTÁN BLOQUEADOS.
    ");
    $stmt->execute([$inactive_time]);

    $rows_affected = $stmt->rowCount();
    // Registrar la actividad del cron en los logs del servidor (útil para monitoreo)
    error_log("CRON JOB: Limpieza de sesiones inactivas. Sesiones limpiadas: " . $rows_affected . " en " . date('Y-m-d H:i:s'));

    // Puedes imprimir un mensaje para confirmar la ejecución si lo ejecutas manualmente desde la CLI
    echo "Limpieza de sesiones inactivas completada. Sesiones limpiadas: " . $rows_affected . "\n";

} catch (PDOException $e) {
    // Captura errores de la base de datos y los registra.
    error_log("CRON JOB ERROR: Error de base de datos en clean_inactive_sessions.php: " . $e->getMessage());
    echo "Error: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    // Captura otros errores inesperados y los registra.
    error_log("CRON JOB ERROR: Error inesperado en clean_inactive_sessions.php: " . $e->getMessage());
    echo "Error: " . $e->getMessage() . "\n";
}
?>