<?php
// panel/telegram_api.php

// Define tu token de bot de Telegram. Este token fue generado por BotFather.
define('TELEGRAM_BOT_TOKEN', '7849662156:AAHzVMHclAusUrxbF3x6C6iHca75zm2v-5k');

/**
 * Envía un mensaje de texto a un chat específico de Telegram usando la API del bot.
 *
 * @param string $chat_id El ID del chat de Telegram al que enviar el mensaje.
 * @param string $message El texto del mensaje a enviar.
 * @return bool True si el mensaje se envió correctamente, false en caso contrario.
 */
function sendTelegramMessage($chat_id, $message) {
    // La URL de la API de Telegram para enviar mensajes
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";

    // Parámetros de la solicitud POST
    $params = [
        'chat_id' => $chat_id, // El ID del chat de destino
        'text' => $message,     // El contenido del mensaje
        'parse_mode' => 'HTML'  // Permite usar etiquetas HTML básicas (como <b> para negritas)
    ];

    // Inicializa una nueva sesión cURL
    $ch = curl_init();
    // Configura la URL de la solicitud
    curl_setopt($ch, CURLOPT_URL, $url);
    // Indica que la solicitud es POST
    curl_setopt($ch, CURLOPT_POST, 1);
    // Establece los datos POST
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    // Indica que queremos que la respuesta sea devuelta como una cadena, no directamente en pantalla
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecuta la solicitud cURL y guarda la respuesta
    $response = curl_exec($ch);
    // Obtiene el código de estado HTTP de la respuesta
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Comprueba si hubo un error en la ejecución de cURL
    if (curl_errno($ch)) {
        // Registra el error en el log del servidor
        error_log("Error al enviar mensaje a Telegram (cURL error): " . curl_error($ch));
        curl_close($ch); // Cierra la sesión cURL
        return false;
    }
    curl_close($ch); // Cierra la sesión cURL

    // Comprueba el código de estado HTTP de la respuesta de Telegram
    if ($http_code != 200) {
        // Registra el error si la API de Telegram no devuelve un 200 OK
        error_log("Error en la respuesta de Telegram (HTTP $http_code): " . $response);
        return false;
    }

    // Decodifica la respuesta JSON de Telegram
    $response_data = json_decode($response, true);
    // Retorna true si la operación fue exitosa según la respuesta de Telegram
    return $response_data['ok'];
}
?>