<?php
// panel/index.php
date_default_timezone_set('America/Bogota'); // Asegúrate de que esta línea esté al principio.
session_start(); // Inicia la sesión

// Si el usuario no ha iniciado sesión, redirigir a login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirige a la página de login
    exit(); // Detiene la ejecución del script
}

// Opcional: Comprobar la inactividad de la sesión (ej. 1 hora)
$session_timeout = 3600; // 1 hora (en segundos)
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset(); // Elimina todas las variables de sesión
    session_destroy(); // Destruye la sesión
    header("Location: login.php?expired=true"); // Redirige con un mensaje de sesión expirada
    exit(); // Detiene la ejecución del script
}
$_SESSION['last_activity'] = time(); // Actualiza la última actividad en cada carga de página

// Redirigir al usuario al dashboard correcto según su rol
$user_role = $_SESSION['role'] ?? 'guest';

if ($user_role === 'marquillador') {
    header("Location: dashboard_b.php"); // Redirige a dashboard_b.php para marquilladores
} else {
    // Por defecto, o para roles 'admin' y 'user'
    header("Location: dashboard_a.php"); // Redirige a dashboard_a.php para admin/user
}
exit();
?>