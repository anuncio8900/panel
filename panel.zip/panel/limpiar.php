<?php
// panel/limpiar.php
date_default_timezone_set('America/Bogota'); //
session_start(); // Inicia la sesi��n al principio

// **NUEVA COMPROBACI�0�7N DE SEGURIDAD POR SESI�0�7N Y ROL**
// Si el usuario no ha iniciado sesi��n o su rol no es 'admin', se deniega el acceso.
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { //
    http_response_code(403); // C��digo de estado HTTP 403 Forbidden
    echo json_encode(["status" => "ERROR", "message" => "Acceso denegado. Solo administradores pueden realizar esta acci��n."]); //
    exit; // Detiene la ejecuci��n del script
}

require_once 'db.php'; // Incluye la conexi��n PDO

header('Content-Type: application/json; charset=UTF-8'); //

try {
    // Estas l��neas de JS en tu index.php ya env��an un X-Auth-Token.
    // Aunque ya verificamos con la sesi��n, mantener esta capa es opcional pero puede ser ��til si se accede de otras formas.
    // $AUTH_TOKEN = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Este token ven��a en tu JS
    // $headers = getallheaders();
    // if (!isset($headers['X-Auth-Token']) || $headers['X-Auth-Token'] !== $AUTH_TOKEN) {
    //     http_response_code(401);
    //     echo json_encode(["status" => "ERROR", "message" => "Acceso no autorizado por token."]);
    //     exit;
    // }

    // Tu l��gica original para limpiar la base de datos
    $db->exec("DELETE FROM registros"); //
    $db->exec("ALTER TABLE registros AUTO_INCREMENT = 1"); //

    echo json_encode(["status" => "OK", "message" => "Base de datos limpiada correctamente."]); //
    exit; //

} catch (PDOException $e) { //
    error_log("Error al limpiar registros (PDO): " . $e->getMessage()); //
    http_response_code(500); //
    echo json_encode(["status" => "ERROR", "message" => "Error interno del servidor al limpiar la base de datos (PDO): " . $e->getMessage()]); //
    exit; //
} catch (Exception $e) { //
    error_log("Error general al limpiar registros: " . $e->getMessage()); //
    http_response_code(500); //
    echo json_encode(["status" => "ERROR", "message" => "Error inesperado al limpiar la base de datos: " . $e->getMessage()]); //
    exit; //
}
?>