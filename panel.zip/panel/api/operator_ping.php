<?php
// panel/api/operator_ping.php
session_start(); // Inicia la sesión para acceder al user_id

date_default_timezone_set('America/Bogota');
header('Content-Type: application/json');

require_once '../db.php'; // Ruta a tu archivo de conexión a la base de datos

// Tu token de autenticación (el mismo que usas en otras APIs)
$AUTH_TOKEN = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g";

// Validar X-Auth-Token (primera capa de seguridad para la API)
$headers = getallheaders();
if (!isset($headers['X-Auth-Token']) || $headers['X-Auth-Token'] !== $AUTH_TOKEN) {
    http_response_code(401);
    echo json_encode(["status" => "ERROR", "message" => "Acceso no autorizado por token."]);
    exit();
}

// Validar que el usuario del panel esté logueado y tenga un user_id en la sesión
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(["status" => "ERROR", "message" => "No hay sesión de usuario activa."]);
    exit();
}

$panel_user_id = $_SESSION['user_id'];

try {
    // Actualizar solo la columna last_login_at para el usuario del panel
    $stmt = $db->prepare("UPDATE panel_users SET last_login_at = ? WHERE id = ?");
    $stmt->execute([date('Y-m-d H:i:s'), $panel_user_id]);

    echo json_encode(["status" => "OK", "message" => "Actividad del operador registrada.", "user_id" => $panel_user_id]);

} catch (PDOException $e) {
    http_response_code(500);
    error_log("Error de DB en operator_ping.php para user_id {$panel_user_id}: " . $e->getMessage());
    echo json_encode(["status" => "ERROR", "message" => "Error de base de datos al registrar actividad.", "detail" => $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    error_log("Error inesperado en operator_ping.php para user_id {$panel_user_id}: " . $e->getMessage());
    echo json_encode(["status" => "ERROR", "message" => "Error inesperado al registrar actividad.", "detail" => $e->getMessage()]);
}
?>