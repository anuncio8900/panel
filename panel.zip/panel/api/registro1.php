<?php
header("Content-Type: application/json; charset=utf-8");

$input = json_decode(file_get_contents("php://input"), true);

// Verifica clave API
if (!isset($input['clave']) || $input['clave'] !== 'colombia123') {
    http_response_code(403);
    echo json_encode(['error' => 'Clave inválida']);
    exit;
}

// Sanitiza y almacena
$usuario   = $input['usuario'] ?? '';
$ip        = $input['ip'] ?? '';
$fecha     = $input['fecha'] ?? '';
$hora      = $input['hora'] ?? '';
$navegador = $input['navegador'] ?? '';
$sistema   = $input['sistema'] ?? '';
$recibido  = date("Y-m-d H:i:s");

// Conexión a base de datos
$conn = new mysqli('localhost', 'TU_USUARIO_DB', 'TU_PASSWORD_DB', 'TU_NOMBRE_DB');
$conn->set_charset("utf8mb4");

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión DB']);
    exit;
}

// Inserta
$stmt = $conn->prepare("INSERT INTO registros (usuario, ip, fecha, hora, navegador, sistema, recibido_en) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $usuario, $ip, $fecha, $hora, $navegador, $sistema, $recibido);
$stmt->execute();
$stmt->close();
$conn->close();

echo json_encode(['estado' => 'ok']);
