<?php
echo json_encode(["status" => "OK", "message" => "Test API works!"]);
?>