<?php
// panel/api/subir_qr.php (MODIFICADO para usar db_qr.php)

date_default_timezone_set('America/Bogota');
header('Content-Type: application/json');

// Incluir el archivo de conexión a la base de datos para el QR (el que tiene la función connectDB)
require_once '../db_qr.php'; // ¡RUTA A db_qr.php!

// Tu token de autenticación. ¡Mantenlo seguro y no lo expongas!
$AUTH_TOKEN = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Debería ser el mismo que en gestion_usuario.php

// Función para devolver una respuesta JSON
function sendJsonResponse($status, $message, $data = null, $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Validar X-Auth-Token
$headers = getallheaders();
if (!isset($headers['X-Auth-Token']) || $headers['X-Auth-Token'] !== $AUTH_TOKEN) {
    sendJsonResponse('ERROR', 'Acceso no autorizado.', null, 401);
}

// Obtener datos del request
$usuario_id = $_POST['id'] ?? null;
$status_to_set = $_POST['status'] ?? null; // Debería ser 'Esperando APP QR'

// Validar ID de usuario y status
if (empty($usuario_id) || !is_numeric($usuario_id)) {
    sendJsonResponse('ERROR', 'ID de usuario no especificado o inválido.');
}
if (empty($status_to_set)) {
    sendJsonResponse('ERROR', 'Estado del usuario no especificado.');
}

// Procesar el archivo subido
if (!isset($_FILES['qr_image'])) {
    sendJsonResponse('ERROR', 'No se ha subido ninguna imagen.');
}

$file = $_FILES['qr_image'];

// Validar errores de subida de PHP
if ($file['error'] !== UPLOAD_ERR_OK) {
    sendJsonResponse('ERROR', 'Error al subir el archivo: ' . $file['error']);
}

// Validar tipo de archivo (mime type)
$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($file['type'], $allowedMimeTypes)) {
    sendJsonResponse('ERROR', 'Tipo de archivo no permitido. Solo se permiten imágenes (JPG, PNG, GIF, WebP).');
}

// Validar tamaño máximo (ej. 5MB)
$maxFileSize = 5 * 1024 * 1024; // 5 MB
if ($file['size'] > $maxFileSize) {
    sendJsonResponse('ERROR', 'La imagen es demasiado grande. El tamaño máximo permitido es 5MB.');
}

// Ruta donde se guardarán los QRs
$uploadDir = '../uploads/qrs/'; // Ruta relativa a panel/api/

// Asegurarse de que el directorio de subida existe y tiene permisos de escritura
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true)) {
        sendJsonResponse('ERROR', 'No se pudo crear el directorio de subida.');
    }
}
if (!is_writable($uploadDir)) {
    sendJsonResponse('ERROR', 'El directorio de subida no tiene permisos de escritura.');
}

// Generar un nombre único para el archivo para evitar colisiones
$fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
$newFileName = 'qr_' . $usuario_id . '_' . time() . '_' . uniqid() . '.' . $fileExtension;
$destinationPath = $uploadDir . $newFileName;

// Mover el archivo subido de la ubicación temporal a la de destino
if (!move_uploaded_file($file['tmp_name'], $destinationPath)) {
    sendJsonResponse('ERROR', 'Error al mover el archivo subido.');
}

// La URL pública (o ruta relativa desde la raíz del panel) para que el cliente acceda a la imagen
$qr_public_path = 'uploads/qrs/' . $newFileName; // Ruta relativa desde la raíz del panel (gestion_usuario.php)

try {
    // LLAMAR A connectDB() para obtener el objeto PDO desde db_qr.php
    $pdo = connectDB();

    // Iniciar una transacción para asegurar la consistencia de los datos
    $pdo->beginTransaction();

    // Actualizar la ruta del QR y el estado en la tabla de usuarios
    $stmt = $pdo->prepare("UPDATE registros SET qr_image_name = ?, status = ? WHERE id = ?");
    $stmt->execute([$qr_public_path, $status_to_set, $usuario_id]);

    // Confirmar la transacción
    $pdo->commit();

    sendJsonResponse('OK', 'QR subido y estado actualizado correctamente.', ['qr_path' => $qr_public_path]);

} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Eliminar el archivo subido si la actualización de la BD falla
    if (file_exists($destinationPath)) {
        unlink($destinationPath);
    }
    sendJsonResponse('ERROR', 'Error de base de datos al actualizar el QR: ' . $e->getMessage(), null, 500);
} catch (Exception $e) {
    sendJsonResponse('ERROR', 'Un error inesperado ocurrió: ' . $e->getMessage(), null, 500);
}

?>