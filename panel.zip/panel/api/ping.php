<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('America/Bogota');

// Incluir el archivo de conexión centralizado a la base de datos (PDO)
// __DIR__ se refiere al directorio del archivo actual (ping.php).
// Esto significa que buscará db.php en el directorio 'panel/' (un nivel arriba de 'panel/api/').
require_once __DIR__ . '/db.php'; // ASEGÚRATE DE QUE ESTA RUTA SEA CORRECTA

header('Content-Type: application/json');

// Validar ID recibido
$id = 0;
if (isset($_POST['id']) && is_numeric($_POST['id'])) {
    $id = (int) $_POST['id'];
}

if ($id <= 0) {
    echo json_encode(["status" => "ERROR", "mensaje" => "ID inválido"]);
    exit;
}

try {
    // Verificar si el ID existe usando PDO
    $stmtCheck = $db->prepare("SELECT COUNT(*) AS total FROM registros WHERE id = ?");
    $stmtCheck->execute([$id]);
    $row = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if ($row['total'] == 0) {
        echo json_encode(["status" => "ERROR", "mensaje" => "ID no existe"]);
        exit;
    }

    // Actualizar última conexión usando PDO
    $stmtUpdate = $db->prepare("UPDATE registros SET ultima_conexion = NOW() WHERE id = ?");
    if ($stmtUpdate->execute([$id])) {
        // Obtener el estado actual, la pregunta (preg) y el nombre de la imagen QR (qr_image_name)
        // desde la base de datos usando PDO
        $stmtStatus = $db->prepare("SELECT status, preg, qr_image_name FROM registros WHERE id = ?"); 
        $stmtStatus->execute([$id]);
        $userData = $stmtStatus->fetch(PDO::FETCH_ASSOC);
        
        $estado = $userData ? $userData['status'] : 'sin datos';
        $preg = $userData ? $userData['preg'] : null;
        $qr_image_name = $userData ? $userData['qr_image_name'] : null; // Obtener el nombre de la imagen QR

        $responseArray = [
            "status" => "OK",
            "mensaje" => "Ping registrado",
            "estado" => $estado
        ];
        if ($preg) { // Si hay una pregunta, añadirla a la respuesta del ping
            $responseArray['preg'] = $preg;
        }
        if ($qr_image_name) { // Si hay un nombre de imagen QR, añadirlo a la respuesta del ping
            $responseArray['qr_image_name'] = $qr_image_name;
        }

        echo json_encode($responseArray);
    } else {
        echo json_encode(["status" => "ERROR", "mensaje" => "No se pudo actualizar"]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    error_log("Error de base de datos en ping.php: " . $e->getMessage());
    echo json_encode(["status" => "ERROR", "mensaje" => "Error de base de datos", "detalle" => $e->getMessage()]);
}
?>