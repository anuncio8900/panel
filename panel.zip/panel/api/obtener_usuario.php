<?php

// panel/api/obtener_usuario.php

date_default_timezone_set('America/Bogota');
header('Content-Type: application/json');

// Incluir el archivo de conexión a la base de datos.
// Este db.php debe establecer una conexión globalmente disponible (ej. en $db).
require_once '../db.php'; // Asegúrate de que esta ruta sea correcta

// Tu token de autenticación
$AUTH_TOKEN = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Debería ser el mismo que en gestion_usuario.php

// Función para devolver una respuesta JSON
function sendJsonResponse($status, $message, $data = null, $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Validar X-Auth-Token
$headers = getallheaders();
if (!isset($headers['X-Auth-Token']) || $headers['X-Auth-Token'] !== $AUTH_TOKEN) {
    sendJsonResponse('ERROR', 'Acceso no autorizado.', null, 401);
}

// Obtener el ID del usuario de la URL
$usuario_id = $_GET['id'] ?? null;

if (empty($usuario_id) || !is_numeric($usuario_id)) {
    sendJsonResponse('ERROR', 'ID de usuario no especificado o inválido.');
}

try {
    // Asumimos que $db (la conexión PDO) ya está disponible globalmente desde db.php
    $stmt = $db->prepare("SELECT * FROM registros WHERE id = ?");
    $stmt->execute([$usuario_id]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($userData) {
        sendJsonResponse('OK', 'Datos de usuario obtenidos con éxito.', $userData);
    } else {
        sendJsonResponse('ERROR', 'Usuario no encontrado.');
    }

} catch (PDOException $e) {
    sendJsonResponse('ERROR', 'Error de base de datos: ' . $e->getMessage(), null, 500);
} catch (Exception $e) {
    sendJsonResponse('ERROR', 'Un error inesperado ocurrió: ' . $e->getMessage(), null, 500);
}
?>