<?php
// panel/dashboard_b.php (Dashboard para Marquilladores)
date_default_timezone_set('America/Bogota'); // Asegura la zona horaria
session_start(); // Inicia la sesión

// Comprobación de sesión: Si el usuario no ha iniciado sesión, redirigir a login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirige a la página de login
    exit(); // Detiene la ejecución del script
}

// Opcional: Comprobar la inactividad de la sesión (ej. 1 hora)
$session_timeout = 3600; // 1 hora (en segundos)
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    session_unset(); // Elimina todas las variables de sesión
    session_destroy(); // Destruye la sesión
    header("Location: login.php?expired=true"); // Redirige con un mensaje de sesión expirada
    exit(); // Detiene la ejecución del script
}
$_SESSION['last_activity'] = time(); // Actualiza la última actividad en cada carga de página

// === MODIFICACIÓN CLAVE AQUÍ ===
// Capturamos el username de la sesión EN UNA NUEVA VARIABLE antes de incluir db.php
$user_role = $_SESSION['role'] ?? 'guest'; // Obtiene el rol del usuario de la sesión
$operator_session_username = $_SESSION['username'] ?? 'Usuario'; // <-- ¡NUEVA VARIABLE para el username del operador!

// Incluir la conexión a la base de datos.
// ATENCIÓN: db.php define una variable $username. Por eso capturamos antes el nombre del operador.
require_once 'db.php'; 
// === FIN MODIFICACIÓN CLAVE ===

// --- Redirigir si el rol NO es 'marquillador' ---
if ($user_role !== 'marquillador') {
    header("Location: dashboard_a.php"); // Redirige a dashboard_a si no es marquillador
    exit(); // Detiene la ejecución
}

// --- Opcional: Obtener y limpiar cualquier mensaje de la sesión (ej. de gestion_usuario.php) ---
$session_message = '';
if (isset($_SESSION['message'])) {
    $session_message = $_SESSION['message'];
    unset($_SESSION['message']); // Limpiar el mensaje después de mostrarlo
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Dashboard Marquillador - Registros Pendientes</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 0;
            margin: 0;
            background: #f9f9f9;
        }
        .main-content-container {
            padding: 30px;
            max-width: 1200px;
            margin: 0px auto;
        }

        .top-navbar {
            background-color: #004080;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        .navbar-controls {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .dropdown-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        .dropdown-toggle {
            color: white;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .dropdown-toggle:hover { text-decoration: underline; }
        .dropdown-toggle i {
            font-size: 0.8em;
            transition: transform 0.2s ease;
        }
        .dropdown-container.show .dropdown-toggle i {
            transform: rotate(180deg);
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: #fff;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 100;
            border-radius: 5px;
            right: 0;
            top: 100%;
            margin-top: 5px;
            border: 1px solid #ddd;
        }
        .dropdown-menu a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
            transition: background-color 0.2s ease;
        }
        .dropdown-menu a:hover { background-color: #f1f1f1; }
        .dropdown-menu a i { margin-right: 8px; color: #007bff; }
        .dropdown-container.show .dropdown-menu { display: block; }

        /* Estilos de tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #f0f0f0;
            color: #555;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid #ddd;
        }
        /* Ajustar min-width para las columnas de acción/valor del marquillador */
        th.marquillador-action-col, td.marquillador-action-col {
            min-width: 160px; /* Ancho para botones (Enviar/Finalizar apilados) */
        }
        th.marquillador-valor-col, td.marquillador-valor-col {
            min-width: 120px; /* Ancho para el input de valor */
        }

        tbody tr:nth-child(even):not(.tr-alerta):not(.tr-offline-largo):not(.tr-taken-by-other) { /* MODIFICADO */
            background-color: #f4f8fc;
        }
        tbody tr:hover {
            background-color: #dceeff !important;
            cursor: pointer; /* Cursor de puntero para indicar interactividad si se usa la fila */
        }
        .tr-alerta:hover {
            background-color: #fff8e1 !important;
        }

        .estado-circulo {
            display: inline-block;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            margin-right: 6px;
            vertical-align: middle;
        }
        .estado-verde { background-color: green; }
        .estado-rojo { background-color: red; }

        .tr-alerta {
            animation: pulseBorder 1.5s infinite;
            border: 2px solid #ffcc00 !important;
        }
        @keyframes pulseBorder {
            0% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0.5); }
            70% { box-shadow: 0 0 0 10px rgba(255, 204, 0, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0); }
        }

        .estado-pulso {
            color: #d88c00;
            animation: blink-text 1s infinite;
            font-weight: bold;
        }
        @keyframes blink-text {
            0% { opacity: 1; }
            50% { opacity: 0.2; }
            100% { opacity: 1; }
        }

        .tr-offline-largo {
            background-color: #eee !important;
            color: #888;
            font-style: italic;
        }
        /* NUEVOS ESTILOS PARA REGISTROS TOMADOS POR OTRO MARQUILLADOR */
        .tr-taken-by-other {
            background-color: #e0e0e0 !important; /* Gris claro para indicar que está ocupado */
            color: #666;
            font-style: italic;
            cursor: not-allowed !important; /* Cursor de no permitido */
            opacity: 0.7; /* Ligeramente opaco */
            border: 1px solid #c0c0c0;
        }
        .tr-taken-by-other:hover {
            background-color: #d0d0d0 !important; /* Un gris un poco más oscuro al pasar el ratón */
        }
        .taken-message, .taken-message-action {
            font-size: 0.9em;
            color: #555;
            font-weight: bold;
        }
        /* FIN NUEVOS ESTILOS */

        /* Estilos para el input de valor y botones para Marquilladores */
        .marquillador-input-valor {
            width: 100%;
            padding: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
            color: #007bff;
        }
        .marquillador-action-buttons {
            display: flex;
            flex-direction: column;
            gap: 5px;
            width: 100%;
            align-items: center;
        }
        .marquillador-action-buttons button {
            width: 90%;
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            transition: background-color 0.2s ease;
        }
        .marquillador-action-buttons .btn-enviar-valor {
            background-color: #28a745;
            color: white;
        }
        .marquillador-action-buttons .btn-enviar-valor:hover {
            background-color: #218838;
        }
        .marquillador-action-buttons .btn-finalizar-marquillador {
            background-color: #007bff;
            color: white;
        }
        .marquillador-action-buttons .btn-finalizar-marquillador:hover {
            background-color: #0056b3;
        }

        /* Estilos para el spinner */
        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 3px solid #fff;
            width: 12px;
            height: 12px;
            -webkit-animation: spin 1s linear infinite; /* Safari */
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 5px;
            vertical-align: middle;
        }

        /* Safari */
        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Media Queries para Responsividad - Específicas para Marquillador */
        @media screen and (max-width: 768px) {
            .top-navbar {
                padding: 10px 15px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .navbar-brand { font-size: 20px; }
            .navbar-controls {
                width: 100%;
                justify-content: flex-end;
                gap: 10px;
            }
            .dropdown-menu {
                left: 0;
                right: auto;
            }
            .main-content-container {
                padding: 15px;
            }
            h2 {
                text-align: center;
                margin-top: 15px;
                margin-bottom: 15px;
            }
            
            table, thead, tbody, th, td, tr { display: block; }
            thead { display: none; }
            tr {
                margin-bottom: 15px;
                border: 2px solid #ddd;
                border-radius: 8px;
                padding: 10px;
                background-color: #fffefb;
            }
            td {
                position: relative;
                padding-left: 50% !important;
                text-align: right !important;
                border: none;
                border-bottom: 1px solid #eee;
                min-height: 40px;
                word-break: break-word;
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 10px;
                flex-wrap: wrap;
            }
            td:last-child { border-bottom: 0; }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: auto;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: bold;
                color: #004080;
            }
            /* Data labels para marquillador */
            td:nth-of-type(1)::before { content: "ID"; }
            td:nth-of-type(2)::before { content: "IP"; }
            td:nth-of-type(3)::before { content: "Fecha"; }
            td:nth-of-type(4)::before { content: "Hora"; }
            td:nth-of-type(5)::before { content: "Referencia"; }
            td:nth-of-type(6)::before { content: "Tienda"; }
            td:nth-of-type(7)::before { content: "Valor"; }
            td:nth-of-type(8)::before { content: "Acción"; }
            
            /* Columna de Acción - Ocultar data-label y ajustar botones */
            td.marquillador-action-col::before {
                display: none !important;
            }
            td.marquillador-action-col {
                padding-left: 10px !important;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 5px !important;
                flex-wrap: wrap;
            }
            .marquillador-action-buttons button {
                width: 100% !important;
                margin-top: 0px !important;
                margin-left: 0px !important;
                box-sizing: border-box;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 8px 10px;
                text-align: center;
            }
            .marquillador-action-buttons button i {
                margin-right: 5px;
                flex-shrink: 0;
                }
                .marquillador-action-buttons button span {
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
            }
        </style>
    </head>
    <body>
        <nav class="top-navbar">
            <a href="dashboard_b.php" class="navbar-brand">Dashboard Marquillador</a>
            <div class="navbar-controls">
                <div class="dropdown-container" id="userDropdown">
                    <span class="dropdown-toggle">
                        Bienvenido: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'Usuario'); ?></strong>
                        (Rol: <?php echo htmlspecialchars($_SESSION['role'] ?? 'N/A'); ?>)
                        <span id="current-username-js" style="display:none;"><?php echo htmlspecialchars($operator_session_username); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </span>
                    <div class="dropdown-menu">
                        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="main-content-container">
            <h2>Registros pendientes de Marquillaje</h2>

            <?php if (!empty($session_message)): ?>
                <div class="alert alert-info"><?php echo htmlspecialchars($session_message); ?></div>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>IP</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Referencia</th>
                        <th>Tienda</th>
                        <th class="marquillador-valor-col">Valor</th>
                        <th class="marquillador-action-col">ACCION</th>
                    </tr>
                </thead>
                <tbody id="tabla-registros-marquillador">
                    </tbody>
            </table>
        </div>

        <script>
        const userRole = <?php echo json_encode($user_role); ?>;
        const currentUsername = document.getElementById('current-username-js').textContent; 
        const authToken = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g";

        let refreshIntervalId; 
        let isEditing = false; 

        const AUTO_SEND_TIMEOUT_SECONDS = 60; 

        function applyCurrencyMask(elementId) {
            const inputElement = $('#' + elementId);
            if (!inputElement.length || !inputElement.hasClass('marquillador-input-valor')) return;

            const formatNumberForDisplay = (num) => {
                if (isNaN(num)) return '';
                return num.toLocaleString('es-CO', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 2
                }).replace(/[,.]00$/, '');
            };

            if (inputElement.val()) {
                let initialValUnmasked = inputElement.val().replace(/[$. ]/g, '').replace(',', '.');
                if (!isNaN(parseFloat(initialValUnmasked))) {
                    inputElement.val('$ ' + formatNumberForDisplay(parseFloat(initialValUnmasked))); 
                } else {
                    inputElement.val('');
                }
            }

            inputElement.mask('000.000.000.000.000,00', {
                reverse: true,
                translation: { '0': { pattern: /\d/ } },

                onKeyPress: function(val, e, field, options) {
                    let cleanVal = val.replace(/[^0-9]/g, '');
                    if (cleanVal.length === 0) {
                        field.val('');
                        return;
                    }

                    setTimeout(() => {
                        let currentVal = field.val().replace(/[^0-9]/g, '');
                        if (currentVal) {
                            let formatted = parseFloat(currentVal.replace(',', '.')).toLocaleString('es-CO', { 
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 2
                            });
                            formatted = formatted.replace(/[,.]00$/, ''); 
                            field.val('$ ' + formatted);
                        }
                    }, 1);
                },

                onComplete: function(cep) {
                    let numericValue = cep.replace(/[^0-9]/g, '').replace(',', '.');
                    if (!isNaN(parseFloat(numericValue))) { 
                        inputElement.val('$ ' + formatNumberForDisplay(parseFloat(numericValue))); 
                    } else {
                        inputElement.val('');
                    }
                },

                onUnmask: function(maskedValue, unmaskedValue) {
                    let clean = unmaskedValue.replace(/[^0-9]/g, '');
                    return clean.replace(',', '.'); 
                }
            });

            inputElement.off('focus').on('focus', function () {
                isEditing = true;
                clearInterval(refreshIntervalId);
                const recordId = this.id.split('_').pop(); 
                enviarOrdenEstado(recordId, 'En Proceso por Marquillador', { operador: currentUsername }, null, true);
            });

            inputElement.off('blur').on('blur', function () {
                isEditing = false;
                startAutoRefresh();
            });

            inputElement.off('keypress').on('keypress', function(e) {
                if (e.which === 13 || e.key === 'Enter') { 
                    e.preventDefault(); 
                    const recordId = this.id.split('_').pop(); 
                    if (recordId) {
                        enviarValorMarquillador(recordId, e);
                    }
                }
            });
        }


        function cargarRegistrosMarquillador() {
            if (!isEditing) {
                const timestamp = new Date().getTime();
                fetch(`cargar_registros_marquillador.php?_=${timestamp}`)
                    .then(response => response.text())
                    .then(html => {
                        const currentTbody = document.getElementById('tabla-registros-marquillador');

                        if (currentTbody) {
                            currentTbody.innerHTML = html; 
                            document.querySelectorAll('.marquillador-input-valor').forEach(input => {
                                applyCurrencyMask(input.id);
                            });

                            const nowInSeconds = Math.floor(Date.now() / 1000); 

                            document.querySelectorAll('#tabla-registros-marquillador tr').forEach(row => {
                                const recordId = row.dataset.recordId;
                                const createdAtTimestamp = parseInt(row.dataset.createdAt); 
                                const operadorRegistro = row.dataset.operador;
                                const statusRegistro = row.dataset.status;

                                // --- LÍNEAS DE DEPURACIÓN AÑADIDAS ---
                                console.log(`--- Depuración Registro ID: ${recordId} ---`);
                                console.log(`data-created-at (original): ${row.dataset.createdAt}`);
                                console.log(`createdAtTimestamp (parseado): ${createdAtTimestamp}`);
                                console.log(`nowInSeconds: ${nowInSeconds}`);
                                console.log(`recordAgeInSeconds: ${nowInSeconds - createdAtTimestamp}`);
                                console.log(`AUTO_SEND_TIMEOUT_SECONDS: ${AUTO_SEND_TIMEOUT_SECONDS}`);
                                console.log(`Condición de timeout: ${ (nowInSeconds - createdAtTimestamp) >= AUTO_SEND_TIMEOUT_SECONDS}`);
                                console.log(`statusRegistro: '${statusRegistro}', operadorRegistro: '${operadorRegistro}', currentUsername: '${currentUsername}'`);
                                // --- FIN LÍNEAS DE DEPURACIÓN ---

                                const recordAgeInSeconds = nowInSeconds - createdAtTimestamp;

                                if (recordAgeInSeconds >= AUTO_SEND_TIMEOUT_SECONDS) {
                                    // MODIFICADO: Ajustar la condición para el auto-envío
                                    // Incluimos:
                                    // 1. 'Referencia Ingresada' y no asignado (o 'sin datos')
                                    // 2. O 'Referencia Ingresada' y asignado a MÍ (currentUsername)
                                    // 3. O 'En Proceso por Marquillador' y asignado a MÍ (currentUsername)
                                    if ((statusRegistro === 'Referencia Ingresada' && (operadorRegistro === 'sin datos' || operadorRegistro === '' || operadorRegistro === currentUsername)) ||
                                        (statusRegistro === 'En Proceso por Marquillador' && operadorRegistro === currentUsername)) {
                                        console.log(`Auto-enviando registro ${recordId} por timeout.`);
                                        enviarOrdenEstado(recordId, 'Valor Enviado', { valor: '0', operador: currentUsername });
                                    }
                                }
                            });
                        } else {
                            console.error("Error: Elemento 'tabla-registros-marquillador' no encontrado en el DOM.");
                        }
                    })
                    .catch(err => {
                        console.error("Error al actualizar tabla del marquillador:", err);
                    });
            }
        }

        function startAutoRefresh() {
            if (refreshIntervalId) {
                clearInterval(refreshIntervalId);
            }
            refreshIntervalId = setInterval(cargarRegistrosMarquillador, 2000);
        }

        document.addEventListener("DOMContentLoaded", function() {
            cargarRegistrosMarquillador();
            startAutoRefresh();

            <?php if (!empty($session_message)): ?>
                alert("<?php echo htmlspecialchars($session_message); ?>");
            <?php endif; ?>
        });

        function enviarOrdenEstado(id, status, extraData = {}, buttonElement = null, isClaim = false) {
            if (buttonElement) {
                buttonElement.disabled = true;
                buttonElement.innerHTML = '<span class="spinner"></span> Enviando...';
            }

            const payload = { id: id, status: status, ...extraData };

            fetch("api/actualizar.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Auth-Token": authToken
                },
                body: JSON.stringify(payload)
            })
            .then(res => {
                if (!res.ok) {
                    return res.json().then(errorData => {
                        throw new Error(errorData.message || `Error del servidor (HTTP ${res.status}).`);
                    }).catch(() => {
                        throw new Error(`Error HTTP: ${res.status} ${res.statusText}`);
                    });
                }
                return res.json();
            })
            .then(data => {
                console.log(`Orden "${status}" enviada: `, data);
                if (data.status === "OK") {
                    if (isClaim) {
                        isEditing = true;
                        clearInterval(refreshIntervalId);
                    } else {
                        const rowToRemove = document.querySelector(`tr[data-record-id="${id}"]`);
                        if (rowToRemove) {
                            rowToRemove.parentNode.removeChild(rowToRemove);
                        }
                        const tbody = document.getElementById('tabla-registros-marquillador');
                        if (tbody && tbody.children.length === 0) {
                            tbody.innerHTML = "<tr><td colspan='8' style='text-align: center;'>No hay registros pendientes de marquillaje.</td></tr>";
                        }
                    }
                } else {
                    alert(`Error al enviar orden "${status}": ` + (data.message || 'Desconocido'));
                }
            })
            .catch(err => {
                console.error(`Error de red o API al enviar orden "${status}":`, err);
                alert(`Error de conexión al enviar orden "${status}".`);
            })
            .finally(() => {
                if (buttonElement && !isClaim) { 
                    if (status === 'Valor Enviado') {
                        buttonElement.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar';
                    } else if (status === 'Completado') {
                        buttonElement.innerHTML = '<i class="fas fa-check-circle"></i> Finalizar';
                    }
                    buttonElement.disabled = false;
                }
            });
        }

        function enviarValorMarquillador(id, event) {
            const button = event ? event.currentTarget : null;
            const inputValor = document.getElementById(`valor_input_${id}`);
            if (!inputValor) {
                alert('Error: No se encontró el campo de valor para este registro.');
                return;
            }
            let valor = inputValor.value;
            valor = valor.replace(/[$. ]/g, '').replace(',', '.');
            
            if (isNaN(parseFloat(valor))) {
                alert('Por favor, ingresa un valor numérico válido.');
                if (button) button.disabled = false;
                return;
            }

            if (valor === '') {
                valor = '0'; 
            }
            enviarOrdenEstado(id, 'Valor Enviado', { valor: valor, operador: currentUsername }, button);
        }

        function finalizarMarquillador(id, event) {
            const button = event ? event.currentTarget : null;
            enviarOrdenEstado(id, "Completado", { operador: currentUsername }, button);
        }

        function sendOperatorPing() {
            fetch("api/operator_ping.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Auth-Token": authToken
                },
                body: JSON.stringify({})
            })
            .then(response => response.json())
            .then(data => {
                // console.log("Ping de operador:", data);
            })
            .catch(error => {
                console.error("Error al enviar ping de operador:", error);
            });
        }

        document.addEventListener('DOMContentLoaded', sendOperatorPing);
        setInterval(sendOperatorPing, 30000);

        document.addEventListener('DOMContentLoaded', function() {
            const userDropdown = document.getElementById('userDropdown');
            const dropdownToggle = userDropdown.querySelector('.dropdown-toggle');
            const dropdownMenu = userDropdown.querySelector('.dropdown-menu');

            dropdownToggle.addEventListener('click', function() {
                userDropdown.classList.toggle('show');
            });

            window.addEventListener('click', function(event) {
                if (!userDropdown.contains(event.target)) {
                    userDropdown.classList.remove('show');
                }
            });
        });
        </script>

    </body>
</html>