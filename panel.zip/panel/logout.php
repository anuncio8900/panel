<?php
// panel/logout.php
session_start(); // Inicia la sesi��n

// Habilitar la visualizaci��n de errores (SOLO PARA DEPURACI�0�7N TEMPORAL)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

// Incluir el archivo de conexi��n a la base de datos
require_once 'db.php'; // Aseg��rate de que esta ruta sea correcta para acceder a tu $db

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Opcional: Mensajes de depuraci��n para los logs del servidor
    // error_log("DEBUG LOGOUT: Intentando limpiar sesi��n para user_id: " . $user_id . " en la DB.");

    try {
        // Limpiar current_ip, current_device_id y desbloquear al usuario en la base de datos.
        // Se establece is_blocked = FALSE para que el usuario pueda volver a iniciar sesi��n
        // sin intervenci��n del admin si fue bloqueado por un intento anterior.
        $stmt = $db->prepare("UPDATE panel_users SET current_ip = NULL, current_device_id = NULL, is_blocked = FALSE WHERE id = ?");
        
        if ($stmt->execute([$user_id])) {
            // error_log("DEBUG LOGOUT: IP/Device ID limpiados y usuario desbloqueado exitosamente para user_id: " . $user_id);
        } else {
            // error_log("DEBUG LOGOUT: Fallo en execute() al limpiar IP/Device ID para user_id: " . $user_id . " ErrorInfo: " . implode(":", $stmt->errorInfo()));
        }

    } catch (PDOException $e) {
        // Registra el error si falla la actualizaci��n de la DB, pero no detiene el logout.
        error_log("DEBUG LOGOUT ERROR: Excepci��n PDO al limpiar IP/Device ID para user_id {$user_id}: " . $e->getMessage());
    }
} else {
    // error_log("DEBUG LOGOUT: user_id no encontrado en la sesi��n al intentar cerrar sesi��n.");
}

// Limpiar todas las variables de sesi��n del servidor
session_unset();
// Destruir la sesi��n actual
session_destroy();

// Redirigir al usuario a la p��gina de login
header("Location: login.php");
exit(); // Es crucial llamar a exit() despu��s de un header() para asegurar que el script se detenga
?>