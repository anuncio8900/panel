<?php
// panel/db.php (Versión que establece conexión global $db)

$host = 'localhost'; // O '127.0.0.1' si 'localhost' causa problemas de socket
$dbname = 'espacove_general';
$username = 'espacove_pollo';
$password = 'Colombia123@.';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Configurar la zona horaria para la conexión MySQL
    $db->exec("SET time_zone = '-05:00'"); // Hora Barranquilla, Atlántico, Colombia.
} catch (PDOException $e) {
    // Registrar el error en el log del servidor
    error_log("Error de conexión a la base de datos en db.php: " . $e->getMessage());

    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        "status" => "ERROR",
        "message" => "Error de conexión a la base de datos",
        "detail" => $e->getMessage()
    ]);
    exit;
}
// La conexión $db está disponible globalmente para los scripts que incluyan este archivo.
?>