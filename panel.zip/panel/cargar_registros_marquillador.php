<?php
// panel/cargar_registros_marquillador.php
// Este script es llamado por AJAX para refrescar solo el tbody de la tabla de marquilladores.

header('Content-Type: text/html; charset=UTF-8');
date_default_timezone_set('America/Bogota'); // Asegura la zona horaria de Barranquilla
session_start(); // Necesario para acceder a $_SESSION['username']

// Incluir la conexión a la base de datos
require_once 'db.php';

// Obtener el username del marquillador logueado
$username = $_SESSION['username'] ?? 'Usuario';

$limite = 50; // Puedes ajustar el límite si es necesario

try {
    $sql_select = "SELECT * FROM registros";
    $sql_where = [];
    $params = [];

    // MODIFICADO: Filtro para marquilladores:
    // Un marquillador SÓLO debe ver registros en estado 'Referencia Ingresada' o 'En Proceso por Marquillador'.
    // Excluimos 'Valor Enviado' y 'Completado' porque se consideran gestionados y se quitan de la tabla.
    $sql_where[] = "(status = ? OR status = ?)";
    $params[] = "Referencia Ingresada";
    $params[] = "En Proceso por Marquillador";
    
    // Y el registro debe ser para este marquillador:
    // 1. O el operador del registro es EXACTAMENTE el username del marquillador logueado.
    // 2. O el operador es NULL / 'sin datos' / '' (es decir, no asignado a NADIE aún).
    // Esta es la lógica para que lo vea el que lo tiene asignado, o cualquiera si está libre.
    $sql_where[] = "(operador = ? OR operador IS NULL OR operador = 'sin datos' OR operador = '')";
    $params[] = $username; 

    if (!empty($sql_where)) {
        $sql_select .= " WHERE " . implode(" AND ", $sql_where);
    }
    $sql_select .= " ORDER BY id DESC LIMIT " . $limite;

    $stmt = $db->prepare($sql_select);
    $stmt->execute($params);
    $registros_marquillador = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $ahora_timestamp = time(); // Usamos timestamp para cálculos de tiempo en JS

    if (empty($registros_marquillador)) {
        echo "<tr><td colspan='8' style='text-align: center;'>No hay registros pendientes de marquillaje.</td></tr>";
    } else {
        foreach ($registros_marquillador as $fila) {
            $created_at_timestamp = strtotime($fila['created_at']); // Convertir created_at a timestamp para JS
            $operador_registro = htmlspecialchars($fila['operador'] ?? 'sin datos');
            $estado = htmlspecialchars($fila['status'] ?? '');

            $claseFila = '';
            $display_action_controls = false; // Bandera para controlar si se muestran los inputs/botones
            $message_if_taken = ''; // Mensaje si el registro está tomado por otro

            // Determinar si el marquillador actual puede interactuar con este registro
            // o si está tomado por otro.
            if ($estado === "Referencia Ingresada" && ($operador_registro === $username || $operador_registro === 'sin datos' || $operador_registro === '')) {
                // Si está en 'Referencia Ingresada' y no tiene dueño o el dueño soy yo
                $claseFila = 'tr-alerta'; // Resaltar para llamar la atención
                $display_action_controls = true; // Puede interactuar
            } elseif ($estado === "En Proceso por Marquillador" && $operador_registro === $username) {
                // Si está 'En Proceso' y el dueño soy yo
                $display_action_controls = true; // Puede interactuar
            } elseif ($estado === "En Proceso por Marquillador" && $operador_registro !== $username && !empty($operador_registro) && $operador_registro !== 'sin datos') {
                // Si está 'En Proceso' y el dueño es OTRO marquillador
                $claseFila = 'tr-taken-by-other'; // Nueva clase para estilos visuales
                $message_if_taken = "Tomado por " . $operador_registro;
                $display_action_controls = false; // NO puede interactuar
            }
            // Los estados 'Valor Enviado' y 'Completado' ya no se procesan aquí porque se excluyen en la consulta SQL.


            // AÑADIDO: data-record-id, data-created-at, data-operador, data-status al <tr>
            // Esto es crucial para que el JavaScript pueda leer esta información.
            echo "<tr class='$claseFila' data-record-id='{$fila['id']}' data-created-at='{$created_at_timestamp}' data-operador='{$operador_registro}' data-status='{$estado}'>";

            echo "<td data-label='ID'>" . htmlspecialchars($fila['id']) . "</td>";
            echo "<td data-label='IP'>" . htmlspecialchars($fila['ip'] ?? 'sin datos') . "</td>";
            echo "<td data-label='Fecha'>" . htmlspecialchars($fila['fecha'] ?? 'sin datos') . "</td>";
            echo "<td data-label='Hora'>" . htmlspecialchars($fila['hora'] ?? 'sin datos') . "</td>";
            echo "<td data-label='Referencia'>" . htmlspecialchars($fila['referencia'] ?? 'sin datos') . "</td>";
            echo "<td data-label='Tienda'>" . htmlspecialchars($fila['tienda'] ?? 'sin datos') . "</td>";

            // Columna 'Valor' para marquilladores
            echo "<td data-label='Valor'>";
            if ($display_action_controls) {
                $current_valor_display = htmlspecialchars($fila['valor'] ?? '');
                // Se mantiene la lógica de applyCurrencyMask en el JS para el formato
                echo "<input type='text' id='valor_input_{$fila['id']}' class='marquillador-input-valor' value='{$current_valor_display}' placeholder='$ 0,00'>";
            } elseif (!empty($message_if_taken)) {
                echo "<span class='taken-message'>" . $message_if_taken . "</span>"; // Muestra el mensaje si está tomado
            } else {
                echo htmlspecialchars($fila['valor'] ?? 'sin datos'); // Muestra el valor normal si no hay interacción
            }
            echo "</td>";

            // Columna 'ACCION' para marquilladores
            echo "<td data-label='Acción' class='marquillador-action-col'>";
            if ($display_action_controls) {
                echo "  <div class='marquillador-action-buttons'>";
                echo "      <button class='btn-enviar-valor' onclick='event.stopPropagation(); enviarValorMarquillador({$fila['id']}, event)'><i class='fas fa-paper-plane'></i> Enviar</button>";
                echo "      <button class='btn-finalizar-marquillador' onclick='event.stopPropagation(); finalizarMarquillador({$fila['id']}, event)'><i class='fas fa-check-circle'></i> Finalizar</button>";
                echo "  </div>";
            } elseif (!empty($message_if_taken)) {
                echo "<span class='taken-message-action'>Por otro</span>"; // Mensaje más corto para la columna de acción
            } else {
                 echo "<span>" . $estado . "</span>";
            }
            echo "</td>";
            echo "</tr>";
        }
    }
} catch (PDOException $e) {
    error_log("Error en cargar_registros_marquillador.php: " . $e->getMessage());
    echo "<tr><td colspan='8'>Error al cargar los registros: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
}
?>